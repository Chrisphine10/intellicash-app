import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/theme/app_colors.dart';

class StatusBadge extends StatelessWidget {
  final String status;
  final bool? isActive;
  final double fontSize;

  const StatusBadge({
    super.key,
    required this.status,
    this.isActive,
    this.fontSize = 11,
  });

  Color get _color {
    if (isActive != null) {
      return isActive! ? AppColors.statusActive : AppColors.statusInactive;
    }
    return AppColors.getStatusColor(status);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: _color.withAlpha(20),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _color.withAlpha(60)),
      ),
      child: Text(
        status,
        style: GoogleFonts.inter(
          fontSize: fontSize,
          color: _color,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}
