import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  String _baseUrl = '';
  String _apiKey = '';
  String _apiSecret = '';

  static final ApiService _instance = ApiService._internal();
  factory ApiService() => _instance;
  ApiService._internal();

  void configure({
    required String baseUrl,
    required String apiKey,
    required String apiSecret,
  }) {
    _baseUrl = baseUrl.endsWith('/') ? baseUrl.substring(0, baseUrl.length - 1) : baseUrl;
    _apiKey = apiKey;
    _apiSecret = apiSecret;
  }

  bool get isConfigured => _baseUrl.isNotEmpty && _apiKey.isNotEmpty;
  String get baseUrl => _baseUrl;

  Map<String, String> get _headers => {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'X-Api-Key': _apiKey,
    'X-Api-Secret': _apiSecret,
  };

  Future<Map<String, dynamic>> get(String endpoint, {Map<String, String>? queryParams}) async {
    final uri = Uri.parse('$_baseUrl/api$endpoint').replace(queryParameters: queryParams);
    final response = await http.get(uri, headers: _headers);
    return _handleResponse(response);
  }

  Future<Map<String, dynamic>> post(String endpoint, Map<String, dynamic> body) async {
    final uri = Uri.parse('$_baseUrl/api$endpoint');
    final response = await http.post(uri, headers: _headers, body: jsonEncode(body));
    return _handleResponse(response);
  }

  Map<String, dynamic> _handleResponse(http.Response response) {
    final body = jsonDecode(response.body) as Map<String, dynamic>;
    if (response.statusCode >= 200 && response.statusCode < 300) {
      return body;
    }
    throw ApiException(
      statusCode: response.statusCode,
      message: body['message'] ?? body['error'] ?? 'Unknown error',
    );
  }

  Future<bool> testConnection() async {
    try {
      final uri = Uri.parse('$_baseUrl/api/health');
      final response = await http.get(uri, headers: {'Accept': 'application/json'});
      return response.statusCode == 200;
    } catch (_) {
      return false;
    }
  }
}

class ApiException implements Exception {
  final int statusCode;
  final String message;
  ApiException({required this.statusCode, required this.message});

  @override
  String toString() => 'ApiException($statusCode): $message';
}
