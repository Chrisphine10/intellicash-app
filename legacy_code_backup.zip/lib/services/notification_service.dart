import 'dart:async';
import 'package:flutter/foundation.dart';
import '../core/network/api_client.dart';
import '../core/constants/api_endpoints.dart';
import '../models/notification/notification_model.dart';

class NotificationService {
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  final ApiClient _apiClient = ApiClient();

  final List<NotificationModel> _notifications = [];
  List<NotificationModel> get notifications =>
      List.unmodifiable(_notifications);

  int _unreadCount = 0;
  int get unreadCount => _unreadCount;

  final StreamController<List<NotificationModel>> _notificationController =
      StreamController<List<NotificationModel>>.broadcast();
  Stream<List<NotificationModel>> get notificationStream =>
      _notificationController.stream;

  Future<void> initialize() async {
    // Platform-specific notification setup would go here
    debugPrint('[NotificationService] Initialized');
  }

  Future<List<NotificationModel>> fetchNotifications({
    int page = 1,
    int perPage = 50,
  }) async {
    try {
      final response = await _apiClient.get(
        ApiEndpoints.notifications,
        queryParams: {
          'page': page.toString(),
          'per_page': perPage.toString(),
        },
      );
      if (response.isSuccess && response.data != null) {
        final list = response.data is List
            ? (response.data as List)
                .map((e) => NotificationModel.fromJson(e))
                .toList()
            : <NotificationModel>[];
        _notifications.clear();
        _notifications.addAll(list);
        _updateUnreadCount();
        _notificationController.add(List.from(_notifications));
        return list;
      }
      return [];
    } catch (e) {
      debugPrint('[NotificationService] Fetch failed: $e');
      return [];
    }
  }

  Future<bool> markAsRead(String notificationId) async {
    try {
      final response = await _apiClient.post(
        ApiEndpoints.notificationReadOne(notificationId),
      );
      if (response.isSuccess) {
        final index = _notifications.indexWhere((n) => n.id == notificationId);
        if (index >= 0) {
          _notifications[index] = NotificationModel(
            id: _notifications[index].id,
            title: _notifications[index].title,
            body: _notifications[index].body,
            type: _notifications[index].type,
            channel: _notifications[index].channel,
            status: _notifications[index].status,
            recipientId: _notifications[index].recipientId,
            groupId: _notifications[index].groupId,
            referenceType: _notifications[index].referenceType,
            referenceId: _notifications[index].referenceId,
            data: _notifications[index].data,
            isRead: true,
            readAt: DateTime.now(),
            createdAt: _notifications[index].createdAt,
          );
          _updateUnreadCount();
          _notificationController.add(List.from(_notifications));
        }
        return true;
      }
      return false;
    } catch (e) {
      debugPrint('[NotificationService] Mark read failed: $e');
      return false;
    }
  }

  Future<bool> markAllAsRead() async {
    try {
      final response =
          await _apiClient.post(ApiEndpoints.notificationRead);
      if (response.isSuccess) {
        for (int i = 0; i < _notifications.length; i++) {
          _notifications[i] = NotificationModel(
            id: _notifications[i].id,
            title: _notifications[i].title,
            body: _notifications[i].body,
            type: _notifications[i].type,
            channel: _notifications[i].channel,
            status: _notifications[i].status,
            recipientId: _notifications[i].recipientId,
            groupId: _notifications[i].groupId,
            referenceType: _notifications[i].referenceType,
            referenceId: _notifications[i].referenceId,
            data: _notifications[i].data,
            isRead: true,
            readAt: DateTime.now(),
            createdAt: _notifications[i].createdAt,
          );
        }
        _unreadCount = 0;
        _notificationController.add(List.from(_notifications));
        return true;
      }
      return false;
    } catch (e) {
      debugPrint('[NotificationService] Mark all read failed: $e');
      return false;
    }
  }

  Future<bool> sendNotification({
    required String type,
    required String title,
    required String body,
    String? recipientId,
    String? groupId,
    String? channel,
    String? referenceType,
    String? referenceId,
  }) async {
    try {
      final response = await _apiClient.post(
        ApiEndpoints.notificationSend,
        body: {
          'type': type,
          'title': title,
          'body': body,
          'recipient_id': recipientId,
          'group_id': groupId,
          'channel': channel ?? 'in_app',
          'reference_type': referenceType,
          'reference_id': referenceId,
        },
      );
      return response.isSuccess;
    } catch (e) {
      debugPrint('[NotificationService] Send failed: $e');
      return false;
    }
  }

  Future<bool> deleteNotification(String notificationId) async {
    try {
      final response =
          await _apiClient.delete(ApiEndpoints.notificationById(notificationId));
      if (response.isSuccess) {
        _notifications.removeWhere((n) => n.id == notificationId);
        _updateUnreadCount();
        _notificationController.add(List.from(_notifications));
        return true;
      }
      return false;
    } catch (e) {
      debugPrint('[NotificationService] Delete failed: $e');
      return false;
    }
  }

  void _updateUnreadCount() {
    _unreadCount = _notifications.where((n) => !n.isRead).length;
  }

  void dispose() {
    _notificationController.close();
  }
}
