import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../core/network/api_client.dart';
import '../core/constants/api_endpoints.dart';
import '../models/user/user_model.dart';

class AuthService {
  static final AuthService _instance = AuthService._internal();
  factory AuthService() => _instance;
  AuthService._internal();

  final FlutterSecureStorage _secureStorage = const FlutterSecureStorage();
  final ApiClient _apiClient = ApiClient();

  static const String _keyAccessToken = 'ic_access_token';
  static const String _keyRefreshToken = 'ic_refresh_token';
  static const String _keyUserData = 'ic_user_data';
  static const String _keyBaseUrl = 'ic_base_url';
  static const String _keyApiKey = 'ic_api_key';
  static const String _keyApiSecret = 'ic_api_secret';
  static const String _keyIsLoggedIn = 'ic_is_logged_in';
  static const String _keyUserId = 'ic_user_id';

  UserModel? _currentUser;
  UserModel? get currentUser => _currentUser;

  bool _isAuthenticated = false;
  bool get isAuthenticated => _isAuthenticated;

  Future<bool> isLoggedIn() async {
    return await _secureStorage.read(key: _keyIsLoggedIn) == 'true';
  }

  Future<void> loadSavedSession() async {
    try {
      final accessToken = await _secureStorage.read(key: _keyAccessToken);
      final baseUrl = await _secureStorage.read(key: _keyBaseUrl);

      if (accessToken != null && baseUrl != null) {
        _apiClient.configure(baseUrl: baseUrl, accessToken: accessToken);
        final userData = await _secureStorage.read(key: _keyUserData);
        if (userData != null) {
          _currentUser = UserModel.fromJson(_parseUserJson(userData));
        }
        _isAuthenticated = true;
      }
    } catch (e) {
      debugPrint('Failed to load saved session: $e');
      await logout();
    }
  }

  Future<bool> loginWithApiKey({
    required String baseUrl,
    required String apiKey,
    required String apiSecret,
  }) async {
    try {
      _apiClient.configure(
        baseUrl: baseUrl,
        apiKey: apiKey,
        apiSecret: apiSecret,
      );

      final response = await _apiClient.get(ApiEndpoints.profile);
      if (response.isSuccess && response.data != null) {
        _currentUser = UserModel.fromJson(
            response.data as Map<String, dynamic>);
        _isAuthenticated = true;

        await _secureStorage.write(key: _keyBaseUrl, value: baseUrl);
        await _secureStorage.write(key: _keyApiKey, value: apiKey);
        await _secureStorage.write(key: _keyApiSecret, value: apiSecret);
        await _secureStorage.write(key: _keyIsLoggedIn, value: 'true');
        await _secureStorage.write(
            key: _keyUserData, value: response.data.toString());
        await _secureStorage.write(
            key: _keyUserId, value: _currentUser!.id);

        return true;
      }
      return false;
    } catch (e) {
      debugPrint('Login failed: $e');
      return false;
    }
  }

  Future<bool> loginWithEmail({
    required String baseUrl,
    required String email,
    required String password,
  }) async {
    try {
      _apiClient.configure(baseUrl: baseUrl);

      final response = await _apiClient.post(
        ApiEndpoints.login,
        body: {'email': email, 'password': password},
        requiresAuth: false,
      );

      if (response.isSuccess && response.data != null) {
        final data = response.data as Map<String, dynamic>;
        _apiClient.setTokens(
          data['access_token'] ?? data['token'],
          data['refresh_token'],
        );
        _currentUser = UserModel.fromJson(
            (data['user'] ?? data['data']) as Map<String, dynamic>);
        _isAuthenticated = true;

        await _saveSession(data);
        return true;
      }
      return false;
    } catch (e) {
      debugPrint('Login failed: $e');
      return false;
    }
  }

  Future<bool> register(Map<String, dynamic> userData) async {
    try {
      final response = await _apiClient.post(
        ApiEndpoints.register,
        body: userData,
        requiresAuth: false,
      );
      return response.isSuccess;
    } catch (e) {
      debugPrint('Registration failed: $e');
      return false;
    }
  }

  Future<bool> verifyMfa(String code) async {
    try {
      final response = await _apiClient.post(
        ApiEndpoints.verifyMfa,
        body: {'code': code},
      );
      return response.isSuccess;
    } catch (e) {
      debugPrint('MFA verification failed: $e');
      return false;
    }
  }

  Future<bool> enableMfa() async {
    try {
      final response = await _apiClient.post(ApiEndpoints.twoFactor);
      return response.isSuccess;
    } catch (e) {
      debugPrint('Enable MFA failed: $e');
      return false;
    }
  }

  Future<bool> forgotPassword(String email) async {
    try {
      final response = await _apiClient.post(
        ApiEndpoints.forgotPassword,
        body: {'email': email},
        requiresAuth: false,
      );
      return response.isSuccess;
    } catch (e) {
      debugPrint('Forgot password failed: $e');
      return false;
    }
  }

  Future<bool> resetPassword(String token, String password) async {
    try {
      final response = await _apiClient.post(
        ApiEndpoints.resetPassword,
        body: {'token': token, 'password': password},
        requiresAuth: false,
      );
      return response.isSuccess;
    } catch (e) {
      debugPrint('Reset password failed: $e');
      return false;
    }
  }

  Future<bool> changePassword(
      String currentPassword, String newPassword) async {
    try {
      final response = await _apiClient.post(
        ApiEndpoints.changePassword,
        body: {
          'current_password': currentPassword,
          'new_password': newPassword,
        },
      );
      return response.isSuccess;
    } catch (e) {
      debugPrint('Change password failed: $e');
      return false;
    }
  }

  Future<void> logout() async {
    try {
      await _apiClient.post(ApiEndpoints.logout);
    } catch (_) {}
    _currentUser = null;
    _isAuthenticated = false;
    _apiClient.clearTokens();
    await _clearSession();
  }

  Future<void> refreshSession() async {
    try {
      final response = await _apiClient.post(ApiEndpoints.refreshToken);
      if (response.isSuccess && response.data != null) {
        final data = response.data as Map<String, dynamic>;
        await _secureStorage.write(
            key: _keyAccessToken, value: data['access_token']);
        await _secureStorage.write(
            key: _keyRefreshToken, value: data['refresh_token']);
      }
    } catch (e) {
      debugPrint('Session refresh failed: $e');
    }
  }

  Future<void> _saveSession(Map<String, dynamic> data) async {
    await _secureStorage.write(
        key: _keyAccessToken, value: data['access_token'] ?? data['token']);
    if (data['refresh_token'] != null) {
      await _secureStorage.write(
          key: _keyRefreshToken, value: data['refresh_token']);
    }
    await _secureStorage.write(key: _keyIsLoggedIn, value: 'true');
    await _secureStorage.write(key: _keyUserId, value: _currentUser?.id ?? '');
    if (_currentUser != null) {
      await _secureStorage.write(
          key: _keyUserData, value: _currentUser!.toJson().toString());
    }
  }

  Future<void> _clearSession() async {
    await _secureStorage.delete(key: _keyAccessToken);
    await _secureStorage.delete(key: _keyRefreshToken);
    await _secureStorage.delete(key: _keyUserData);
    await _secureStorage.delete(key: _keyIsLoggedIn);
    await _secureStorage.delete(key: _keyUserId);
  }

  Future<String?> getAccessToken() async {
    return await _secureStorage.read(key: _keyAccessToken);
  }

  Future<UserModel?> getUser() async {
    if (_currentUser != null) return _currentUser;
    final userData = await _secureStorage.read(key: _keyUserData);
    if (userData != null) {
      try {
        _currentUser = UserModel.fromJson(_parseUserJson(userData));
      } catch (_) {}
    }
    return _currentUser;
  }
}

Map<String, dynamic> _parseUserJson(String json) {
  try {
    final parsed = jsonDecode(json);
    return Map<String, dynamic>.from(parsed as Map);
  } catch (_) {
    return {};
  }
}
