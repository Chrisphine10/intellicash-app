import 'dart:async';
import 'package:flutter/foundation.dart';
import '../core/network/api_client.dart';
import '../core/constants/api_endpoints.dart';
import 'offline_service.dart';

enum SyncStatus { idle, syncing, completed, failed }

class SyncService {
  static final SyncService _instance = SyncService._internal();
  factory SyncService() => _instance;
  SyncService._internal();

  final ApiClient _apiClient = ApiClient();
  final OfflineService _offlineService = OfflineService();

  SyncStatus _status = SyncStatus.idle;
  SyncStatus get status => _status;

  double _progress = 0.0;
  double get progress => _progress;

  String? _lastSyncMessage;
  String? get lastSyncMessage => _lastSyncMessage;

  DateTime? _lastSyncTime;
  DateTime? get lastSyncTime => _lastSyncTime;

  Timer? _autoSyncTimer;
  bool _isInitialized = false;

  final StreamController<SyncStatus> _statusController =
      StreamController<SyncStatus>.broadcast();
  Stream<SyncStatus> get statusStream => _statusController.stream;

  final StreamController<double> _progressController =
      StreamController<double>.broadcast();
  Stream<double> get progressStream => _progressController.stream;

  void initialize({int intervalMinutes = 15}) {
    if (_isInitialized) return;
    _isInitialized = true;

    _autoSyncTimer = Timer.periodic(
      Duration(minutes: intervalMinutes),
      (_) => _autoSync(),
    );
  }

  Future<void> _autoSync() async {
    if (!_offlineService.isOnline) return;
    if (_status == SyncStatus.syncing) return;
    await syncAll();
  }

  Future<bool> syncAll() async {
    if (_status == SyncStatus.syncing) return false;
    if (!_offlineService.isOnline) {
      _lastSyncMessage = 'No internet connection';
      return false;
    }

    _setStatus(SyncStatus.syncing);
    _progress = 0.0;
    _lastSyncMessage = 'Starting sync...';

    try {
      await _pushPendingChanges();
      _progress = 0.3;
      _progressController.add(0.3);

      await _pullChanges();
      _progress = 0.7;
      _progressController.add(0.7);

      await _resolveConflicts();
      _progress = 1.0;
      _progressController.add(1.0);

      _lastSyncTime = DateTime.now();
      _lastSyncMessage = 'Sync completed successfully';
      _setStatus(SyncStatus.completed);
      return true;
    } catch (e) {
      _lastSyncMessage = 'Sync failed: $e';
      _setStatus(SyncStatus.failed);
      return false;
    }
  }

  Future<void> _pushPendingChanges() async {
    final pending = _offlineService.pendingSyncQueue;
    if (pending.isEmpty) {
      debugPrint('[SyncService] No pending changes to push');
      return;
    }

    debugPrint('[SyncService] Pushing ${pending.length} changes...');
    try {
      await _apiClient.post(
        ApiEndpoints.syncPush,
        body: {'changes': pending},
      );
      await _offlineService.clearSyncQueue();
    } catch (e) {
      debugPrint('[SyncService] Push failed: $e');
      rethrow;
    }
  }

  Future<void> _pullChanges() async {
    debugPrint('[SyncService] Pulling changes from server...');
    try {
      final lastSync = _lastSyncTime?.toIso8601String() ?? '';
      final response = await _apiClient.get(
        ApiEndpoints.syncPull,
        queryParams: {
          'last_sync': lastSync,
          'limit': '5000',
        },
      );

      if (response.isSuccess && response.data != null) {
        debugPrint('[SyncService] Pulled data successfully');
      }
    } catch (e) {
      debugPrint('[SyncService] Pull failed: $e');
      rethrow;
    }
  }

  Future<void> _resolveConflicts() async {
    try {
      final response = await _apiClient.get(ApiEndpoints.syncConflict);
      if (response.isSuccess && response.data != null) {
        debugPrint('[SyncService] Found conflicts to resolve');
      }
    } catch (e) {
      debugPrint('[SyncService] Conflict resolution failed: $e');
    }
  }

  Future<bool> syncEntity(String entityType, String entityId) async {
    if (!_offlineService.isOnline) return false;
    try {
      final response = await _apiClient.get('/$entityType/$entityId/sync');
      if (response.isSuccess) {
        await _offlineService.cacheData(
          '${entityType}_$entityId',
          response.data,
        );
        return true;
      }
      return false;
    } catch (e) {
      debugPrint('[SyncService] Entity sync failed: $e');
      return false;
    }
  }

  Future<Map<String, dynamic>> getSyncStatus() async {
    try {
      final response = await _apiClient.get(ApiEndpoints.syncStatus);
      return {
        'server': response.isSuccess,
        'pending': _offlineService.pendingSyncCount,
        'last_sync': _lastSyncTime?.toIso8601String(),
        'online': _offlineService.isOnline,
      };
    } catch (_) {
      return {
        'server': false,
        'pending': _offlineService.pendingSyncCount,
        'last_sync': _lastSyncTime?.toIso8601String(),
        'online': _offlineService.isOnline,
      };
    }
  }

  void _setStatus(SyncStatus newStatus) {
    _status = newStatus;
    _statusController.add(newStatus);
  }

  void dispose() {
    _autoSyncTimer?.cancel();
    _statusController.close();
    _progressController.close();
  }
}
