import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:connectivity_plus/connectivity_plus.dart';

class OfflineService {
  static final OfflineService _instance = OfflineService._internal();
  factory OfflineService() => _instance;
  OfflineService._internal();

  SharedPreferences? _prefs;
  bool _isOnline = true;
  bool get isOnline => _isOnline;

  final List<Map<String, dynamic>> _pendingSyncQueue = [];
  List<Map<String, dynamic>> get pendingSyncQueue =>
      List.unmodifiable(_pendingSyncQueue);
  int get pendingSyncCount => _pendingSyncQueue.length;

  static const String _keyPendingSync = 'pending_sync_queue';
  static const String _keyLastSyncTime = 'last_sync_time';
  static const String _keyCachedData = 'cached_data_';

  Future<void> initialize() async {
    _prefs = await SharedPreferences.getInstance();
    await _loadSyncQueue();
    _monitorConnectivity();
  }

  void _monitorConnectivity() {
    Connectivity().onConnectivityChanged.listen((results) {
      final wasOffline = !_isOnline;
      _isOnline = results.any((r) => r != ConnectivityResult.none);
      if (wasOffline && _isOnline) {
        _onReconnect();
      }
    });
  }

  void _onReconnect() {
    debugPrint('[OfflineService] Connection restored. Processing sync queue...');
    _processSyncQueue();
  }

  Future<void> checkConnectivity() async {
    final results = await Connectivity().checkConnectivity();
    _isOnline = results.any((r) => r != ConnectivityResult.none);
  }

  Future<void> cacheData(String key, dynamic data) async {
    if (_prefs == null) return;
    await _prefs!.setString(
      '$_keyCachedData$key',
      jsonEncode(data),
    );
    debugPrint('[OfflineService] Cached data for key: $key');
  }

  T? getCachedData<T>(String key, T Function(dynamic) fromJson) {
    if (_prefs == null) return null;
    final cached = _prefs!.getString('$_keyCachedData$key');
    if (cached == null) return null;
    try {
      final decoded = jsonDecode(cached);
      if (decoded is List && T.toString().contains('List')) {
        return decoded.map((e) => fromJson(e)).toList() as T;
      }
      return fromJson(decoded);
    } catch (e) {
      debugPrint('[OfflineService] Error reading cache: $e');
      return null;
    }
  }

  Future<void> addToSyncQueue(Map<String, dynamic> syncItem) async {
    _pendingSyncQueue.add({
      ...syncItem,
      'timestamp': DateTime.now().toIso8601String(),
      'sync_id': '${DateTime.now().millisecondsSinceEpoch}_${_pendingSyncQueue.length}',
    });
    await _saveSyncQueue();
    debugPrint('[OfflineService] Added to sync queue. Queue size: ${_pendingSyncQueue.length}');

    if (_isOnline) {
      _processSyncQueue();
    }
  }

  Future<void> _processSyncQueue() async {
    if (_pendingSyncQueue.isEmpty) return;
    debugPrint('[OfflineService] Processing ${_pendingSyncQueue.length} pending items...');

    final items = List<Map<String, dynamic>>.from(_pendingSyncQueue);
    final List<Map<String, dynamic>> failed = [];

    for (final item in items) {
      try {
        await _syncItem(item);
        _pendingSyncQueue.remove(item);
      } catch (e) {
        debugPrint('[OfflineService] Sync failed for item: $e');
        failed.add(item);
      }
    }

    await _saveSyncQueue();
    await _updateLastSyncTime();
    debugPrint('[OfflineService] Sync complete. Failed: ${failed.length}, Remaining: ${_pendingSyncQueue.length}');
  }

  Future<void> _syncItem(Map<String, dynamic> item) async {
    final endpoint = item['endpoint'] as String;
    final method = item['method'] as String? ?? 'POST';
    debugPrint('[OfflineService] Syncing $method $endpoint');
  }

  Future<void> _loadSyncQueue() async {
    if (_prefs == null) return;
    final data = _prefs!.getString(_keyPendingSync);
    if (data != null) {
      try {
        final list = jsonDecode(data) as List;
        _pendingSyncQueue.clear();
        _pendingSyncQueue.addAll(list.cast<Map<String, dynamic>>());
        debugPrint('[OfflineService] Loaded ${_pendingSyncQueue.length} pending sync items');
      } catch (e) {
        debugPrint('[OfflineService] Error loading sync queue: $e');
      }
    }
  }

  Future<void> _saveSyncQueue() async {
    if (_prefs == null) return;
    await _prefs!.setString(_keyPendingSync, jsonEncode(_pendingSyncQueue));
  }

  Future<DateTime?> getLastSyncTime() async {
    if (_prefs == null) return null;
    final time = _prefs!.getString(_keyLastSyncTime);
    return time != null ? DateTime.tryParse(time) : null;
  }

  Future<void> _updateLastSyncTime() async {
    if (_prefs == null) return;
    await _prefs!.setString(
        _keyLastSyncTime, DateTime.now().toIso8601String());
  }

  Future<void> clearCache() async {
    if (_prefs == null) return;
    final keys = _prefs!.getKeys().toList();
    for (final key in keys) {
      if (key.startsWith(_keyCachedData)) {
        await _prefs!.remove(key);
      }
    }
    debugPrint('[OfflineService] Cache cleared');
  }

  Future<void> clearSyncQueue() async {
    _pendingSyncQueue.clear();
    await _saveSyncQueue();
  }
}
