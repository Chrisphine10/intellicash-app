class MemberModel {
  final String id;
  final String firstName;
  final String? lastName;
  final String? name;
  final String? memberNo;
  final String? email;
  final String? phone;
  final String? countryCode;
  final String? gender;
  final String? dateOfBirth;
  final int? age;
  final String? nationalId;
  final String? passportNumber;
  final String? maritalStatus;
  final String? education;
  final String? occupation;
  final String? incomeLevel;
  final String? businessName;
  final String? householdSize;
  final String? address;
  final String? city;
  final String? state;
  final String? zip;
  final String? country;
  final String? county;
  final String? subCounty;
  final String? ward;
  final String? village;
  final double? latitude;
  final double? longitude;
  final String? photoUrl;
  final String? signatureUrl;
  final String? status;
  final String? groupId;
  final String? groupName;
  final String? organizationId;
  final String? organizationName;
  final String? branchId;
  final String? branchName;
  final String? registrationDate;
  final String? membershipType;
  final String? emergencyContactName;
  final String? emergencyContactPhone;
  final String? emergencyContactRelation;
  final String? nextOfKinName;
  final String? nextOfKinPhone;
  final String? nextOfKinRelation;
  final String? nextOfKinAddress;
  final List<MemberDocumentModel>? documents;
  final Map<String, dynamic>? kycData;
  final Map<String, dynamic>? metadata;
  final double? creditScore;
  final double? totalSavings;
  final double? totalShares;
  final double? totalLoans;
  final double? outstandingLoans;
  final int? attendanceRate;
  final String? createdBy;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  MemberModel({
    required this.id,
    required this.firstName,
    this.lastName,
    this.name,
    this.memberNo,
    this.email,
    this.phone,
    this.countryCode,
    this.gender,
    this.dateOfBirth,
    this.age,
    this.nationalId,
    this.passportNumber,
    this.maritalStatus,
    this.education,
    this.occupation,
    this.incomeLevel,
    this.businessName,
    this.householdSize,
    this.address,
    this.city,
    this.state,
    this.zip,
    this.country,
    this.county,
    this.subCounty,
    this.ward,
    this.village,
    this.latitude,
    this.longitude,
    this.photoUrl,
    this.signatureUrl,
    this.status,
    this.groupId,
    this.groupName,
    this.organizationId,
    this.organizationName,
    this.branchId,
    this.branchName,
    this.registrationDate,
    this.membershipType,
    this.emergencyContactName,
    this.emergencyContactPhone,
    this.emergencyContactRelation,
    this.nextOfKinName,
    this.nextOfKinPhone,
    this.nextOfKinRelation,
    this.nextOfKinAddress,
    this.documents,
    this.kycData,
    this.metadata,
    this.creditScore,
    this.totalSavings,
    this.totalShares,
    this.totalLoans,
    this.outstandingLoans,
    this.attendanceRate,
    this.createdBy,
    this.createdAt,
    this.updatedAt,
  });

  String get displayName =>
      name ?? '$firstName ${lastName ?? ''}'.trim();

  String get initials {
    final parts = displayName.split(' ');
    if (parts.length >= 2) {
      return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
    }
    return displayName[0].toUpperCase();
  }

  bool get isActive => status == 'active' || status == '1';

  String get statusText => isActive ? 'Active' : 'Inactive';

  factory MemberModel.fromJson(Map<String, dynamic> json) {
    return MemberModel(
      id: json['id']?.toString() ?? '',
      firstName: json['first_name'] ?? json['firstName'] ?? '',
      lastName: json['last_name'] ?? json['lastName'],
      name: json['name'],
      memberNo: json['member_no'] ?? json['memberNo'] ?? json['member_number'],
      email: json['email'],
      phone: json['phone'] ?? json['mobile'],
      countryCode: json['country_code'],
      gender: json['gender'],
      dateOfBirth: json['date_of_birth'] ?? json['dob'],
      age: json['age'],
      nationalId: json['national_id'] ?? json['id_number'] ?? json['idNumber'],
      passportNumber: json['passport_number'],
      maritalStatus: json['marital_status'],
      education: json['education'],
      occupation: json['occupation'],
      incomeLevel: json['income_level'],
      businessName: json['business_name'],
      householdSize: json['household_size']?.toString(),
      address: json['address'],
      city: json['city'],
      state: json['state'],
      zip: json['zip'],
      country: json['country'],
      county: json['county'],
      subCounty: json['sub_county'],
      ward: json['ward'],
      village: json['village'],
      latitude: (json['latitude'] as num?)?.toDouble(),
      longitude: (json['longitude'] as num?)?.toDouble(),
      photoUrl: json['photo_url'] ?? json['photo'],
      signatureUrl: json['signature_url'],
      status: json['status']?.toString() ?? 'active',
      groupId: json['group_id']?.toString(),
      groupName: json['group_name'],
      organizationId: json['organization_id']?.toString(),
      organizationName: json['organization_name'],
      branchId: json['branch_id']?.toString(),
      branchName: json['branch_name'] ?? (json['branch'] is Map ? json['branch']['name'] : null),
      registrationDate: json['registration_date'],
      membershipType: json['membership_type'],
      emergencyContactName: json['emergency_contact_name'],
      emergencyContactPhone: json['emergency_contact_phone'],
      emergencyContactRelation: json['emergency_contact_relation'],
      nextOfKinName: json['next_of_kin_name'],
      nextOfKinPhone: json['next_of_kin_phone'],
      nextOfKinRelation: json['next_of_kin_relation'],
      nextOfKinAddress: json['next_of_kin_address'],
      documents: (json['documents'] as List?)
          ?.map((d) => MemberDocumentModel.fromJson(d))
          .toList(),
      kycData: json['kyc_data'],
      metadata: json['metadata'],
      creditScore: (json['credit_score'] as num?)?.toDouble(),
      totalSavings: (json['total_savings'] as num?)?.toDouble(),
      totalShares: (json['total_shares'] as num?)?.toDouble(),
      totalLoans: (json['total_loans'] as num?)?.toDouble(),
      outstandingLoans: (json['outstanding_loans'] as num?)?.toDouble(),
      attendanceRate: json['attendance_rate'],
      createdBy: json['created_by']?.toString(),
      createdAt: json['created_at'] != null
          ? DateTime.tryParse(json['created_at'])
          : null,
      updatedAt: json['updated_at'] != null
          ? DateTime.tryParse(json['updated_at'])
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'first_name': firstName,
      'last_name': lastName,
      'name': name,
      'member_no': memberNo,
      'email': email,
      'phone': phone,
      'country_code': countryCode,
      'gender': gender,
      'date_of_birth': dateOfBirth,
      'age': age,
      'national_id': nationalId,
      'passport_number': passportNumber,
      'marital_status': maritalStatus,
      'education': education,
      'occupation': occupation,
      'income_level': incomeLevel,
      'business_name': businessName,
      'household_size': householdSize,
      'address': address,
      'city': city,
      'state': state,
      'zip': zip,
      'country': country,
      'county': county,
      'sub_county': subCounty,
      'ward': ward,
      'village': village,
      'latitude': latitude,
      'longitude': longitude,
      'photo_url': photoUrl,
      'signature_url': signatureUrl,
      'status': status,
      'group_id': groupId,
      'group_name': groupName,
      'organization_id': organizationId,
      'organization_name': organizationName,
      'branch_id': branchId,
      'registration_date': registrationDate,
      'membership_type': membershipType,
      'emergency_contact_name': emergencyContactName,
      'emergency_contact_phone': emergencyContactPhone,
      'emergency_contact_relation': emergencyContactRelation,
      'next_of_kin_name': nextOfKinName,
      'next_of_kin_phone': nextOfKinPhone,
      'next_of_kin_relation': nextOfKinRelation,
      'next_of_kin_address': nextOfKinAddress,
      'documents': documents?.map((d) => d.toJson()).toList(),
      'kyc_data': kycData,
      'metadata': metadata,
      'credit_score': creditScore,
      'total_savings': totalSavings,
      'total_shares': totalShares,
      'total_loans': totalLoans,
      'outstanding_loans': outstandingLoans,
      'attendance_rate': attendanceRate,
      'created_by': createdBy,
      'created_at': createdAt?.toIso8601String(),
      'updated_at': updatedAt?.toIso8601String(),
    };
  }
}

class MemberDocumentModel {
  final String? id;
  final String? type;
  final String? name;
  final String? url;
  final String? status;
  final DateTime? uploadedAt;

  MemberDocumentModel({
    this.id,
    this.type,
    this.name,
    this.url,
    this.status,
    this.uploadedAt,
  });

  factory MemberDocumentModel.fromJson(Map<String, dynamic> json) {
    return MemberDocumentModel(
      id: json['id']?.toString(),
      type: json['type'],
      name: json['name'] ?? json['file_name'],
      url: json['url'] ?? json['file_url'],
      status: json['status'],
      uploadedAt: json['uploaded_at'] != null
          ? DateTime.tryParse(json['uploaded_at'])
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'type': type,
      'name': name,
      'url': url,
      'status': status,
      'uploaded_at': uploadedAt?.toIso8601String(),
    };
  }
}
