enum UserRole {
  superAdmin,
  organizationAdmin,
  partner,
  countyManager,
  fieldOfficer,
  trainer,
  chairperson,
  secretary,
  treasurer,
  member,
  auditor,
  donor,
  bankOfficer,
  governmentOfficer,
  apiClient,
}

enum UserStatus { active, inactive, suspended, pending }

class UserModel {
  final String id;
  final String? email;
  final String? phone;
  final String? countryCode;
  final String firstName;
  final String? lastName;
  final String? displayName;
  final UserRole role;
  final UserStatus status;
  final String? organizationId;
  final String? organizationName;
  final String? groupId;
  final String? groupName;
  final String? photoUrl;
  final bool emailVerified;
  final bool phoneVerified;
  final bool mfaEnabled;
  final String? timezone;
  final String? locale;
  final Map<String, dynamic>? permissions;
  final Map<String, dynamic>? metadata;
  final DateTime? lastLoginAt;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  UserModel({
    required this.id,
    this.email,
    this.phone,
    this.countryCode,
    required this.firstName,
    this.lastName,
    this.displayName,
    this.role = UserRole.member,
    this.status = UserStatus.active,
    this.organizationId,
    this.organizationName,
    this.groupId,
    this.groupName,
    this.photoUrl,
    this.emailVerified = false,
    this.phoneVerified = false,
    this.mfaEnabled = false,
    this.timezone,
    this.locale,
    this.permissions,
    this.metadata,
    this.lastLoginAt,
    this.createdAt,
    this.updatedAt,
  });

  String get fullName =>
      displayName ?? '$firstName ${lastName ?? ''}'.trim();

  String get initials {
    final parts = fullName.split(' ');
    if (parts.length >= 2) {
      return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
    }
    return fullName[0].toUpperCase();
  }

  bool get isActive => status == UserStatus.active;

  String get statusText {
    switch (status) {
      case UserStatus.active:
        return 'Active';
      case UserStatus.inactive:
        return 'Inactive';
      case UserStatus.suspended:
        return 'Suspended';
      case UserStatus.pending:
        return 'Pending';
    }
  }

  String get roleText {
    switch (role) {
      case UserRole.superAdmin:
        return 'Super Admin';
      case UserRole.organizationAdmin:
        return 'Organization Admin';
      case UserRole.partner:
        return 'Partner';
      case UserRole.countyManager:
        return 'County Manager';
      case UserRole.fieldOfficer:
        return 'Field Officer';
      case UserRole.trainer:
        return 'Trainer';
      case UserRole.chairperson:
        return 'Chairperson';
      case UserRole.secretary:
        return 'Secretary';
      case UserRole.treasurer:
        return 'Treasurer';
      case UserRole.member:
        return 'Member';
      case UserRole.auditor:
        return 'Auditor';
      case UserRole.donor:
        return 'Donor';
      case UserRole.bankOfficer:
        return 'Bank Officer';
      case UserRole.governmentOfficer:
        return 'Government Officer';
      case UserRole.apiClient:
        return 'API Client';
    }
  }

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['id']?.toString() ?? '',
      email: json['email'],
      phone: json['phone'],
      countryCode: json['country_code'],
      firstName: json['first_name'] ?? json['firstName'] ?? '',
      lastName: json['last_name'] ?? json['lastName'],
      displayName: json['display_name'] ?? json['displayName'] ?? json['name'],
      role: _parseRole(json['role']),
      status: _parseStatus(json['status']),
      organizationId: json['organization_id']?.toString(),
      organizationName: json['organization_name'],
      groupId: json['group_id']?.toString(),
      groupName: json['group_name'],
      photoUrl: json['photo_url'] ?? json['avatar'],
      emailVerified: json['email_verified'] == true,
      phoneVerified: json['phone_verified'] == true,
      mfaEnabled: json['mfa_enabled'] == true || json['two_factor_enabled'] == true,
      timezone: json['timezone'],
      locale: json['locale'],
      permissions: json['permissions'],
      metadata: json['metadata'],
      lastLoginAt: json['last_login_at'] != null
          ? DateTime.tryParse(json['last_login_at'])
          : null,
      createdAt: json['created_at'] != null
          ? DateTime.tryParse(json['created_at'])
          : null,
      updatedAt: json['updated_at'] != null
          ? DateTime.tryParse(json['updated_at'])
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'email': email,
      'phone': phone,
      'country_code': countryCode,
      'first_name': firstName,
      'last_name': lastName,
      'display_name': displayName,
      'role': role.name,
      'status': status.name,
      'organization_id': organizationId,
      'organization_name': organizationName,
      'group_id': groupId,
      'group_name': groupName,
      'photo_url': photoUrl,
      'email_verified': emailVerified,
      'phone_verified': phoneVerified,
      'mfa_enabled': mfaEnabled,
      'timezone': timezone,
      'locale': locale,
      'permissions': permissions,
      'metadata': metadata,
      'last_login_at': lastLoginAt?.toIso8601String(),
      'created_at': createdAt?.toIso8601String(),
      'updated_at': updatedAt?.toIso8601String(),
    };
  }

  static UserRole _parseRole(dynamic role) {
    if (role == null) return UserRole.member;
    final str = role.toString().toLowerCase();
    switch (str) {
      case 'super_admin':
      case 'superadmin':
        return UserRole.superAdmin;
      case 'organization_admin':
      case 'org_admin':
      case 'admin':
        return UserRole.organizationAdmin;
      case 'partner':
        return UserRole.partner;
      case 'county_manager':
      case 'countymanager':
        return UserRole.countyManager;
      case 'field_officer':
      case 'fieldofficer':
        return UserRole.fieldOfficer;
      case 'trainer':
        return UserRole.trainer;
      case 'chairperson':
        return UserRole.chairperson;
      case 'secretary':
        return UserRole.secretary;
      case 'treasurer':
        return UserRole.treasurer;
      case 'member':
        return UserRole.member;
      case 'auditor':
        return UserRole.auditor;
      case 'donor':
        return UserRole.donor;
      case 'bank_officer':
      case 'bankofficer':
        return UserRole.bankOfficer;
      case 'government_officer':
      case 'governmentofficer':
        return UserRole.governmentOfficer;
      case 'api_client':
      case 'apiclient':
        return UserRole.apiClient;
      default:
        return UserRole.member;
    }
  }

  static UserStatus _parseStatus(dynamic status) {
    if (status == null) return UserStatus.active;
    final str = status.toString().toLowerCase();
    switch (str) {
      case 'active':
      case '1':
      case 'true':
        return UserStatus.active;
      case 'inactive':
      case '0':
      case 'false':
        return UserStatus.inactive;
      case 'suspended':
        return UserStatus.suspended;
      case 'pending':
        return UserStatus.pending;
      default:
        return UserStatus.active;
    }
  }
}
