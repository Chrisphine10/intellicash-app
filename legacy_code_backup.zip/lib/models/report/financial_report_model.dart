class CashbookEntryModel {
  final String id;
  final String? groupId;
  final DateTime? date;
  final String? description;
  final String? transactionType;
  final double? receipts;
  final double? payments;
  final double? balance;
  final String? category;
  final String? reference;
  final String? createdBy;

  CashbookEntryModel({
    required this.id,
    this.groupId,
    this.date,
    this.description,
    this.transactionType,
    this.receipts,
    this.payments,
    this.balance,
    this.category,
    this.reference,
    this.createdBy,
  });

  factory CashbookEntryModel.fromJson(Map<String, dynamic> json) {
    return CashbookEntryModel(
      id: json['id']?.toString() ?? '',
      groupId: json['group_id']?.toString(),
      date: json['date'] != null ? DateTime.tryParse(json['date']) : null,
      description: json['description'],
      transactionType: json['transaction_type'],
      receipts: (json['receipts'] as num?)?.toDouble(),
      payments: (json['payments'] as num?)?.toDouble(),
      balance: (json['balance'] as num?)?.toDouble(),
      category: json['category'],
      reference: json['reference'],
      createdBy: json['created_by']?.toString(),
    );
  }
}

class GeneralLedgerEntryModel {
  final String id;
  final String? accountCode;
  final String? accountName;
  final DateTime? date;
  final String? description;
  final double? debit;
  final double? credit;
  final double? balance;
  final String? reference;

  GeneralLedgerEntryModel({
    required this.id,
    this.accountCode,
    this.accountName,
    this.date,
    this.description,
    this.debit,
    this.credit,
    this.balance,
    this.reference,
  });

  factory GeneralLedgerEntryModel.fromJson(Map<String, dynamic> json) {
    return GeneralLedgerEntryModel(
      id: json['id']?.toString() ?? '',
      accountCode: json['account_code'],
      accountName: json['account_name'],
      date: json['date'] != null ? DateTime.tryParse(json['date']) : null,
      description: json['description'],
      debit: (json['debit'] as num?)?.toDouble(),
      credit: (json['credit'] as num?)?.toDouble(),
      balance: (json['balance'] as num?)?.toDouble(),
      reference: json['reference'],
    );
  }
}

class ChartOfAccountModel {
  final String id;
  final String? code;
  final String? name;
  final String? type;
  final String? category;
  final String? subCategory;
  final double? balance;
  final String? description;
  final bool isActive;

  ChartOfAccountModel({
    required this.id,
    this.code,
    this.name,
    this.type,
    this.category,
    this.subCategory,
    this.balance,
    this.description,
    this.isActive = true,
  });

  factory ChartOfAccountModel.fromJson(Map<String, dynamic> json) {
    return ChartOfAccountModel(
      id: json['id']?.toString() ?? '',
      code: json['code'],
      name: json['name'],
      type: json['type'],
      category: json['category'],
      subCategory: json['sub_category'],
      balance: (json['balance'] as num?)?.toDouble(),
      description: json['description'],
      isActive: json['is_active'] == true,
    );
  }
}

class TrialBalanceModel {
  final String? accountCode;
  final String? accountName;
  final double? debitBalance;
  final double? creditBalance;

  TrialBalanceModel({
    this.accountCode,
    this.accountName,
    this.debitBalance,
    this.creditBalance,
  });

  factory TrialBalanceModel.fromJson(Map<String, dynamic> json) {
    return TrialBalanceModel(
      accountCode: json['account_code'],
      accountName: json['account_name'],
      debitBalance: (json['debit_balance'] as num?)?.toDouble(),
      creditBalance: (json['credit_balance'] as num?)?.toDouble(),
    );
  }
}

class IncomeStatementModel {
  final String? category;
  final String? subCategory;
  final double? amount;
  final String? type;

  IncomeStatementModel({
    this.category,
    this.subCategory,
    this.amount,
    this.type,
  });

  factory IncomeStatementModel.fromJson(Map<String, dynamic> json) {
    return IncomeStatementModel(
      category: json['category'],
      subCategory: json['sub_category'],
      amount: (json['amount'] as num?)?.toDouble(),
      type: json['type'],
    );
  }
}

class BalanceSheetModel {
  final String? category;
  final String? subCategory;
  final double? amount;
  final String? type;

  BalanceSheetModel({
    this.category,
    this.subCategory,
    this.amount,
    this.type,
  });

  factory BalanceSheetModel.fromJson(Map<String, dynamic> json) {
    return BalanceSheetModel(
      category: json['category'],
      subCategory: json['sub_category'],
      amount: (json['amount'] as num?)?.toDouble(),
      type: json['type'],
    );
  }
}
