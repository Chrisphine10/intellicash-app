class ReportModel {
  final String id;
  final String? name;
  final String? type;
  final String? format;
  final String? period;
  final String? status;
  final String? groupId;
  final String? groupName;
  final String? organizationId;
  final String? generatedBy;
  final String? generatedByName;
  final String? fileUrl;
  final String? fileSize;
  final Map<String, dynamic>? data;
  final Map<String, dynamic>? filters;
  final Map<String, dynamic>? metadata;
  final DateTime? generatedAt;
  final DateTime? createdAt;

  ReportModel({
    required this.id,
    this.name,
    this.type,
    this.format,
    this.period,
    this.status,
    this.groupId,
    this.groupName,
    this.organizationId,
    this.generatedBy,
    this.generatedByName,
    this.fileUrl,
    this.fileSize,
    this.data,
    this.filters,
    this.metadata,
    this.generatedAt,
    this.createdAt,
  });

  factory ReportModel.fromJson(Map<String, dynamic> json) {
    return ReportModel(
      id: json['id']?.toString() ?? '',
      name: json['name'],
      type: json['type'],
      format: json['format'],
      period: json['period'],
      status: json['status'],
      groupId: json['group_id']?.toString(),
      groupName: json['group_name'],
      organizationId: json['organization_id']?.toString(),
      generatedBy: json['generated_by']?.toString(),
      generatedByName: json['generated_by_name'],
      fileUrl: json['file_url'],
      fileSize: json['file_size']?.toString(),
      data: json['data'],
      filters: json['filters'],
      metadata: json['metadata'],
      generatedAt: json['generated_at'] != null
          ? DateTime.tryParse(json['generated_at'])
          : null,
      createdAt: json['created_at'] != null
          ? DateTime.tryParse(json['created_at'])
          : null,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'type': type,
        'format': format,
        'period': period,
        'status': status,
        'group_id': groupId,
        'group_name': groupName,
        'organization_id': organizationId,
        'generated_by': generatedBy,
        'generated_by_name': generatedByName,
        'file_url': fileUrl,
        'file_size': fileSize,
        'data': data,
        'filters': filters,
        'metadata': metadata,
        'generated_at': generatedAt?.toIso8601String(),
        'created_at': createdAt?.toIso8601String(),
      };
}

class DashboardSummaryModel {
  final int totalGroups;
  final int activeGroups;
  final int totalMembers;
  final int activeMembers;
  final int totalMeetings;
  final double totalSavings;
  final double totalShares;
  final double totalLoans;
  final double outstandingLoans;
  final double totalSocialFund;
  final double totalFines;
  final double totalIncome;
  final double totalExpenses;
  final double totalBankBalance;
  final double cashAtHand;
  final int activeLoanCount;
  final int defaultedLoanCount;
  final double portfolioAtRisk;
  final double recoveryRate;
  final double savingsGrowthRate;
  final double loanGrowthRate;

  DashboardSummaryModel({
    this.totalGroups = 0,
    this.activeGroups = 0,
    this.totalMembers = 0,
    this.activeMembers = 0,
    this.totalMeetings = 0,
    this.totalSavings = 0.0,
    this.totalShares = 0.0,
    this.totalLoans = 0.0,
    this.outstandingLoans = 0.0,
    this.totalSocialFund = 0.0,
    this.totalFines = 0.0,
    this.totalIncome = 0.0,
    this.totalExpenses = 0.0,
    this.totalBankBalance = 0.0,
    this.cashAtHand = 0.0,
    this.activeLoanCount = 0,
    this.defaultedLoanCount = 0,
    this.portfolioAtRisk = 0.0,
    this.recoveryRate = 0.0,
    this.savingsGrowthRate = 0.0,
    this.loanGrowthRate = 0.0,
  });

  factory DashboardSummaryModel.fromJson(Map<String, dynamic> json) {
    return DashboardSummaryModel(
      totalGroups: json['total_groups'] ?? json['totalGroups'] ?? 0,
      activeGroups: json['active_groups'] ?? json['activeGroups'] ?? 0,
      totalMembers: json['total_members'] ?? json['totalMembers'] ?? 0,
      activeMembers: json['active_members'] ?? json['activeMembers'] ?? 0,
      totalMeetings: json['total_meetings'] ?? json['totalMeetings'] ?? 0,
      totalSavings: (json['total_savings'] as num?)?.toDouble() ?? 0.0,
      totalShares: (json['total_shares'] as num?)?.toDouble() ?? 0.0,
      totalLoans: (json['total_loans'] as num?)?.toDouble() ?? 0.0,
      outstandingLoans:
          (json['outstanding_loans'] as num?)?.toDouble() ?? 0.0,
      totalSocialFund:
          (json['total_social_fund'] as num?)?.toDouble() ?? 0.0,
      totalFines: (json['total_fines'] as num?)?.toDouble() ?? 0.0,
      totalIncome: (json['total_income'] as num?)?.toDouble() ?? 0.0,
      totalExpenses: (json['total_expenses'] as num?)?.toDouble() ?? 0.0,
      totalBankBalance:
          (json['total_bank_balance'] as num?)?.toDouble() ?? 0.0,
      cashAtHand: (json['cash_at_hand'] as num?)?.toDouble() ?? 0.0,
      activeLoanCount: json['active_loan_count'] ?? 0,
      defaultedLoanCount: json['defaulted_loan_count'] ?? 0,
      portfolioAtRisk:
          (json['portfolio_at_risk'] as num?)?.toDouble() ?? 0.0,
      recoveryRate: (json['recovery_rate'] as num?)?.toDouble() ?? 0.0,
      savingsGrowthRate:
          (json['savings_growth_rate'] as num?)?.toDouble() ?? 0.0,
      loanGrowthRate:
          (json['loan_growth_rate'] as num?)?.toDouble() ?? 0.0,
    );
  }
}
