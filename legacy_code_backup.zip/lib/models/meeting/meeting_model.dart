class MeetingModel {
  final String id;
  final String? groupId;
  final String? groupName;
  final String? meetingNumber;
  final String? title;
  final String? meetingType;
  final String? status;
  final DateTime? scheduledDate;
  final DateTime? startTime;
  final DateTime? endTime;
  final String? venue;
  final double? latitude;
  final double? longitude;
  final String? agenda;
  final String? minutes;
  final String? chairmanRemarks;
  final String? secretaryRemarks;
  final String? treasurerReport;
  final int? expectedAttendance;
  final int? actualAttendance;
  final double? openingBalance;
  final double? totalSavings;
  final double? totalShares;
  final double? totalLoanRepayments;
  final double? totalLoanDisbursements;
  final double? totalFines;
  final double? totalSocialFund;
  final double? totalExpenses;
  final double? totalIncome;
  final double? closingBalance;
  final double? cashAtHand;
  final double? cashAtBank;
  final String? createdBy;
  final String? createdByName;
  final List<MeetingAgendaModel>? agendaItems;
  final List<MeetingResolutionModel>? resolutions;
  final List<MeetingAttendanceModel>? attendance;
  final List<MeetingSignatureModel>? signatures;
  final Map<String, dynamic>? metadata;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  MeetingModel({
    required this.id,
    this.groupId,
    this.groupName,
    this.meetingNumber,
    this.title,
    this.meetingType,
    this.status,
    this.scheduledDate,
    this.startTime,
    this.endTime,
    this.venue,
    this.latitude,
    this.longitude,
    this.agenda,
    this.minutes,
    this.chairmanRemarks,
    this.secretaryRemarks,
    this.treasurerReport,
    this.expectedAttendance,
    this.actualAttendance,
    this.openingBalance,
    this.totalSavings,
    this.totalShares,
    this.totalLoanRepayments,
    this.totalLoanDisbursements,
    this.totalFines,
    this.totalSocialFund,
    this.totalExpenses,
    this.totalIncome,
    this.closingBalance,
    this.cashAtHand,
    this.cashAtBank,
    this.createdBy,
    this.createdByName,
    this.agendaItems,
    this.resolutions,
    this.attendance,
    this.signatures,
    this.metadata,
    this.createdAt,
    this.updatedAt,
  });

  String get displayTitle => title ?? 'Meeting #${meetingNumber ?? id}';

  bool get isCompleted => status == 'completed';
  bool get isInProgress => status == 'in_progress';
  bool get isScheduled => status == 'scheduled';

  factory MeetingModel.fromJson(Map<String, dynamic> json) {
    return MeetingModel(
      id: json['id']?.toString() ?? '',
      groupId: json['group_id']?.toString(),
      groupName: json['group_name'],
      meetingNumber: json['meeting_number']?.toString(),
      title: json['title'],
      meetingType: json['meeting_type'],
      status: json['status']?.toString() ?? 'scheduled',
      scheduledDate: json['scheduled_date'] != null
          ? DateTime.tryParse(json['scheduled_date'])
          : null,
      startTime: json['start_time'] != null
          ? DateTime.tryParse(json['start_time'])
          : null,
      endTime: json['end_time'] != null
          ? DateTime.tryParse(json['end_time'])
          : null,
      venue: json['venue'],
      latitude: (json['latitude'] as num?)?.toDouble(),
      longitude: (json['longitude'] as num?)?.toDouble(),
      agenda: json['agenda'],
      minutes: json['minutes'],
      chairmanRemarks: json['chairman_remarks'],
      secretaryRemarks: json['secretary_remarks'],
      treasurerReport: json['treasurer_report'],
      expectedAttendance: json['expected_attendance'],
      actualAttendance: json['actual_attendance'],
      openingBalance: (json['opening_balance'] as num?)?.toDouble(),
      totalSavings: (json['total_savings'] as num?)?.toDouble(),
      totalShares: (json['total_shares'] as num?)?.toDouble(),
      totalLoanRepayments: (json['total_loan_repayments'] as num?)?.toDouble(),
      totalLoanDisbursements:
          (json['total_loan_disbursements'] as num?)?.toDouble(),
      totalFines: (json['total_fines'] as num?)?.toDouble(),
      totalSocialFund: (json['total_social_fund'] as num?)?.toDouble(),
      totalExpenses: (json['total_expenses'] as num?)?.toDouble(),
      totalIncome: (json['total_income'] as num?)?.toDouble(),
      closingBalance: (json['closing_balance'] as num?)?.toDouble(),
      cashAtHand: (json['cash_at_hand'] as num?)?.toDouble(),
      cashAtBank: (json['cash_at_bank'] as num?)?.toDouble(),
      createdBy: json['created_by']?.toString(),
      createdByName: json['created_by_name'],
      agendaItems: (json['agenda_items'] as List?)
          ?.map((a) => MeetingAgendaModel.fromJson(a))
          .toList(),
      resolutions: (json['resolutions'] as List?)
          ?.map((r) => MeetingResolutionModel.fromJson(r))
          .toList(),
      attendance: (json['attendance'] as List?)
          ?.map((a) => MeetingAttendanceModel.fromJson(a))
          .toList(),
      signatures: (json['signatures'] as List?)
          ?.map((s) => MeetingSignatureModel.fromJson(s))
          .toList(),
      metadata: json['metadata'],
      createdAt: json['created_at'] != null
          ? DateTime.tryParse(json['created_at'])
          : null,
      updatedAt: json['updated_at'] != null
          ? DateTime.tryParse(json['updated_at'])
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'group_id': groupId,
      'group_name': groupName,
      'meeting_number': meetingNumber,
      'title': title,
      'meeting_type': meetingType,
      'status': status,
      'scheduled_date': scheduledDate?.toIso8601String(),
      'start_time': startTime?.toIso8601String(),
      'end_time': endTime?.toIso8601String(),
      'venue': venue,
      'latitude': latitude,
      'longitude': longitude,
      'agenda': agenda,
      'minutes': minutes,
      'chairman_remarks': chairmanRemarks,
      'secretary_remarks': secretaryRemarks,
      'treasurer_report': treasurerReport,
      'expected_attendance': expectedAttendance,
      'actual_attendance': actualAttendance,
      'opening_balance': openingBalance,
      'total_savings': totalSavings,
      'total_shares': totalShares,
      'total_loan_repayments': totalLoanRepayments,
      'total_loan_disbursements': totalLoanDisbursements,
      'total_fines': totalFines,
      'total_social_fund': totalSocialFund,
      'total_expenses': totalExpenses,
      'total_income': totalIncome,
      'closing_balance': closingBalance,
      'cash_at_hand': cashAtHand,
      'cash_at_bank': cashAtBank,
      'created_by': createdBy,
      'agenda_items': agendaItems?.map((a) => a.toJson()).toList(),
      'resolutions': resolutions?.map((r) => r.toJson()).toList(),
      'attendance': attendance?.map((a) => a.toJson()).toList(),
      'signatures': signatures?.map((s) => s.toJson()).toList(),
      'metadata': metadata,
      'created_at': createdAt?.toIso8601String(),
      'updated_at': updatedAt?.toIso8601String(),
    };
  }
}

class MeetingAgendaModel {
  final String? id;
  final String? title;
  final String? description;
  final int? order;
  final String? status;
  final String? discussion;

  MeetingAgendaModel({
    this.id,
    this.title,
    this.description,
    this.order,
    this.status,
    this.discussion,
  });

  factory MeetingAgendaModel.fromJson(Map<String, dynamic> json) {
    return MeetingAgendaModel(
      id: json['id']?.toString(),
      title: json['title'],
      description: json['description'],
      order: json['order'],
      status: json['status'],
      discussion: json['discussion'],
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'description': description,
        'order': order,
        'status': status,
        'discussion': discussion,
      };
}

class MeetingResolutionModel {
  final String? id;
  final String? title;
  final String? description;
  final String? proposedBy;
  final String? secondedBy;
  final int? votesFor;
  final int? votesAgainst;
  final int? abstentions;
  final String? status;

  MeetingResolutionModel({
    this.id,
    this.title,
    this.description,
    this.proposedBy,
    this.secondedBy,
    this.votesFor,
    this.votesAgainst,
    this.abstentions,
    this.status,
  });

  factory MeetingResolutionModel.fromJson(Map<String, dynamic> json) {
    return MeetingResolutionModel(
      id: json['id']?.toString(),
      title: json['title'],
      description: json['description'],
      proposedBy: json['proposed_by'],
      secondedBy: json['seconded_by'],
      votesFor: json['votes_for'],
      votesAgainst: json['votes_against'],
      abstentions: json['abstentions'],
      status: json['status'],
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'description': description,
        'proposed_by': proposedBy,
        'seconded_by': secondedBy,
        'votes_for': votesFor,
        'votes_against': votesAgainst,
        'abstentions': abstentions,
        'status': status,
      };
}

class MeetingAttendanceModel {
  final String? id;
  final String? memberId;
  final String? memberName;
  final String? memberNo;
  final bool present;
  final String? arrivalTime;
  final String? departureTime;
  final String? status;

  MeetingAttendanceModel({
    this.id,
    this.memberId,
    this.memberName,
    this.memberNo,
    this.present = false,
    this.arrivalTime,
    this.departureTime,
    this.status,
  });

  factory MeetingAttendanceModel.fromJson(Map<String, dynamic> json) {
    return MeetingAttendanceModel(
      id: json['id']?.toString(),
      memberId: json['member_id']?.toString(),
      memberName: json['member_name'],
      memberNo: json['member_no'],
      present: json['present'] == true || json['status'] == 'present',
      arrivalTime: json['arrival_time'],
      departureTime: json['departure_time'],
      status: json['status'] ?? (json['present'] == true ? 'present' : 'absent'),
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'member_id': memberId,
        'member_name': memberName,
        'member_no': memberNo,
        'present': present,
        'arrival_time': arrivalTime,
        'departure_time': departureTime,
        'status': status,
      };
}

class MeetingSignatureModel {
  final String? id;
  final String? userId;
  final String? memberId;
  final String? name;
  final String? role;
  final String? signatureData;
  final bool isDigital;
  final DateTime? signedAt;

  MeetingSignatureModel({
    this.id,
    this.userId,
    this.memberId,
    this.name,
    this.role,
    this.signatureData,
    this.isDigital = false,
    this.signedAt,
  });

  factory MeetingSignatureModel.fromJson(Map<String, dynamic> json) {
    return MeetingSignatureModel(
      id: json['id']?.toString(),
      userId: json['user_id']?.toString(),
      memberId: json['member_id']?.toString(),
      name: json['name'],
      role: json['role'],
      signatureData: json['signature_data'],
      isDigital: json['is_digital'] == true,
      signedAt: json['signed_at'] != null
          ? DateTime.tryParse(json['signed_at'])
          : null,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'user_id': userId,
        'member_id': memberId,
        'name': name,
        'role': role,
        'signature_data': signatureData,
        'is_digital': isDigital,
        'signed_at': signedAt?.toIso8601String(),
      };
}
