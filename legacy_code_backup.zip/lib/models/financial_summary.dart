class FinancialSummary {
  final int totalMembers;
  final int activeMembers;
  final double totalSavings;
  final double totalLoans;
  final double outstandingLoans;
  final int bankAccounts;
  final double totalBankBalance;

  FinancialSummary({
    required this.totalMembers,
    required this.activeMembers,
    required this.totalSavings,
    required this.totalLoans,
    required this.outstandingLoans,
    required this.bankAccounts,
    required this.totalBankBalance,
  });

  factory FinancialSummary.fromJson(Map<String, dynamic> json) {
    return FinancialSummary(
      totalMembers: json['total_members'] ?? 0,
      activeMembers: json['active_members'] ?? 0,
      totalSavings: (json['total_savings'] as num?)?.toDouble() ?? 0,
      totalLoans: (json['total_loans'] as num?)?.toDouble() ?? 0,
      outstandingLoans: (json['outstanding_loans'] as num?)?.toDouble() ?? 0,
      bankAccounts: json['bank_accounts'] ?? 0,
      totalBankBalance: (json['total_bank_balance'] as num?)?.toDouble() ?? 0,
    );
  }
}
