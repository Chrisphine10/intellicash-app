class LoanModel {
  final String id;
  final String? loanId;
  final String? loanProduct;
  final String? loanType;
  final String? memberId;
  final String? memberName;
  final String? memberNo;
  final String? groupId;
  final String? groupName;
  final String? organizationId;
  final double? appliedAmount;
  final double? approvedAmount;
  final double? disbursedAmount;
  final double? totalPayable;
  final double? totalPaid;
  final double? outstandingAmount;
  final double? interestRate;
  final String? interestMethod;
  final int? duration;
  final String? durationPeriod;
  final String? repaymentFrequency;
  final int? gracePeriod;
  final double? processingFee;
  final double? latePaymentFine;
  final String? currency;
  final String? status;
  final String? purpose;
  final String? firstPaymentDate;
  final String? releaseDate;
  final String? expectedMaturityDate;
  final String? completionDate;
  final String? approvedBy;
  final String? approvedByName;
  final String? disbursedBy;
  final String? createdBy;
  final String? createdByName;
  final String? rejectionReason;
  final String? notes;
  final List<LoanGuarantorModel>? guarantors;
  final List<LoanCollateralModel>? collateral;
  final List<LoanRepaymentModel>? repayments;
  final List<LoanScheduleModel>? schedule;
  final Map<String, dynamic>? metadata;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  LoanModel({
    required this.id,
    this.loanId,
    this.loanProduct,
    this.loanType,
    this.memberId,
    this.memberName,
    this.memberNo,
    this.groupId,
    this.groupName,
    this.organizationId,
    this.appliedAmount,
    this.approvedAmount,
    this.disbursedAmount,
    this.totalPayable,
    this.totalPaid,
    this.outstandingAmount,
    this.interestRate,
    this.interestMethod,
    this.duration,
    this.durationPeriod,
    this.repaymentFrequency,
    this.gracePeriod,
    this.processingFee,
    this.latePaymentFine,
    this.currency,
    this.status,
    this.purpose,
    this.firstPaymentDate,
    this.releaseDate,
    this.expectedMaturityDate,
    this.completionDate,
    this.approvedBy,
    this.approvedByName,
    this.disbursedBy,
    this.createdBy,
    this.createdByName,
    this.rejectionReason,
    this.notes,
    this.guarantors,
    this.collateral,
    this.repayments,
    this.schedule,
    this.metadata,
    this.createdAt,
    this.updatedAt,
  });

  double get repaymentProgress {
    if (totalPayable == null || totalPayable == 0) return 0.0;
    return (totalPaid! / totalPayable!).clamp(0.0, 1.0);
  }

  String get statusText {
    switch (status) {
      case 'draft':
        return 'Draft';
      case 'pending':
        return 'Pending';
      case 'approved':
        return 'Approved';
      case 'active':
        return 'Active';
      case 'completed':
        return 'Completed';
      case 'defaulted':
        return 'Defaulted';
      case 'written_off':
        return 'Written Off';
      case 'restructured':
        return 'Restructured';
      case 'rejected':
        return 'Rejected';
      case 'cancelled':
        return 'Cancelled';
      default:
        return status ?? 'Unknown';
    }
  }

  bool get isActive => status == 'active';
  bool get isPending => status == 'pending';
  bool get isCompleted => status == 'completed';
  bool get isDefaulted => status == 'defaulted';
  bool get isOverdue => status == 'active' &&
      (expectedMaturityDate != null &&
          DateTime.tryParse(expectedMaturityDate!)?.isBefore(DateTime.now()) == true);

  factory LoanModel.fromJson(Map<String, dynamic> json) {
    return LoanModel(
      id: json['id']?.toString() ?? '',
      loanId: json['loan_id']?.toString() ?? json['loanId'],
      loanProduct: json['loan_product'],
      loanType: json['loan_type'],
      memberId: json['member_id']?.toString(),
      memberName: json['member_name'],
      memberNo: json['member_no'],
      groupId: json['group_id']?.toString(),
      groupName: json['group_name'],
      organizationId: json['organization_id']?.toString(),
      appliedAmount: (json['applied_amount'] as num?)?.toDouble(),
      approvedAmount: (json['approved_amount'] as num?)?.toDouble(),
      disbursedAmount: (json['disbursed_amount'] as num?)?.toDouble(),
      totalPayable: (json['total_payable'] as num?)?.toDouble(),
      totalPaid: (json['total_paid'] as num?)?.toDouble(),
      outstandingAmount: (json['outstanding_amount'] as num?)?.toDouble(),
      interestRate: (json['interest_rate'] as num?)?.toDouble(),
      interestMethod: json['interest_method'],
      duration: json['duration'],
      durationPeriod: json['duration_period'],
      repaymentFrequency: json['repayment_frequency'],
      gracePeriod: json['grace_period'],
      processingFee: (json['processing_fee'] as num?)?.toDouble(),
      latePaymentFine: (json['late_payment_fine'] as num?)?.toDouble(),
      currency: json['currency'] ?? 'KES',
      status: json['status']?.toString() ?? 'pending',
      purpose: json['purpose'],
      firstPaymentDate: json['first_payment_date'],
      releaseDate: json['release_date'],
      expectedMaturityDate: json['expected_maturity_date'],
      completionDate: json['completion_date'],
      approvedBy: json['approved_by']?.toString(),
      approvedByName: json['approved_by_name'],
      disbursedBy: json['disbursed_by']?.toString(),
      createdBy: json['created_by']?.toString(),
      createdByName: json['created_by_name'],
      rejectionReason: json['rejection_reason'],
      notes: json['notes'],
      guarantors: (json['guarantors'] as List?)
          ?.map((g) => LoanGuarantorModel.fromJson(g))
          .toList(),
      collateral: (json['collateral'] as List?)
          ?.map((c) => LoanCollateralModel.fromJson(c))
          .toList(),
      repayments: (json['repayments'] as List?)
          ?.map((r) => LoanRepaymentModel.fromJson(r))
          .toList(),
      schedule: (json['schedule'] as List?)
          ?.map((s) => LoanScheduleModel.fromJson(s))
          .toList(),
      metadata: json['metadata'],
      createdAt: json['created_at'] != null
          ? DateTime.tryParse(json['created_at'])
          : null,
      updatedAt: json['updated_at'] != null
          ? DateTime.tryParse(json['updated_at'])
          : null,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'loan_id': loanId,
        'loan_product': loanProduct,
        'loan_type': loanType,
        'member_id': memberId,
        'member_name': memberName,
        'member_no': memberNo,
        'group_id': groupId,
        'group_name': groupName,
        'organization_id': organizationId,
        'applied_amount': appliedAmount,
        'approved_amount': approvedAmount,
        'disbursed_amount': disbursedAmount,
        'total_payable': totalPayable,
        'total_paid': totalPaid,
        'outstanding_amount': outstandingAmount,
        'interest_rate': interestRate,
        'interest_method': interestMethod,
        'duration': duration,
        'duration_period': durationPeriod,
        'repayment_frequency': repaymentFrequency,
        'grace_period': gracePeriod,
        'processing_fee': processingFee,
        'late_payment_fine': latePaymentFine,
        'currency': currency,
        'status': status,
        'purpose': purpose,
        'first_payment_date': firstPaymentDate,
        'release_date': releaseDate,
        'expected_maturity_date': expectedMaturityDate,
        'completion_date': completionDate,
        'approved_by': approvedBy,
        'approved_by_name': approvedByName,
        'disbursed_by': disbursedBy,
        'created_by': createdBy,
        'created_by_name': createdByName,
        'rejection_reason': rejectionReason,
        'notes': notes,
        'guarantors': guarantors?.map((g) => g.toJson()).toList(),
        'collateral': collateral?.map((c) => c.toJson()).toList(),
        'repayments': repayments?.map((r) => r.toJson()).toList(),
        'schedule': schedule?.map((s) => s.toJson()).toList(),
        'metadata': metadata,
        'created_at': createdAt?.toIso8601String(),
        'updated_at': updatedAt?.toIso8601String(),
      };
}

class LoanGuarantorModel {
  final String? id;
  final String? memberId;
  final String? memberName;
  final String? memberNo;
  final String? relationship;
  final double? guaranteedAmount;
  final String? status;
  final String? notes;

  LoanGuarantorModel({
    this.id,
    this.memberId,
    this.memberName,
    this.memberNo,
    this.relationship,
    this.guaranteedAmount,
    this.status,
    this.notes,
  });

  factory LoanGuarantorModel.fromJson(Map<String, dynamic> json) {
    return LoanGuarantorModel(
      id: json['id']?.toString(),
      memberId: json['member_id']?.toString(),
      memberName: json['member_name'],
      memberNo: json['member_no'],
      relationship: json['relationship'],
      guaranteedAmount: (json['guaranteed_amount'] as num?)?.toDouble(),
      status: json['status'],
      notes: json['notes'],
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'member_id': memberId,
        'member_name': memberName,
        'member_no': memberNo,
        'relationship': relationship,
        'guaranteed_amount': guaranteedAmount,
        'status': status,
        'notes': notes,
      };
}

class LoanCollateralModel {
  final String? id;
  final String? type;
  final String? description;
  final String? estimatedValue;
  final String? documents;
  final String? status;

  LoanCollateralModel({
    this.id,
    this.type,
    this.description,
    this.estimatedValue,
    this.documents,
    this.status,
  });

  factory LoanCollateralModel.fromJson(Map<String, dynamic> json) {
    return LoanCollateralModel(
      id: json['id']?.toString(),
      type: json['type'],
      description: json['description'],
      estimatedValue: json['estimated_value']?.toString(),
      documents: json['documents'],
      status: json['status'],
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'type': type,
        'description': description,
        'estimated_value': estimatedValue,
        'documents': documents,
        'status': status,
      };
}

class LoanRepaymentModel {
  final String id;
  final String? loanId;
  final String? memberId;
  final String? memberName;
  final double? amount;
  final double? principalPaid;
  final double? interestPaid;
  final double? penaltyPaid;
  final double? balanceAfter;
  final String? method;
  final String? status;
  final String? reference;
  final String? receiptNumber;
  final String? paymentMethod;
  final String? paymentReference;
  final String? notes;
  final DateTime? paymentDate;
  final DateTime? createdAt;

  LoanRepaymentModel({
    required this.id,
    this.loanId,
    this.memberId,
    this.memberName,
    this.amount,
    this.principalPaid,
    this.interestPaid,
    this.penaltyPaid,
    this.balanceAfter,
    this.method,
    this.status,
    this.reference,
    this.receiptNumber,
    this.paymentMethod,
    this.paymentReference,
    this.notes,
    this.paymentDate,
    this.createdAt,
  });

  factory LoanRepaymentModel.fromJson(Map<String, dynamic> json) {
    return LoanRepaymentModel(
      id: json['id']?.toString() ?? '',
      loanId: json['loan_id']?.toString(),
      memberId: json['member_id']?.toString(),
      memberName: json['member_name'],
      amount: (json['amount'] as num?)?.toDouble(),
      principalPaid: (json['principal_paid'] as num?)?.toDouble(),
      interestPaid: (json['interest_paid'] as num?)?.toDouble(),
      penaltyPaid: (json['penalty_paid'] as num?)?.toDouble(),
      balanceAfter: (json['balance_after'] as num?)?.toDouble(),
      method: json['method'],
      status: json['status']?.toString() ?? 'completed',
      reference: json['reference'],
      receiptNumber: json['receipt_number'],
      paymentMethod: json['payment_method'],
      paymentReference: json['payment_reference'],
      notes: json['notes'],
      paymentDate: json['payment_date'] != null
          ? DateTime.tryParse(json['payment_date'])
          : null,
      createdAt: json['created_at'] != null
          ? DateTime.tryParse(json['created_at'])
          : null,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'loan_id': loanId,
        'member_id': memberId,
        'member_name': memberName,
        'amount': amount,
        'principal_paid': principalPaid,
        'interest_paid': interestPaid,
        'penalty_paid': penaltyPaid,
        'balance_after': balanceAfter,
        'method': method,
        'status': status,
        'reference': reference,
        'receipt_number': receiptNumber,
        'payment_method': paymentMethod,
        'payment_reference': paymentReference,
        'notes': notes,
        'payment_date': paymentDate?.toIso8601String(),
        'created_at': createdAt?.toIso8601String(),
      };
}

class LoanScheduleModel {
  final String? id;
  final String? loanId;
  final int? installmentNo;
  final DateTime? dueDate;
  final double? principalAmount;
  final double? interestAmount;
  final double? totalAmount;
  final double? paidAmount;
  final double? balance;
  final String? status;
  final DateTime? paidDate;

  LoanScheduleModel({
    this.id,
    this.loanId,
    this.installmentNo,
    this.dueDate,
    this.principalAmount,
    this.interestAmount,
    this.totalAmount,
    this.paidAmount,
    this.balance,
    this.status,
    this.paidDate,
  });

  bool get isPaid => status == 'paid';
  bool get isOverdue => status == 'overdue';
  bool get isPending => status == 'pending';

  factory LoanScheduleModel.fromJson(Map<String, dynamic> json) {
    return LoanScheduleModel(
      id: json['id']?.toString(),
      loanId: json['loan_id']?.toString(),
      installmentNo: json['installment_no'],
      dueDate: json['due_date'] != null
          ? DateTime.tryParse(json['due_date'])
          : null,
      principalAmount: (json['principal_amount'] as num?)?.toDouble(),
      interestAmount: (json['interest_amount'] as num?)?.toDouble(),
      totalAmount: (json['total_amount'] as num?)?.toDouble(),
      paidAmount: (json['paid_amount'] as num?)?.toDouble(),
      balance: (json['balance'] as num?)?.toDouble(),
      status: json['status'],
      paidDate: json['paid_date'] != null
          ? DateTime.tryParse(json['paid_date'])
          : null,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'loan_id': loanId,
        'installment_no': installmentNo,
        'due_date': dueDate?.toIso8601String(),
        'principal_amount': principalAmount,
        'interest_amount': interestAmount,
        'total_amount': totalAmount,
        'paid_amount': paidAmount,
        'balance': balance,
        'status': status,
        'paid_date': paidDate?.toIso8601String(),
      };
}
