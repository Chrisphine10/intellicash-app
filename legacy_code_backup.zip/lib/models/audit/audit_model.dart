class AuditLogModel {
  final String id;
  final String? action;
  final String? entityType;
  final String? entityId;
  final String? description;
  final Map<String, dynamic>? oldValues;
  final Map<String, dynamic>? newValues;
  final String? userId;
  final String? userName;
  final String? userRole;
  final String? organizationId;
  final String? groupId;
  final String? ipAddress;
  final String? userAgent;
  final String? sessionId;
  final String? deviceInfo;
  final String? location;
  final String? status;
  final Map<String, dynamic>? metadata;
  final DateTime? createdAt;

  AuditLogModel({
    required this.id,
    this.action,
    this.entityType,
    this.entityId,
    this.description,
    this.oldValues,
    this.newValues,
    this.userId,
    this.userName,
    this.userRole,
    this.organizationId,
    this.groupId,
    this.ipAddress,
    this.userAgent,
    this.sessionId,
    this.deviceInfo,
    this.location,
    this.status,
    this.metadata,
    this.createdAt,
  });

  factory AuditLogModel.fromJson(Map<String, dynamic> json) {
    return AuditLogModel(
      id: json['id']?.toString() ?? '',
      action: json['action'],
      entityType: json['entity_type'],
      entityId: json['entity_id']?.toString(),
      description: json['description'],
      oldValues: json['old_values'],
      newValues: json['new_values'],
      userId: json['user_id']?.toString(),
      userName: json['user_name'],
      userRole: json['user_role'],
      organizationId: json['organization_id']?.toString(),
      groupId: json['group_id']?.toString(),
      ipAddress: json['ip_address'],
      userAgent: json['user_agent'],
      sessionId: json['session_id'],
      deviceInfo: json['device_info'],
      location: json['location'],
      status: json['status'],
      metadata: json['metadata'],
      createdAt: json['created_at'] != null
          ? DateTime.tryParse(json['created_at'])
          : null,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'action': action,
        'entity_type': entityType,
        'entity_id': entityId,
        'description': description,
        'old_values': oldValues,
        'new_values': newValues,
        'user_id': userId,
        'user_name': userName,
        'user_role': userRole,
        'organization_id': organizationId,
        'group_id': groupId,
        'ip_address': ipAddress,
        'user_agent': userAgent,
        'session_id': sessionId,
        'device_info': deviceInfo,
        'location': location,
        'status': status,
        'metadata': metadata,
        'created_at': createdAt?.toIso8601String(),
      };
}

class FinancialSummaryModel {
  final double totalSavings;
  final double totalShares;
  final double totalLoans;
  final double outstandingLoans;
  final double totalSocialFund;
  final double totalFines;
  final double totalIncome;
  final double totalExpenses;
  final double totalAssets;
  final double totalLiabilities;
  final double totalEquity;
  final double cashAtHand;
  final double cashAtBank;
  final double netIncome;
  final double portfolioAtRisk;
  final double recoveryRate;
  final double savingsGrowth;
  final double loanGrowth;

  FinancialSummaryModel({
    this.totalSavings = 0.0,
    this.totalShares = 0.0,
    this.totalLoans = 0.0,
    this.outstandingLoans = 0.0,
    this.totalSocialFund = 0.0,
    this.totalFines = 0.0,
    this.totalIncome = 0.0,
    this.totalExpenses = 0.0,
    this.totalAssets = 0.0,
    this.totalLiabilities = 0.0,
    this.totalEquity = 0.0,
    this.cashAtHand = 0.0,
    this.cashAtBank = 0.0,
    this.netIncome = 0.0,
    this.portfolioAtRisk = 0.0,
    this.recoveryRate = 0.0,
    this.savingsGrowth = 0.0,
    this.loanGrowth = 0.0,
  });

  factory FinancialSummaryModel.fromJson(Map<String, dynamic> json) {
    return FinancialSummaryModel(
      totalSavings: (json['total_savings'] as num?)?.toDouble() ?? 0.0,
      totalShares: (json['total_shares'] as num?)?.toDouble() ?? 0.0,
      totalLoans: (json['total_loans'] as num?)?.toDouble() ?? 0.0,
      outstandingLoans: (json['outstanding_loans'] as num?)?.toDouble() ?? 0.0,
      totalSocialFund: (json['total_social_fund'] as num?)?.toDouble() ?? 0.0,
      totalFines: (json['total_fines'] as num?)?.toDouble() ?? 0.0,
      totalIncome: (json['total_income'] as num?)?.toDouble() ?? 0.0,
      totalExpenses: (json['total_expenses'] as num?)?.toDouble() ?? 0.0,
      totalAssets: (json['total_assets'] as num?)?.toDouble() ?? 0.0,
      totalLiabilities: (json['total_liabilities'] as num?)?.toDouble() ?? 0.0,
      totalEquity: (json['total_equity'] as num?)?.toDouble() ?? 0.0,
      cashAtHand: (json['cash_at_hand'] as num?)?.toDouble() ?? 0.0,
      cashAtBank: (json['cash_at_bank'] as num?)?.toDouble() ?? 0.0,
      netIncome: (json['net_income'] as num?)?.toDouble() ?? 0.0,
      portfolioAtRisk: (json['portfolio_at_risk'] as num?)?.toDouble() ?? 0.0,
      recoveryRate: (json['recovery_rate'] as num?)?.toDouble() ?? 0.0,
      savingsGrowth: (json['savings_growth'] as num?)?.toDouble() ?? 0.0,
      loanGrowth: (json['loan_growth'] as num?)?.toDouble() ?? 0.0,
    );
  }
}
