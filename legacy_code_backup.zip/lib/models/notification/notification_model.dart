class NotificationModel {
  final String id;
  final String? title;
  final String? body;
  final String? type;
  final String? channel;
  final String? status;
  final String? recipientId;
  final String? recipientEmail;
  final String? recipientPhone;
  final String? groupId;
  final String? groupName;
  final String? organizationId;
  final String? referenceType;
  final String? referenceId;
  final Map<String, dynamic>? data;
  final bool isRead;
  final DateTime? readAt;
  final DateTime? scheduledAt;
  final DateTime? sentAt;
  final DateTime? createdAt;

  NotificationModel({
    required this.id,
    this.title,
    this.body,
    this.type,
    this.channel,
    this.status,
    this.recipientId,
    this.recipientEmail,
    this.recipientPhone,
    this.groupId,
    this.groupName,
    this.organizationId,
    this.referenceType,
    this.referenceId,
    this.data,
    this.isRead = false,
    this.readAt,
    this.scheduledAt,
    this.sentAt,
    this.createdAt,
  });

  factory NotificationModel.fromJson(Map<String, dynamic> json) {
    return NotificationModel(
      id: json['id']?.toString() ?? '',
      title: json['title'],
      body: json['body'] ?? json['message'],
      type: json['type'],
      channel: json['channel'],
      status: json['status'],
      recipientId: json['recipient_id']?.toString(),
      recipientEmail: json['recipient_email'],
      recipientPhone: json['recipient_phone'],
      groupId: json['group_id']?.toString(),
      groupName: json['group_name'],
      organizationId: json['organization_id']?.toString(),
      referenceType: json['reference_type'],
      referenceId: json['reference_id']?.toString(),
      data: json['data'],
      isRead: json['is_read'] == true || json['read_at'] != null,
      readAt: json['read_at'] != null
          ? DateTime.tryParse(json['read_at'])
          : null,
      scheduledAt: json['scheduled_at'] != null
          ? DateTime.tryParse(json['scheduled_at'])
          : null,
      sentAt: json['sent_at'] != null
          ? DateTime.tryParse(json['sent_at'])
          : null,
      createdAt: json['created_at'] != null
          ? DateTime.tryParse(json['created_at'])
          : null,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'body': body,
        'type': type,
        'channel': channel,
        'status': status,
        'recipient_id': recipientId,
        'recipient_email': recipientEmail,
        'recipient_phone': recipientPhone,
        'group_id': groupId,
        'group_name': groupName,
        'organization_id': organizationId,
        'reference_type': referenceType,
        'reference_id': referenceId,
        'data': data,
        'is_read': isRead,
        'read_at': readAt?.toIso8601String(),
        'scheduled_at': scheduledAt?.toIso8601String(),
        'sent_at': sentAt?.toIso8601String(),
        'created_at': createdAt?.toIso8601String(),
      };
}

class NotificationTemplateModel {
  final String? id;
  final String? name;
  final String? type;
  final String? channel;
  final String? subject;
  final String? template;
  final Map<String, dynamic>? variables;
  final bool isActive;

  NotificationTemplateModel({
    this.id,
    this.name,
    this.type,
    this.channel,
    this.subject,
    this.template,
    this.variables,
    this.isActive = true,
  });

  factory NotificationTemplateModel.fromJson(Map<String, dynamic> json) {
    return NotificationTemplateModel(
      id: json['id']?.toString(),
      name: json['name'],
      type: json['type'],
      channel: json['channel'],
      subject: json['subject'],
      template: json['template'],
      variables: json['variables'],
      isActive: json['is_active'] == true,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'type': type,
        'channel': channel,
        'subject': subject,
        'template': template,
        'variables': variables,
        'is_active': isActive,
      };

  String render(Map<String, String> values) {
    String result = template ?? '';
    values.forEach((key, value) {
      result = result.replaceAll('{{$key}}', value);
    });
    return result;
  }
}
