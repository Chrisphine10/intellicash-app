class SavingsAccount {
  final int id;
  final String? accountNumber;
  final String? savingsType;
  final int? status;
  final double? openingBalance;
  final double? currentBalance;
  final String? createdAt;

  SavingsAccount({
    required this.id,
    this.accountNumber,
    this.savingsType,
    this.status,
    this.openingBalance,
    this.currentBalance,
    this.createdAt,
  });

  factory SavingsAccount.fromJson(Map<String, dynamic> json) {
    return SavingsAccount(
      id: json['id'],
      accountNumber: json['account_number'],
      savingsType: json['savings_type'] is String
          ? json['savings_type']
          : (json['savings_type'] is Map ? json['savings_type']['name'] : null),
      status: json['status'],
      openingBalance: (json['opening_balance'] as num?)?.toDouble(),
      currentBalance: (json['current_balance'] ?? json['balance'] as num?)?.toDouble(),
      createdAt: json['created_at'],
    );
  }

  bool get isActive => status == 1;
}
