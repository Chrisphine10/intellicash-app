class Member {
  final int id;
  final String? firstName;
  final String? lastName;
  final String? name;
  final String? memberNo;
  final String? email;
  final String? mobile;
  final String? countryCode;
  final String? gender;
  final String? businessName;
  final String? address;
  final String? city;
  final String? state;
  final String? zip;
  final int? status;
  final Map<String, dynamic>? branch;
  final String? createdAt;

  Member({
    required this.id,
    this.firstName,
    this.lastName,
    this.name,
    this.memberNo,
    this.email,
    this.mobile,
    this.countryCode,
    this.gender,
    this.businessName,
    this.address,
    this.city,
    this.state,
    this.zip,
    this.status,
    this.branch,
    this.createdAt,
  });

  factory Member.fromJson(Map<String, dynamic> json) {
    return Member(
      id: json['id'],
      firstName: json['first_name'],
      lastName: json['last_name'],
      name: json['name'] ?? '${json['first_name'] ?? ''} ${json['last_name'] ?? ''}'.trim(),
      memberNo: json['member_no'],
      email: json['email'],
      mobile: json['mobile'],
      countryCode: json['country_code'],
      gender: json['gender'],
      businessName: json['business_name'],
      address: json['address'],
      city: json['city'],
      state: json['state'],
      zip: json['zip'],
      status: json['status'],
      branch: json['branch'] is Map ? json['branch'] : null,
      createdAt: json['created_at'],
    );
  }

  String get displayName => name ?? '$firstName $lastName'.trim();
  bool get isActive => status == 1;
  String get statusText => isActive ? 'Active' : 'Inactive';
  String get branchName => branch?['name'] ?? 'N/A';
}
