class BankAccount {
  final int id;
  final String? accountName;
  final String? accountNumber;
  final String? bankName;
  final double? currentBalance;
  final double? availableBalance;
  final String? currency;
  final bool? isActive;

  BankAccount({
    required this.id,
    this.accountName,
    this.accountNumber,
    this.bankName,
    this.currentBalance,
    this.availableBalance,
    this.currency,
    this.isActive,
  });

  factory BankAccount.fromJson(Map<String, dynamic> json) {
    return BankAccount(
      id: json['id'],
      accountName: json['account_name'],
      accountNumber: json['account_number'],
      bankName: json['bank_name'],
      currentBalance: (json['current_balance'] as num?)?.toDouble(),
      availableBalance: (json['available_balance'] as num?)?.toDouble(),
      currency: json['currency'],
      isActive: json['is_active'] == true || json['is_active'] == 1,
    );
  }
}
