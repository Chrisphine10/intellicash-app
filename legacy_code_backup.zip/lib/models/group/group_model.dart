class GroupModel {
  final String id;
  final String name;
  final String? code;
  final String? description;
  final String? organizationId;
  final String? organizationName;
  final String? status;
  final String? registrationDate;
  final String? approvalDate;
  final String? constitution;
  final String? meetingSchedule;
  final String? meetingDay;
  final String? meetingFrequency;
  final String? meetingTime;
  final String? currency;
  final String? country;
  final String? county;
  final String? subCounty;
  final String? ward;
  final String? village;
  final double? latitude;
  final double? longitude;
  final int? memberCount;
  final int? maxMembers;
  final double? sharePrice;
  final int? maxShares;
  final double? registrationFee;
  final double? minimumSavings;
  final double? minimumLoanAmount;
  final double? maximumLoanAmount;
  final double? loanInterestRate;
  final String? loanInterestMethod;
  final int? loanDurationMin;
  final int? loanDurationMax;
  final double? latePaymentFine;
  final int? gracePeriod;
  final String? socialFundType;
  final double? socialFundAmount;
  final String? createdBy;
  final String? createdByName;
  final List<GroupLeaderModel>? leaders;
  final Map<String, dynamic>? settings;
  final Map<String, dynamic>? metadata;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  GroupModel({
    required this.id,
    required this.name,
    this.code,
    this.description,
    this.organizationId,
    this.organizationName,
    this.status,
    this.registrationDate,
    this.approvalDate,
    this.constitution,
    this.meetingSchedule,
    this.meetingDay,
    this.meetingFrequency,
    this.meetingTime,
    this.currency,
    this.country,
    this.county,
    this.subCounty,
    this.ward,
    this.village,
    this.latitude,
    this.longitude,
    this.memberCount,
    this.maxMembers,
    this.sharePrice,
    this.maxShares,
    this.registrationFee,
    this.minimumSavings,
    this.minimumLoanAmount,
    this.maximumLoanAmount,
    this.loanInterestRate,
    this.loanInterestMethod,
    this.loanDurationMin,
    this.loanDurationMax,
    this.latePaymentFine,
    this.gracePeriod,
    this.socialFundType,
    this.socialFundAmount,
    this.createdBy,
    this.createdByName,
    this.leaders,
    this.settings,
    this.metadata,
    this.createdAt,
    this.updatedAt,
  });

  bool get isActive => status == 'active';
  bool get isApproved => status == 'approved' || status == 'active';

  String get statusText {
    switch (status) {
      case 'pending':
        return 'Pending';
      case 'active':
        return 'Active';
      case 'suspended':
        return 'Suspended';
      case 'dormant':
        return 'Dormant';
      case 'dissolved':
        return 'Dissolved';
      default:
        return status ?? 'Unknown';
    }
  }

  double get totalSavings => metadata?['total_savings'] ?? 0.0;
  double get totalLoans => metadata?['total_loans'] ?? 0.0;
  double get totalShares => metadata?['total_shares'] ?? 0.0;
  double get totalSocialFund => metadata?['total_social_fund'] ?? 0.0;
  double get cashAtHand => metadata?['cash_at_hand'] ?? 0.0;
  double get cashAtBank => metadata?['cash_at_bank'] ?? 0.0;

  factory GroupModel.fromJson(Map<String, dynamic> json) {
    return GroupModel(
      id: json['id']?.toString() ?? '',
      name: json['name'] ?? json['group_name'] ?? '',
      code: json['code'] ?? json['group_code'],
      description: json['description'],
      organizationId: json['organization_id']?.toString(),
      organizationName: json['organization_name'],
      status: json['status']?.toString() ?? 'pending',
      registrationDate: json['registration_date'],
      approvalDate: json['approval_date'],
      constitution: json['constitution'],
      meetingSchedule: json['meeting_schedule'],
      meetingDay: json['meeting_day'],
      meetingFrequency: json['meeting_frequency'],
      meetingTime: json['meeting_time'],
      currency: json['currency'] ?? 'KES',
      country: json['country'],
      county: json['county'],
      subCounty: json['sub_county'],
      ward: json['ward'],
      village: json['village'],
      latitude: (json['latitude'] as num?)?.toDouble(),
      longitude: (json['longitude'] as num?)?.toDouble(),
      memberCount: json['member_count'] ?? json['members_count'],
      maxMembers: json['max_members'],
      sharePrice: (json['share_price'] as num?)?.toDouble(),
      maxShares: json['max_shares'],
      registrationFee: (json['registration_fee'] as num?)?.toDouble(),
      minimumSavings: (json['minimum_savings'] as num?)?.toDouble(),
      minimumLoanAmount: (json['minimum_loan_amount'] as num?)?.toDouble(),
      maximumLoanAmount: (json['maximum_loan_amount'] as num?)?.toDouble(),
      loanInterestRate: (json['loan_interest_rate'] as num?)?.toDouble(),
      loanInterestMethod: json['loan_interest_method'] ?? 'flat',
      loanDurationMin: json['loan_duration_min'],
      loanDurationMax: json['loan_duration_max'],
      latePaymentFine: (json['late_payment_fine'] as num?)?.toDouble(),
      gracePeriod: json['grace_period'],
      socialFundType: json['social_fund_type'],
      socialFundAmount: (json['social_fund_amount'] as num?)?.toDouble(),
      createdBy: json['created_by']?.toString(),
      createdByName: json['created_by_name'],
      leaders: (json['leaders'] as List?)
          ?.map((l) => GroupLeaderModel.fromJson(l))
          .toList(),
      settings: json['settings'],
      metadata: json['metadata'],
      createdAt: json['created_at'] != null
          ? DateTime.tryParse(json['created_at'])
          : null,
      updatedAt: json['updated_at'] != null
          ? DateTime.tryParse(json['updated_at'])
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'code': code,
      'description': description,
      'organization_id': organizationId,
      'status': status,
      'registration_date': registrationDate,
      'approval_date': approvalDate,
      'constitution': constitution,
      'meeting_schedule': meetingSchedule,
      'meeting_day': meetingDay,
      'meeting_frequency': meetingFrequency,
      'meeting_time': meetingTime,
      'currency': currency,
      'country': country,
      'county': county,
      'sub_county': subCounty,
      'ward': ward,
      'village': village,
      'latitude': latitude,
      'longitude': longitude,
      'member_count': memberCount,
      'max_members': maxMembers,
      'share_price': sharePrice,
      'max_shares': maxShares,
      'registration_fee': registrationFee,
      'minimum_savings': minimumSavings,
      'minimum_loan_amount': minimumLoanAmount,
      'maximum_loan_amount': maximumLoanAmount,
      'loan_interest_rate': loanInterestRate,
      'loan_interest_method': loanInterestMethod,
      'loan_duration_min': loanDurationMin,
      'loan_duration_max': loanDurationMax,
      'late_payment_fine': latePaymentFine,
      'grace_period': gracePeriod,
      'social_fund_type': socialFundType,
      'social_fund_amount': socialFundAmount,
      'created_by': createdBy,
      'leaders': leaders?.map((l) => l.toJson()).toList(),
      'settings': settings,
      'metadata': metadata,
      'created_at': createdAt?.toIso8601String(),
      'updated_at': updatedAt?.toIso8601String(),
    };
  }
}

class GroupLeaderModel {
  final String? id;
  final String? userId;
  final String? memberId;
  final String? name;
  final String? position;
  final String? phone;
  final String? email;
  final String? photoUrl;
  final bool isActive;

  GroupLeaderModel({
    this.id,
    this.userId,
    this.memberId,
    this.name,
    this.position,
    this.phone,
    this.email,
    this.photoUrl,
    this.isActive = true,
  });

  factory GroupLeaderModel.fromJson(Map<String, dynamic> json) {
    return GroupLeaderModel(
      id: json['id']?.toString(),
      userId: json['user_id']?.toString(),
      memberId: json['member_id']?.toString(),
      name: json['name'],
      position: json['position'],
      phone: json['phone'],
      email: json['email'],
      photoUrl: json['photo_url'],
      isActive: json['is_active'] == true,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'user_id': userId,
      'member_id': memberId,
      'name': name,
      'position': position,
      'phone': phone,
      'email': email,
      'photo_url': photoUrl,
      'is_active': isActive,
    };
  }
}
