class SavingsAccountModel {
  final String id;
  final String? accountNumber;
  final String? memberId;
  final String? memberName;
  final String? groupId;
  final String? groupName;
  final String? savingsType;
  final String? status;
  final double? openingBalance;
  final double? currentBalance;
  final double? targetAmount;
  final double? interestRate;
  final String? interestFrequency;
  final String? currency;
  final bool isActive;
  final Map<String, dynamic>? metadata;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  SavingsAccountModel({
    required this.id,
    this.accountNumber,
    this.memberId,
    this.memberName,
    this.groupId,
    this.groupName,
    this.savingsType,
    this.status,
    this.openingBalance,
    this.currentBalance,
    this.targetAmount,
    this.interestRate,
    this.interestFrequency,
    this.currency,
    this.isActive = false,
    this.metadata,
    this.createdAt,
    this.updatedAt,
  });

  String get savingsTypeDisplay => savingsType != null
      ? savingsType!.replaceAll('_', ' ').split(' ').map((w) =>
          w[0].toUpperCase() + w.substring(1)).join(' ')
      : 'Savings';

  double get balance => currentBalance ?? openingBalance ?? 0.0;

  factory SavingsAccountModel.fromJson(Map<String, dynamic> json) {
    final savingsType = json['savings_type'];
    return SavingsAccountModel(
      id: json['id']?.toString() ?? '',
      accountNumber: json['account_number'],
      memberId: json['member_id']?.toString(),
      memberName: json['member_name'],
      groupId: json['group_id']?.toString(),
      groupName: json['group_name'],
      savingsType: savingsType is Map ? savingsType['name'] : savingsType?.toString(),
      status: json['status']?.toString() ?? 'active',
      openingBalance: (json['opening_balance'] as num?)?.toDouble(),
      currentBalance: (json['current_balance'] as num?)?.toDouble() ??
          (json['balance'] as num?)?.toDouble(),
      targetAmount: (json['target_amount'] as num?)?.toDouble(),
      interestRate: (json['interest_rate'] as num?)?.toDouble(),
      interestFrequency: json['interest_frequency'],
      currency: json['currency'] ?? 'KES',
      isActive: json['status'] == 'active' || json['status'] == 1 || json['is_active'] == true,
      metadata: json['metadata'],
      createdAt: json['created_at'] != null
          ? DateTime.tryParse(json['created_at'])
          : null,
      updatedAt: json['updated_at'] != null
          ? DateTime.tryParse(json['updated_at'])
          : null,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'account_number': accountNumber,
        'member_id': memberId,
        'member_name': memberName,
        'group_id': groupId,
        'group_name': groupName,
        'savings_type': savingsType,
        'status': status,
        'opening_balance': openingBalance,
        'current_balance': currentBalance,
        'target_amount': targetAmount,
        'interest_rate': interestRate,
        'interest_frequency': interestFrequency,
        'currency': currency,
        'metadata': metadata,
        'created_at': createdAt?.toIso8601String(),
        'updated_at': updatedAt?.toIso8601String(),
      };
}

class SavingsTransactionModel {
  final String id;
  final String? savingsAccountId;
  final String? memberId;
  final String? memberName;
  final String? groupId;
  final String? transactionType;
  final double? amount;
  final double? balanceBefore;
  final double? balanceAfter;
  final String? method;
  final String? status;
  final String? description;
  final String? reference;
  final String? receiptNumber;
  final String? paymentMethod;
  final String? paymentReference;
  final String? createdBy;
  final DateTime? transactionDate;
  final DateTime? createdAt;

  SavingsTransactionModel({
    required this.id,
    this.savingsAccountId,
    this.memberId,
    this.memberName,
    this.groupId,
    this.transactionType,
    this.amount,
    this.balanceBefore,
    this.balanceAfter,
    this.method,
    this.status,
    this.description,
    this.reference,
    this.receiptNumber,
    this.paymentMethod,
    this.paymentReference,
    this.createdBy,
    this.transactionDate,
    this.createdAt,
  });

  bool get isCredit =>
      transactionType == 'deposit' || transactionType == 'credit';
  bool get isDebit =>
      transactionType == 'withdrawal' || transactionType == 'debit';
  bool get isCompleted => status == 'completed' || status == 'approved';
  bool get isPending => status == 'pending';

  factory SavingsTransactionModel.fromJson(Map<String, dynamic> json) {
    return SavingsTransactionModel(
      id: json['id']?.toString() ?? '',
      savingsAccountId: json['savings_account_id']?.toString(),
      memberId: json['member_id']?.toString(),
      memberName: json['member_name'],
      groupId: json['group_id']?.toString(),
      transactionType: json['transaction_type'] ?? json['type'],
      amount: (json['amount'] as num?)?.toDouble(),
      balanceBefore: (json['balance_before'] as num?)?.toDouble(),
      balanceAfter: (json['balance_after'] as num?)?.toDouble(),
      method: json['method'],
      status: json['status']?.toString() ?? 'pending',
      description: json['description'],
      reference: json['reference'],
      receiptNumber: json['receipt_number'],
      paymentMethod: json['payment_method'],
      paymentReference: json['payment_reference'],
      createdBy: json['created_by']?.toString(),
      transactionDate: json['transaction_date'] != null
          ? DateTime.tryParse(json['transaction_date'])
          : null,
      createdAt: json['created_at'] != null
          ? DateTime.tryParse(json['created_at'])
          : null,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'savings_account_id': savingsAccountId,
        'member_id': memberId,
        'member_name': memberName,
        'group_id': groupId,
        'transaction_type': transactionType,
        'amount': amount,
        'balance_before': balanceBefore,
        'balance_after': balanceAfter,
        'method': method,
        'status': status,
        'description': description,
        'reference': reference,
        'receipt_number': receiptNumber,
        'payment_method': paymentMethod,
        'payment_reference': paymentReference,
        'created_by': createdBy,
        'transaction_date': transactionDate?.toIso8601String(),
        'created_at': createdAt?.toIso8601String(),
      };
}
