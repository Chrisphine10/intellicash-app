class TransactionModel {
  final String id;
  final String? transactionDate;
  final String? memberId;
  final String? memberName;
  final String? groupId;
  final String? groupName;
  final String? savingsAccountId;
  final String? loanId;
  final double? amount;
  final String? type;
  final String? drCr;
  final String? method;
  final String? status;
  final String? description;
  final String? note;
  final String? reference;
  final String? receiptNumber;
  final String? paymentMethod;
  final String? paymentReference;
  final String? category;
  final String? subCategory;
  final String? createdBy;
  final String? createdByName;
  final Map<String, dynamic>? metadata;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  TransactionModel({
    required this.id,
    this.transactionDate,
    this.memberId,
    this.memberName,
    this.groupId,
    this.groupName,
    this.savingsAccountId,
    this.loanId,
    this.amount,
    this.type,
    this.drCr,
    this.method,
    this.status,
    this.description,
    this.note,
    this.reference,
    this.receiptNumber,
    this.paymentMethod,
    this.paymentReference,
    this.category,
    this.subCategory,
    this.createdBy,
    this.createdByName,
    this.metadata,
    this.createdAt,
    this.updatedAt,
  });

  bool get isCredit => drCr == 'cr' || drCr == 'credit';
  bool get isDebit => drCr == 'dr' || drCr == 'debit';
  bool get isCompleted =>
      status == 'completed' || status == 'approved' || status == '2';
  bool get isPending =>
      status == 'pending' || status == '1';
  bool get isRejected =>
      status == 'rejected' || status == '3';

  String get statusText {
    switch (status) {
      case '1':
      case 'pending':
        return 'Pending';
      case '2':
      case 'approved':
      case 'completed':
        return 'Approved';
      case '3':
      case 'rejected':
        return 'Rejected';
      default:
        return status ?? 'Unknown';
    }
  }

  String get typeDisplay {
    switch (type) {
      case 'savings_deposit':
        return 'Savings Deposit';
      case 'savings_withdrawal':
        return 'Savings Withdrawal';
      case 'share_purchase':
        return 'Share Purchase';
      case 'share_sale':
        return 'Share Sale';
      case 'loan_disbursement':
        return 'Loan Disbursement';
      case 'loan_repayment':
        return 'Loan Repayment';
      case 'fine_payment':
        return 'Fine Payment';
      case 'social_fund':
        return 'Social Fund Contribution';
      case 'social_fund_disbursement':
        return 'Social Fund Disbursement';
      case 'expense':
        return 'Expense';
      case 'income':
        return 'Income';
      case 'registration_fee':
        return 'Registration Fee';
      case 'transfer':
        return 'Transfer';
      default:
        return type ?? 'Transaction';
    }
  }

  factory TransactionModel.fromJson(Map<String, dynamic> json) {
    return TransactionModel(
      id: json['id']?.toString() ?? '',
      transactionDate:
          json['transaction_date'] ?? json['trans_date'],
      memberId: json['member_id']?.toString(),
      memberName: json['member_name'] ??
          (json['member'] is Map ? json['member']['name'] : null),
      groupId: json['group_id']?.toString(),
      groupName: json['group_name'],
      savingsAccountId: json['savings_account_id']?.toString(),
      loanId: json['loan_id']?.toString(),
      amount: (json['amount'] as num?)?.toDouble(),
      type: json['type'] ?? json['transaction_type'],
      drCr: json['dr_cr'] ?? json['drCr'] ?? json['entry_type'],
      method: json['method'],
      status: json['status']?.toString() ?? 'completed',
      description: json['description'],
      note: json['note'] ?? json['notes'],
      reference: json['reference'],
      receiptNumber: json['receipt_number'],
      paymentMethod: json['payment_method'],
      paymentReference: json['payment_reference'],
      category: json['category'],
      subCategory: json['sub_category'],
      createdBy: json['created_by']?.toString(),
      createdByName: json['created_by_name'],
      metadata: json['metadata'],
      createdAt: json['created_at'] != null
          ? DateTime.tryParse(json['created_at'])
          : null,
      updatedAt: json['updated_at'] != null
          ? DateTime.tryParse(json['updated_at'])
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'transaction_date': transactionDate,
      'member_id': memberId,
      'member_name': memberName,
      'group_id': groupId,
      'group_name': groupName,
      'savings_account_id': savingsAccountId,
      'loan_id': loanId,
      'amount': amount,
      'type': type,
      'dr_cr': drCr,
      'method': method,
      'status': status,
      'description': description,
      'note': note,
      'reference': reference,
      'receipt_number': receiptNumber,
      'payment_method': paymentMethod,
      'payment_reference': paymentReference,
      'category': category,
      'sub_category': subCategory,
      'created_by': createdBy,
      'created_by_name': createdByName,
      'metadata': metadata,
      'created_at': createdAt?.toIso8601String(),
      'updated_at': updatedAt?.toIso8601String(),
    };
  }
}
