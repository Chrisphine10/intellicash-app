class Loan {
  final int id;
  final String? loanId;
  final String? loanProduct;
  final double? appliedAmount;
  final double? totalPayable;
  final double? totalPaid;
  final double? outstandingAmount;
  final double? interestRate;
  final String? currency;
  final int? status;
  final String? firstPaymentDate;
  final String? releaseDate;
  final String? createdAt;

  Loan({
    required this.id,
    this.loanId,
    this.loanProduct,
    this.appliedAmount,
    this.totalPayable,
    this.totalPaid,
    this.outstandingAmount,
    this.interestRate,
    this.currency,
    this.status,
    this.firstPaymentDate,
    this.releaseDate,
    this.createdAt,
  });

  factory Loan.fromJson(Map<String, dynamic> json) {
    return Loan(
      id: json['id'],
      loanId: json['loan_id'],
      loanProduct: json['loan_product'],
      appliedAmount: (json['applied_amount'] as num?)?.toDouble(),
      totalPayable: (json['total_payable'] as num?)?.toDouble(),
      totalPaid: (json['total_paid'] as num?)?.toDouble(),
      outstandingAmount: (json['outstanding_amount'] as num?)?.toDouble(),
      interestRate: (json['interest_rate'] as num?)?.toDouble(),
      currency: json['currency'],
      status: json['status'],
      firstPaymentDate: json['first_payment_date'],
      releaseDate: json['release_date'],
      createdAt: json['created_at'],
    );
  }

  String get statusText {
    switch (status) {
      case 0: return 'Draft';
      case 1: return 'Pending';
      case 2: return 'Active';
      case 3: return 'Completed';
      case 4: return 'Rejected';
      case 5: return 'Defaulted';
      default: return 'Unknown';
    }
  }

  double get repaymentProgress {
    if (totalPayable == null || totalPayable == 0) return 0;
    return ((totalPaid ?? 0) / totalPayable!).clamp(0.0, 1.0);
  }
}
