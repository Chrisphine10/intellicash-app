class Transaction {
  final int id;
  final String? transDate;
  final int? memberId;
  final int? savingsAccountId;
  final double? amount;
  final String? type;
  final String? drCr;
  final String? method;
  final int? status;
  final String? description;
  final String? note;
  final String? reference;
  final String? createdAt;
  final Map<String, dynamic>? member;
  final Map<String, dynamic>? savingsAccount;

  Transaction({
    required this.id,
    this.transDate,
    this.memberId,
    this.savingsAccountId,
    this.amount,
    this.type,
    this.drCr,
    this.method,
    this.status,
    this.description,
    this.note,
    this.reference,
    this.createdAt,
    this.member,
    this.savingsAccount,
  });

  factory Transaction.fromJson(Map<String, dynamic> json) {
    return Transaction(
      id: json['id'],
      transDate: json['trans_date'] ?? json['transaction_date'],
      memberId: json['member_id'],
      savingsAccountId: json['savings_account_id'],
      amount: (json['amount'] as num?)?.toDouble(),
      type: json['type'],
      drCr: json['dr_cr'],
      method: json['method'],
      status: json['status'],
      description: json['description'],
      note: json['note'],
      reference: json['reference'],
      createdAt: json['created_at'],
      member: json['member'] is Map<String, dynamic> ? json['member'] : null,
      savingsAccount: json['savings_account'] is Map<String, dynamic> ? json['savings_account'] : null,
    );
  }

  bool get isCredit => drCr == 'cr';
  bool get isDebit => drCr == 'dr';
  String get statusText {
    switch (status) {
      case 1: return 'Pending';
      case 2: return 'Approved';
      case 3: return 'Rejected';
      default: return 'Unknown';
    }
  }

  String get memberName {
    if (member == null) return 'N/A';
    final fn = member!['first_name'] ?? '';
    final ln = member!['last_name'] ?? '';
    return member!['name'] ?? '$fn $ln'.trim();
  }
}
