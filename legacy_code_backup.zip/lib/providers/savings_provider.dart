import 'package:flutter/material.dart';
import '../core/network/api_client.dart';
import '../core/constants/api_endpoints.dart';
import '../models/savings/savings_model.dart';

class SavingsProvider extends ChangeNotifier {
  final ApiClient _apiClient = ApiClient();

  List<SavingsAccountModel> _accounts = [];
  List<SavingsAccountModel> get accounts => _accounts;

  SavingsAccountModel? _selectedAccount;
  SavingsAccountModel? get selectedAccount => _selectedAccount;

  List<SavingsTransactionModel> _transactions = [];
  List<SavingsTransactionModel> get transactions => _transactions;

  bool _isLoading = false;
  bool get isLoading => _isLoading;
  String? _error;
  String? get error => _error;

  // Stats
  double _totalSavings = 0.0;
  double get totalSavings => _totalSavings;
  double _totalShares = 0.0;
  double get totalShares => _totalShares;
  double _totalSocialFund = 0.0;
  double get totalSocialFund => _totalSocialFund;
  int _activeAccounts = 0;
  int get activeAccounts => _activeAccounts;

  Future<void> fetchAccounts({String? memberId, String? groupId}) async {
    _setLoading(true);
    try {
      final queryParams = <String, String>{
        'with': 'member,transactions',
      };
      if (memberId != null) queryParams['member_id'] = memberId;
      if (groupId != null) queryParams['group_id'] = groupId;

      final response =
          await _apiClient.get(ApiEndpoints.savings, queryParams: queryParams);
      if (response.isSuccess) {
        final data = response.data;
        if (data is List) {
          _accounts = data.map((e) => SavingsAccountModel.fromJson(e)).toList();
          _computeStats();
          notifyListeners();
        }
      }
    } catch (e) {
      _setError('Failed to load savings accounts: $e');
    }
    _setLoading(false);
  }

  Future<void> fetchAccountDetail(String accountId) async {
    _setLoading(true);
    try {
      final response = await _apiClient.get(ApiEndpoints.savingById(accountId));
      if (response.isSuccess && response.data != null) {
        _selectedAccount =
            SavingsAccountModel.fromJson(response.data as Map<String, dynamic>);
        notifyListeners();
      }
    } catch (e) {
      _setError('Failed to load account details: $e');
    }
    _setLoading(false);
  }

  Future<void> fetchTransactions(String accountId) async {
    try {
      final response =
          await _apiClient.get(ApiEndpoints.savingTransactions(accountId));
      if (response.isSuccess && response.data is List) {
        _transactions = (response.data as List)
            .map((e) => SavingsTransactionModel.fromJson(e))
            .toList();
        notifyListeners();
      }
    } catch (e) {
      _setError('Failed to load transactions: $e');
    }
  }

  Future<bool> createAccount(Map<String, dynamic> accountData) async {
    _setLoading(true);
    try {
      final response =
          await _apiClient.post(ApiEndpoints.savings, body: accountData);
      if (response.isSuccess) {
        await fetchAccounts();
        _setLoading(false);
        return true;
      }
      _setLoading(false);
      return false;
    } catch (e) {
      _setError('Failed to create account: $e');
      _setLoading(false);
      return false;
    }
  }

  Future<bool> makeDeposit(Map<String, dynamic> depositData) async {
    _setLoading(true);
    try {
      final accountId = depositData['savings_account_id'];
      final response = await _apiClient.post(
        ApiEndpoints.savingDeposit(accountId),
        body: depositData,
      );
      if (response.isSuccess) {
        await fetchAccountDetail(accountId);
        await fetchTransactions(accountId);
        await fetchAccounts();
        _setLoading(false);
        return true;
      }
      _setLoading(false);
      return false;
    } catch (e) {
      _setError('Failed to process deposit: $e');
      _setLoading(false);
      return false;
    }
  }

  Future<bool> makeWithdrawal(Map<String, dynamic> withdrawalData) async {
    _setLoading(true);
    try {
      final accountId = withdrawalData['savings_account_id'];
      final response = await _apiClient.post(
        ApiEndpoints.savingWithdrawal(accountId),
        body: withdrawalData,
      );
      if (response.isSuccess) {
        await fetchAccountDetail(accountId);
        await fetchTransactions(accountId);
        await fetchAccounts();
        _setLoading(false);
        return true;
      }
      _setLoading(false);
      return false;
    } catch (e) {
      _setError('Failed to process withdrawal: $e');
      _setLoading(false);
      return false;
    }
  }

  Future<bool> transferFunds(Map<String, dynamic> transferData) async {
    _setLoading(true);
    try {
      final response = await _apiClient.post(
        ApiEndpoints.savingTransfer(transferData['from_account_id']),
        body: transferData,
      );
      if (response.isSuccess) {
        await fetchAccounts();
        _setLoading(false);
        return true;
      }
      _setLoading(false);
      return false;
    } catch (e) {
      _setError('Failed to transfer funds: $e');
      _setLoading(false);
      return false;
    }
  }

  void _computeStats() {
    _totalSavings = 0.0;
    _totalShares = 0.0;
    _totalSocialFund = 0.0;
    _activeAccounts = 0;

    for (final account in _accounts) {
      if (account.savingsType == 'share') {
        _totalShares += account.balance;
      } else if (account.savingsType == 'social_fund') {
        _totalSocialFund += account.balance;
      } else {
        _totalSavings += account.balance;
      }
      if (account.isActive) _activeAccounts++;
    }
  }

  void selectAccount(SavingsAccountModel? account) {
    _selectedAccount = account;
    if (account != null) {
      fetchTransactions(account.id);
    }
    notifyListeners();
  }

  void clearSelection() {
    _selectedAccount = null;
    _transactions = [];
    notifyListeners();
  }

  void _setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }

  void _setError(String message) {
    _error = message;
    notifyListeners();
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}
