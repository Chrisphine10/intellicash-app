import 'package:flutter/material.dart';
import '../core/network/api_client.dart';
import '../core/constants/api_endpoints.dart';
import '../models/meeting/meeting_model.dart';

class MeetingProvider extends ChangeNotifier {
  final ApiClient _apiClient = ApiClient();

  List<MeetingModel> _meetings = [];
  List<MeetingModel> get meetings => _meetings;

  MeetingModel? _selectedMeeting;
  MeetingModel? get selectedMeeting => _selectedMeeting;

  List<MeetingAttendanceModel> _attendance = [];
  List<MeetingAttendanceModel> get attendance => _attendance;

  List<MeetingAgendaModel> _agendaItems = [];
  List<MeetingAgendaModel> get agendaItems => _agendaItems;

  List<MeetingResolutionModel> _resolutions = [];
  List<MeetingResolutionModel> get resolutions => _resolutions;

  bool _isLoading = false;
  bool get isLoading => _isLoading;
  String? _error;
  String? get error => _error;

  Future<void> fetchMeetings({
    String? groupId,
    String? status,
    int page = 1,
  }) async {
    _setLoading(true);
    try {
      final queryParams = <String, String>{
        'page': page.toString(),
        'per_page': '50',
        'with': 'attendance,financials',
      };
      if (groupId != null) queryParams['group_id'] = groupId;
      if (status != null) queryParams['status'] = status;

      final response =
          await _apiClient.get(ApiEndpoints.meetings, queryParams: queryParams);
      if (response.isSuccess) {
        final data = response.data;
        if (data is List) {
          _meetings = data.map((e) => MeetingModel.fromJson(e)).toList();
          notifyListeners();
        }
      }
    } catch (e) {
      _setError('Failed to load meetings: $e');
    }
    _setLoading(false);
  }

  Future<void> fetchMeetingDetail(String meetingId) async {
    _setLoading(true);
    try {
      final response =
          await _apiClient.get(ApiEndpoints.meetingById(meetingId));
      if (response.isSuccess && response.data != null) {
        _selectedMeeting =
            MeetingModel.fromJson(response.data as Map<String, dynamic>);
        _attendance = _selectedMeeting?.attendance ?? [];
        _agendaItems = _selectedMeeting?.agendaItems ?? [];
        _resolutions = _selectedMeeting?.resolutions ?? [];
        notifyListeners();
      }
    } catch (e) {
      _setError('Failed to load meeting details: $e');
    }
    _setLoading(false);
  }

  Future<bool> createMeeting(Map<String, dynamic> meetingData) async {
    _setLoading(true);
    try {
      final response =
          await _apiClient.post(ApiEndpoints.meetings, body: meetingData);
      if (response.isSuccess) {
        await fetchMeetings(groupId: meetingData['group_id']);
        _setLoading(false);
        return true;
      }
      _setLoading(false);
      return false;
    } catch (e) {
      _setError('Failed to create meeting: $e');
      _setLoading(false);
      return false;
    }
  }

  Future<bool> updateMeeting(
      String meetingId, Map<String, dynamic> data) async {
    _setLoading(true);
    try {
      final response =
          await _apiClient.put(ApiEndpoints.meetingById(meetingId), body: data);
      if (response.isSuccess) {
        await fetchMeetingDetail(meetingId);
        _setLoading(false);
        return true;
      }
      _setLoading(false);
      return false;
    } catch (e) {
      _setError('Failed to update meeting: $e');
      _setLoading(false);
      return false;
    }
  }

  Future<bool> startMeeting(String meetingId) async {
    return updateMeeting(meetingId, {
      'status': 'in_progress',
      'start_time': DateTime.now().toIso8601String(),
    });
  }

  Future<bool> completeMeeting(String meetingId,
      Map<String, dynamic> financialData) async {
    return updateMeeting(meetingId, {
      ...financialData,
      'status': 'completed',
      'end_time': DateTime.now().toIso8601String(),
    });
  }

  Future<bool> markAttendance(
      String meetingId, List<Map<String, dynamic>> attendanceData) async {
    try {
      final response = await _apiClient.post(
        ApiEndpoints.meetingAttendance(meetingId),
        body: {'attendance': attendanceData},
      );
      if (response.isSuccess) {
        await fetchMeetingDetail(meetingId);
        return true;
      }
      return false;
    } catch (e) {
      _setError('Failed to mark attendance: $e');
      return false;
    }
  }

  Future<bool> addAgendaItem(
      String meetingId, Map<String, dynamic> agendaData) async {
    try {
      final response = await _apiClient.post(
        ApiEndpoints.meetingAgenda(meetingId),
        body: agendaData,
      );
      if (response.isSuccess) {
        await fetchMeetingDetail(meetingId);
        return true;
      }
      return false;
    } catch (e) {
      _setError('Failed to add agenda item: $e');
      return false;
    }
  }

  Future<bool> addResolution(
      String meetingId, Map<String, dynamic> resolutionData) async {
    try {
      final response = await _apiClient.post(
        ApiEndpoints.meetingResolutions(meetingId),
        body: resolutionData,
      );
      if (response.isSuccess) {
        await fetchMeetingDetail(meetingId);
        return true;
      }
      return false;
    } catch (e) {
      _setError('Failed to add resolution: $e');
      return false;
    }
  }

  Future<bool> addSignature(
      String meetingId, Map<String, dynamic> signatureData) async {
    try {
      final response = await _apiClient.post(
        ApiEndpoints.meetingSignatures(meetingId),
        body: signatureData,
      );
      if (response.isSuccess) {
        await fetchMeetingDetail(meetingId);
        return true;
      }
      return false;
    } catch (e) {
      _setError('Failed to add signature: $e');
      return false;
    }
  }

  Future<bool> saveMinutes(String meetingId, String minutes) async {
    return updateMeeting(meetingId, {'minutes': minutes});
  }

  Future<bool> deleteMeeting(String meetingId) async {
    _setLoading(true);
    try {
      final response =
          await _apiClient.delete(ApiEndpoints.meetingById(meetingId));
      if (response.isSuccess) {
        _meetings.removeWhere((m) => m.id == meetingId);
        notifyListeners();
        _setLoading(false);
        return true;
      }
      _setLoading(false);
      return false;
    } catch (e) {
      _setError('Failed to delete meeting: $e');
      _setLoading(false);
      return false;
    }
  }

  void selectMeeting(MeetingModel? meeting) {
    _selectedMeeting = meeting;
    if (meeting != null) {
      _attendance = meeting.attendance ?? [];
      _agendaItems = meeting.agendaItems ?? [];
      _resolutions = meeting.resolutions ?? [];
    }
    notifyListeners();
  }

  void clearSelection() {
    _selectedMeeting = null;
    _attendance = [];
    _agendaItems = [];
    _resolutions = [];
    notifyListeners();
  }

  void _setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }

  void _setError(String message) {
    _error = message;
    notifyListeners();
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}
