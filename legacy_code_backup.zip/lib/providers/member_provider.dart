import 'package:flutter/material.dart';
import '../core/network/api_client.dart';
import '../core/constants/api_endpoints.dart';
import '../models/member/member_model.dart';
import '../services/offline_service.dart';

class MemberProvider extends ChangeNotifier {
  final ApiClient _apiClient = ApiClient();
  final OfflineService _offlineService = OfflineService();

  List<MemberModel> _members = [];
  List<MemberModel> get members => _members;

  MemberModel? _selectedMember;
  MemberModel? get selectedMember => _selectedMember;

  bool _isLoading = false;
  bool get isLoading => _isLoading;

  String? _error;
  String? get error => _error;

  int _totalCount = 0;
  int get totalCount => _totalCount;
  int _currentPage = 1;
  bool _hasMore = true;
  bool get hasMore => _hasMore;

  Future<void> fetchMembers({
    String? search,
    String? groupId,
    String? status,
    int page = 1,
    bool refresh = false,
  }) async {
    if (refresh) {
      _currentPage = 1;
      _hasMore = true;
    }

    _setLoading(true);
    try {
      final queryParams = <String, String>{
        'page': _currentPage.toString(),
        'per_page': '50',
        'with': 'savings,loans,group,documents',
      };
      if (search != null && search.isNotEmpty) queryParams['search'] = search;
      if (groupId != null) queryParams['group_id'] = groupId;
      if (status != null) queryParams['status'] = status;

      final response =
          await _apiClient.get(ApiEndpoints.members, queryParams: queryParams);
      if (response.isSuccess) {
        final data = response.data;
        if (data is List) {
          final fetched = data.map((e) => MemberModel.fromJson(e)).toList();
          if (refresh || _currentPage == 1) {
            _members = fetched;
          } else {
            _members.addAll(fetched);
          }
          _hasMore = fetched.length >= 50;
          _currentPage++;
          _totalCount = _members.length;
        }
        await _offlineService.cacheData('members',
            _members.map((m) => m.toJson()).toList());
        notifyListeners();
      }
    } catch (e) {
      if (_members.isEmpty) {
        final cached = _offlineService.getCachedData<dynamic>('members', (d) => d);
        if (cached is List) {
          _members = cached.map((e) => MemberModel.fromJson(e as Map<String, dynamic>)).toList();
        }
      }
      _setError('Failed to load members: $e');
    }
    _setLoading(false);
  }

  Future<void> fetchMemberDetail(String memberId) async {
    _setLoading(true);
    try {
      final response =
          await _apiClient.get(ApiEndpoints.memberById(memberId));
      if (response.isSuccess && response.data != null) {
        _selectedMember =
            MemberModel.fromJson(response.data as Map<String, dynamic>);
        notifyListeners();
      }
    } catch (e) {
      _setError('Failed to load member details: $e');
    }
    _setLoading(false);
  }

  Future<bool> addMember(Map<String, dynamic> memberData) async {
    _setLoading(true);
    try {
      if (!_offlineService.isOnline) {
        await _offlineService.addToSyncQueue({
          'endpoint': ApiEndpoints.members,
          'method': 'POST',
          'body': memberData,
        });
        _setLoading(false);
        return true;
      }

      final response =
          await _apiClient.post(ApiEndpoints.members, body: memberData);
      if (response.isSuccess) {
        await fetchMembers(refresh: true);
        _setLoading(false);
        return true;
      }
      _setLoading(false);
      return false;
    } catch (e) {
      _setError('Failed to add member: $e');
      _setLoading(false);
      return false;
    }
  }

  Future<bool> updateMember(
      String memberId, Map<String, dynamic> data) async {
    _setLoading(true);
    try {
      final response =
          await _apiClient.put(ApiEndpoints.memberById(memberId), body: data);
      if (response.isSuccess) {
        await fetchMemberDetail(memberId);
        _setLoading(false);
        return true;
      }
      _setLoading(false);
      return false;
    } catch (e) {
      _setError('Failed to update member: $e');
      _setLoading(false);
      return false;
    }
  }

  Future<bool> deleteMember(String memberId) async {
    _setLoading(true);
    try {
      final response =
          await _apiClient.delete(ApiEndpoints.memberById(memberId));
      if (response.isSuccess) {
        _members.removeWhere((m) => m.id == memberId);
        notifyListeners();
        _setLoading(false);
        return true;
      }
      _setLoading(false);
      return false;
    } catch (e) {
      _setError('Failed to delete member: $e');
      _setLoading(false);
      return false;
    }
  }

  Future<bool> uploadMemberPhoto(String memberId, String filePath) async {
    try {
      final bytes = [1];
      final response = await _apiClient.upload(
        ApiEndpoints.memberPhoto(memberId),
        fileBytes: bytes,
        fileName: 'photo.jpg',
      );
      if (response.isSuccess) {
        await fetchMemberDetail(memberId);
        return true;
      }
      return false;
    } catch (e) {
      _setError('Failed to upload photo: $e');
      return false;
    }
  }

  Future<List<MemberDocumentModel>> fetchMemberDocuments(
      String memberId) async {
    try {
      final response =
          await _apiClient.get(ApiEndpoints.memberDocuments(memberId));
      if (response.isSuccess && response.data is List) {
        return (response.data as List)
            .map((e) => MemberDocumentModel.fromJson(e))
            .toList();
      }
      return [];
    } catch (e) {
      _setError('Failed to load documents: $e');
      return [];
    }
  }

  void selectMember(MemberModel? member) {
    _selectedMember = member;
    notifyListeners();
  }

  void clearSelection() {
    _selectedMember = null;
    notifyListeners();
  }

  void _setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }

  void _setError(String message) {
    _error = message;
    notifyListeners();
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}
