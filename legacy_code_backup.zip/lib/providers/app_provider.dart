import 'package:flutter/material.dart';
import '../core/network/api_client.dart';
import '../core/constants/api_endpoints.dart';
import '../models/user/user_model.dart';
import '../models/group/group_model.dart';
import '../models/member/member_model.dart';
import '../models/meeting/meeting_model.dart';
import '../models/savings/savings_model.dart';
import '../models/loan/loan_model.dart';
import '../models/transaction/transaction_model.dart';
import '../models/report/report_model.dart';
import '../models/notification/notification_model.dart';
import '../services/auth_service.dart';
import '../services/offline_service.dart';
import '../services/sync_service.dart';
import '../services/notification_service.dart';

class AppProvider extends ChangeNotifier {
  final ApiClient _apiClient = ApiClient();
  final AuthService _authService = AuthService();
  final OfflineService _offlineService = OfflineService();
  final SyncService _syncService = SyncService();
  final NotificationService _notificationService = NotificationService();

  bool _isLoading = false;
  bool get isLoading => _isLoading;

  String? _error;
  String? get error => _error;

  bool _isDarkMode = false;
  bool get isDarkMode => _isDarkMode;

  bool _isOffline = false;
  bool get isOffline => _isOffline;

  // Auth
  UserModel? _currentUser;
  UserModel? get currentUser => _currentUser;
  bool get isLoggedIn => _authService.isAuthenticated;

  // Dashboard
  DashboardSummaryModel? _dashboardSummary;
  DashboardSummaryModel? get dashboardSummary => _dashboardSummary;

  // Groups
  List<GroupModel> _groups = [];
  List<GroupModel> get groups => _groups;
  GroupModel? _selectedGroup;
  GroupModel? get selectedGroup => _selectedGroup;

  // Members
  List<MemberModel> _members = [];
  List<MemberModel> get members => _members;
  MemberModel? _selectedMember;
  MemberModel? get selectedMember => _selectedMember;

  // Meetings
  List<MeetingModel> _meetings = [];
  List<MeetingModel> get meetings => _meetings;
  MeetingModel? _selectedMeeting;
  MeetingModel? get selectedMeeting => _selectedMeeting;

  // Savings
  List<SavingsAccountModel> _savingsAccounts = [];
  List<SavingsAccountModel> get savingsAccounts => _savingsAccounts;
  final List<SavingsTransactionModel> _savingsTransactions = [];
  List<SavingsTransactionModel> get savingsTransactions =>
      _savingsTransactions;

  // Loans
  List<LoanModel> _loans = [];
  List<LoanModel> get loans => _loans;
  LoanModel? _selectedLoan;
  LoanModel? get selectedLoan => _selectedLoan;

  // Transactions
  List<TransactionModel> _transactions = [];
  List<TransactionModel> get transactions => _transactions;

  // Notifications
  List<NotificationModel> _notifications = [];
  List<NotificationModel> get notifications => _notifications;

  // Sync
  SyncStatus _syncStatus = SyncStatus.idle;
  SyncStatus get syncStatus => _syncStatus;
  double _syncProgress = 0.0;
  double get syncProgress => _syncProgress;

  Future<void> initialize() async {
    await _offlineService.initialize();
    _isOffline = !_offlineService.isOnline;
    await _authService.loadSavedSession();
    _currentUser = _authService.currentUser;

    _syncService.statusStream.listen((status) {
      _syncStatus = status;
      notifyListeners();
    });
    _syncService.progressStream.listen((progress) {
      _syncProgress = progress;
      notifyListeners();
    });
    _syncService.initialize();

    if (isLoggedIn) {
      await loadInitialData();
    }
    notifyListeners();
  }

  Future<void> loadInitialData() async {
    await Future.wait([
      fetchDashboard(),
      fetchGroups(),
      fetchMembers(),
      fetchNotifications(),
    ]);
  }

  Future<bool> login({
    required String baseUrl,
    required String apiKey,
    required String apiSecret,
  }) async {
    _setLoading(true);
    _clearError();

    try {
      final success = await _authService.loginWithApiKey(
        baseUrl: baseUrl,
        apiKey: apiKey,
        apiSecret: apiSecret,
      );

      if (success) {
        _currentUser = _authService.currentUser;
        await loadInitialData();
        _setLoading(false);
        return true;
      } else {
        _setError('Invalid credentials or server unreachable');
        _setLoading(false);
        return false;
      }
    } catch (e) {
      _setError(e.toString());
      _setLoading(false);
      return false;
    }
  }

  Future<bool> loginWithEmail({
    required String baseUrl,
    required String email,
    required String password,
  }) async {
    _setLoading(true);
    _clearError();

    try {
      final success = await _authService.loginWithEmail(
        baseUrl: baseUrl,
        email: email,
        password: password,
      );

      if (success) {
        _currentUser = _authService.currentUser;
        await loadInitialData();
        _setLoading(false);
        return true;
      } else {
        _setError('Invalid email or password');
        _setLoading(false);
        return false;
      }
    } catch (e) {
      _setError(e.toString());
      _setLoading(false);
      return false;
    }
  }

  Future<void> logout() async {
    await _authService.logout();
    _currentUser = null;
    _clearAllData();
    notifyListeners();
  }

  // Dashboard
  Future<void> fetchDashboard() async {
    try {
      final response = await _apiClient.get(ApiEndpoints.reportDashboard);
      if (response.isSuccess && response.data != null) {
        _dashboardSummary =
            DashboardSummaryModel.fromJson(response.data as Map<String, dynamic>);
        notifyListeners();
      }
    } catch (e) {
      _dashboardSummary = _offlineService.getCachedData(
        'dashboard_summary',
        (d) => DashboardSummaryModel.fromJson(d as Map<String, dynamic>),
      );
      debugPrint('Dashboard fetch failed: $e');
    }
  }

  // Groups
  Future<void> fetchGroups({String? search, int page = 1}) async {
    _setLoading(true);
    try {
      final queryParams = <String, String>{
        'page': page.toString(),
        'per_page': '50',
      };
      if (search != null && search.isNotEmpty) {
        queryParams['search'] = search;
      }

      final response =
          await _apiClient.get(ApiEndpoints.groups, queryParams: queryParams);
      if (response.isSuccess) {
        final data = response.data;
        if (data is List) {
          _groups = data.map((e) => GroupModel.fromJson(e)).toList();
        }
        await _offlineService.cacheData('groups', _groups.map((g) => g.toJson()).toList());
        notifyListeners();
      }
    } catch (e) {
      final cached = _offlineService.getCachedData<dynamic>('groups', (d) => d);
      if (cached is List) {
        _groups = cached.map((e) => GroupModel.fromJson(e as Map<String, dynamic>)).toList();
      }
      debugPrint('Groups fetch failed: $e');
    }
    _setLoading(false);
  }

  Future<void> fetchGroupDetail(String groupId) async {
    _setLoading(true);
    try {
      final response = await _apiClient.get(ApiEndpoints.groupById(groupId));
      if (response.isSuccess && response.data != null) {
        _selectedGroup =
            GroupModel.fromJson(response.data as Map<String, dynamic>);
        notifyListeners();
      }
    } catch (e) {
      debugPrint('Group detail fetch failed: $e');
    }
    _setLoading(false);
  }

  Future<bool> createGroup(Map<String, dynamic> groupData) async {
    _setLoading(true);
    try {
      final response = await _apiClient.post(
        ApiEndpoints.groups,
        body: groupData,
      );
      if (response.isSuccess) {
        await fetchGroups();
        _setLoading(false);
        return true;
      }
      _setLoading(false);
      return false;
    } catch (e) {
      _setError(e.toString());
      _setLoading(false);
      return false;
    }
  }

  // Members
  Future<void> fetchMembers({String? search, int page = 1}) async {
    _setLoading(true);
    try {
      final queryParams = <String, String>{
        'page': page.toString(),
        'per_page': '50',
        'with': 'savings,loans,group',
      };
      if (search != null && search.isNotEmpty) {
        queryParams['search'] = search;
      }

      final response =
          await _apiClient.get(ApiEndpoints.members, queryParams: queryParams);
      if (response.isSuccess) {
        final data = response.data;
        if (data is List) {
          _members = data.map((e) => MemberModel.fromJson(e)).toList();
        }
        await _offlineService.cacheData('members', _members.map((m) => m.toJson()).toList());
        notifyListeners();
      }
    } catch (e) {
      final cached = _offlineService.getCachedData<dynamic>('members', (d) => d);
      if (cached is List) {
        _members = cached.map((e) => MemberModel.fromJson(e as Map<String, dynamic>)).toList();
      }
      debugPrint('Members fetch failed: $e');
    }
    _setLoading(false);
  }

  Future<void> fetchMemberDetail(String memberId) async {
    _setLoading(true);
    try {
      final response =
          await _apiClient.get(ApiEndpoints.memberById(memberId));
      if (response.isSuccess && response.data != null) {
        _selectedMember =
            MemberModel.fromJson(response.data as Map<String, dynamic>);
        notifyListeners();
      }
    } catch (e) {
      debugPrint('Member detail fetch failed: $e');
    }
    _setLoading(false);
  }

  Future<bool> addMember(Map<String, dynamic> memberData) async {
    _setLoading(true);
    try {
      if (!_offlineService.isOnline) {
        await _offlineService.addToSyncQueue({
          'endpoint': ApiEndpoints.members,
          'method': 'POST',
          'body': memberData,
        });
        _setLoading(false);
        return true;
      }

      final response = await _apiClient.post(
        ApiEndpoints.members,
        body: memberData,
      );
      if (response.isSuccess) {
        await fetchMembers();
        _setLoading(false);
        return true;
      }
      _setLoading(false);
      return false;
    } catch (e) {
      _setError(e.toString());
      _setLoading(false);
      return false;
    }
  }

  Future<bool> updateMember(String memberId, Map<String, dynamic> data) async {
    _setLoading(true);
    try {
      final response = await _apiClient.put(
        ApiEndpoints.memberById(memberId),
        body: data,
      );
      if (response.isSuccess) {
        await fetchMemberDetail(memberId);
        _setLoading(false);
        return true;
      }
      _setLoading(false);
      return false;
    } catch (e) {
      _setError(e.toString());
      _setLoading(false);
      return false;
    }
  }

  // Meetings
  Future<void> fetchMeetings({String? groupId, int page = 1}) async {
    _setLoading(true);
    try {
      final queryParams = <String, String>{
        'page': page.toString(),
        'per_page': '50',
      };
      if (groupId != null) queryParams['group_id'] = groupId;

      final response =
          await _apiClient.get(ApiEndpoints.meetings, queryParams: queryParams);
      if (response.isSuccess) {
        final data = response.data;
        if (data is List) {
          _meetings = data.map((e) => MeetingModel.fromJson(e)).toList();
        }
        notifyListeners();
      }
    } catch (e) {
      debugPrint('Meetings fetch failed: $e');
    }
    _setLoading(false);
  }

  Future<bool> createMeeting(Map<String, dynamic> meetingData) async {
    try {
      final response = await _apiClient.post(
        ApiEndpoints.meetings,
        body: meetingData,
      );
      if (response.isSuccess) {
        await fetchMeetings();
        return true;
      }
      return false;
    } catch (e) {
      _setError(e.toString());
      return false;
    }
  }

  // Loans
  Future<void> fetchLoans({
    String? memberId,
    String? groupId,
    String? status,
    int page = 1,
  }) async {
    _setLoading(true);
    try {
      final queryParams = <String, String>{
        'page': page.toString(),
        'per_page': '50',
      };
      if (memberId != null) queryParams['member_id'] = memberId;
      if (groupId != null) queryParams['group_id'] = groupId;
      if (status != null) queryParams['status'] = status;

      final response =
          await _apiClient.get(ApiEndpoints.loans, queryParams: queryParams);
      if (response.isSuccess) {
        final data = response.data;
        if (data is List) {
          _loans = data.map((e) => LoanModel.fromJson(e)).toList();
        }
        notifyListeners();
      }
    } catch (e) {
      debugPrint('Loans fetch failed: $e');
    }
    _setLoading(false);
  }

  Future<bool> applyLoan(Map<String, dynamic> loanData) async {
    try {
      final response = await _apiClient.post(
        ApiEndpoints.loans,
        body: loanData,
      );
      if (response.isSuccess) {
        await fetchLoans();
        return true;
      }
      return false;
    } catch (e) {
      _setError(e.toString());
      return false;
    }
  }

  Future<bool> makeRepayment(Map<String, dynamic> repaymentData) async {
    try {
      final loanId = repaymentData['loan_id'];
      final response = await _apiClient.post(
        ApiEndpoints.loanRepayments(loanId),
        body: repaymentData,
      );
      if (response.isSuccess) {
        await fetchLoans();
        return true;
      }
      return false;
    } catch (e) {
      _setError(e.toString());
      return false;
    }
  }

  // Savings
  Future<void> fetchSavingsAccounts({String? memberId}) async {
    try {
      final queryParams = <String, String>{};
      if (memberId != null) queryParams['member_id'] = memberId;

      final response =
          await _apiClient.get(ApiEndpoints.savings, queryParams: queryParams);
      if (response.isSuccess) {
        final data = response.data;
        if (data is List) {
          _savingsAccounts =
              data.map((e) => SavingsAccountModel.fromJson(e)).toList();
        }
        notifyListeners();
      }
    } catch (e) {
      debugPrint('Savings accounts fetch failed: $e');
    }
  }

  Future<bool> processDeposit(Map<String, dynamic> depositData) async {
    try {
      final accountId = depositData['savings_account_id'];
      final response = await _apiClient.post(
        ApiEndpoints.savingDeposit(accountId),
        body: depositData,
      );
      if (response.isSuccess) {
        await fetchSavingsAccounts();
        return true;
      }
      return false;
    } catch (e) {
      _setError(e.toString());
      return false;
    }
  }

  // Transactions
  Future<void> fetchTransactions({
    String? memberId,
    String? groupId,
    int page = 1,
  }) async {
    _setLoading(true);
    try {
      final queryParams = <String, String>{
        'page': page.toString(),
        'per_page': '50',
      };
      if (memberId != null) queryParams['member_id'] = memberId;
      if (groupId != null) queryParams['group_id'] = groupId;

      final response = await _apiClient.get(
        ApiEndpoints.transactions,
        queryParams: queryParams,
      );
      if (response.isSuccess) {
        final data = response.data;
        if (data is List) {
          _transactions =
              data.map((e) => TransactionModel.fromJson(e)).toList();
        }
        notifyListeners();
      }
    } catch (e) {
      debugPrint('Transactions fetch failed: $e');
    }
    _setLoading(false);
  }

  // Sync
  Future<bool> syncAll() async {
    return await _syncService.syncAll();
  }

  // Theme
  void toggleDarkMode() {
    _isDarkMode = !_isDarkMode;
    notifyListeners();
  }

  // Error handling
  void clearError() {
    _clearError();
  }

  // Notifications
  Future<void> fetchNotifications() async {
    final list = await _notificationService.fetchNotifications();
    _notifications = list;
    notifyListeners();
  }

  Future<bool> markNotificationRead(String id) async {
    final result = await _notificationService.markAsRead(id);
    if (result) {
      _notifications = _notificationService.notifications;
      notifyListeners();
    }
    return result;
  }

  Future<bool> markAllNotificationsRead() async {
    final result = await _notificationService.markAllAsRead();
    if (result) {
      _notifications = _notificationService.notifications;
      notifyListeners();
    }
    return result;
  }

  // Helpers
  void _setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }

  void _setError(String message) {
    _error = message;
    notifyListeners();
  }

  void _clearError() {
    _error = null;
    notifyListeners();
  }

  void _clearAllData() {
    _dashboardSummary = null;
    _groups = [];
    _members = [];
    _meetings = [];
    _savingsAccounts = [];
    _loans = [];
    _transactions = [];
    _notifications = [];
    _selectedGroup = null;
    _selectedMember = null;
    _selectedMeeting = null;
    _selectedLoan = null;
  }
}
