import 'package:flutter/material.dart';
import '../core/network/api_client.dart';
import '../core/constants/api_endpoints.dart';
import '../models/loan/loan_model.dart';

class LoanProvider extends ChangeNotifier {
  final ApiClient _apiClient = ApiClient();

  List<LoanModel> _loans = [];
  List<LoanModel> get loans => _loans;

  LoanModel? _selectedLoan;
  LoanModel? get selectedLoan => _selectedLoan;

  List<LoanRepaymentModel> _repayments = [];
  List<LoanRepaymentModel> get repayments => _repayments;

  List<LoanScheduleModel> _schedule = [];
  List<LoanScheduleModel> get schedule => _schedule;

  bool _isLoading = false;
  bool get isLoading => _isLoading;
  String? _error;
  String? get error => _error;

  int _currentPage = 1;
  bool _hasMore = true;
  bool get hasMore => _hasMore;

  // Dashboard stats
  int _activeLoansCount = 0;
  int get activeLoansCount => _activeLoansCount;
  int _defaultedLoansCount = 0;
  int get defaultedLoansCount => _defaultedLoansCount;
  int _pendingLoansCount = 0;
  int get pendingLoansCount => _pendingLoansCount;
  int _completedLoansCount = 0;
  int get completedLoansCount => _completedLoansCount;
  double _totalDisbursed = 0.0;
  double get totalDisbursed => _totalDisbursed;
  double _totalOutstanding = 0.0;
  double get totalOutstanding => _totalOutstanding;
  double _totalRecovered = 0.0;
  double get totalRecovered => _totalRecovered;
  double _portfolioAtRisk = 0.0;
  double get portfolioAtRisk => _portfolioAtRisk;

  Future<void> fetchLoans({
    String? memberId,
    String? groupId,
    String? status,
    int page = 1,
    bool refresh = false,
  }) async {
    if (refresh) {
      _currentPage = 1;
      _hasMore = true;
    }
    _setLoading(true);
    try {
      final queryParams = <String, String>{
        'page': _currentPage.toString(),
        'per_page': '50',
        'with': 'member,group,repayments,guarantors',
      };
      if (memberId != null) queryParams['member_id'] = memberId;
      if (groupId != null) queryParams['group_id'] = groupId;
      if (status != null) queryParams['status'] = status;

      final response =
          await _apiClient.get(ApiEndpoints.loans, queryParams: queryParams);
      if (response.isSuccess) {
        final data = response.data;
        if (data is List) {
          final fetched = data.map((e) => LoanModel.fromJson(e)).toList();
          if (refresh || _currentPage == 1) {
            _loans = fetched;
          } else {
            _loans.addAll(fetched);
          }
          _hasMore = fetched.length >= 50;
          _currentPage++;
          _computeStats();
          notifyListeners();
        }
      }
    } catch (e) {
      _setError('Failed to load loans: $e');
    }
    _setLoading(false);
  }

  Future<void> fetchLoanDetail(String loanId) async {
    _setLoading(true);
    try {
      final response = await _apiClient.get(ApiEndpoints.loanById(loanId));
      if (response.isSuccess && response.data != null) {
        _selectedLoan =
            LoanModel.fromJson(response.data as Map<String, dynamic>);
        notifyListeners();
      }
    } catch (e) {
      _setError('Failed to load loan details: $e');
    }
    _setLoading(false);
  }

  Future<void> fetchLoanRepayments(String loanId) async {
    try {
      final response =
          await _apiClient.get(ApiEndpoints.loanRepayments(loanId));
      if (response.isSuccess && response.data is List) {
        _repayments = (response.data as List)
            .map((e) => LoanRepaymentModel.fromJson(e))
            .toList();
        notifyListeners();
      }
    } catch (e) {
      _setError('Failed to load repayments: $e');
    }
  }

  Future<void> fetchLoanSchedule(String loanId) async {
    try {
      final response = await _apiClient.get(ApiEndpoints.loanSchedule(loanId));
      if (response.isSuccess && response.data is List) {
        _schedule = (response.data as List)
            .map((e) => LoanScheduleModel.fromJson(e))
            .toList();
        notifyListeners();
      }
    } catch (e) {
      _setError('Failed to load schedule: $e');
    }
  }

  Future<bool> applyLoan(Map<String, dynamic> loanData) async {
    _setLoading(true);
    try {
      final response =
          await _apiClient.post(ApiEndpoints.loans, body: loanData);
      if (response.isSuccess) {
        await fetchLoans(refresh: true);
        _setLoading(false);
        return true;
      }
      _setLoading(false);
      return false;
    } catch (e) {
      _setError('Failed to apply loan: $e');
      _setLoading(false);
      return false;
    }
  }

  Future<bool> approveLoan(String loanId, {String? notes}) async {
    _setLoading(true);
    try {
      final response = await _apiClient.post(
        ApiEndpoints.loanApproval(loanId),
        body: {'status': 'approved', 'notes': notes},
      );
      if (response.isSuccess) {
        await fetchLoanDetail(loanId);
        await fetchLoans(refresh: true);
        _setLoading(false);
        return true;
      }
      _setLoading(false);
      return false;
    } catch (e) {
      _setError('Failed to approve loan: $e');
      _setLoading(false);
      return false;
    }
  }

  Future<bool> rejectLoan(String loanId, {String? reason}) async {
    _setLoading(true);
    try {
      final response = await _apiClient.post(
        ApiEndpoints.loanApproval(loanId),
        body: {'status': 'rejected', 'rejection_reason': reason},
      );
      if (response.isSuccess) {
        await fetchLoans(refresh: true);
        _setLoading(false);
        return true;
      }
      _setLoading(false);
      return false;
    } catch (e) {
      _setError('Failed to reject loan: $e');
      _setLoading(false);
      return false;
    }
  }

  Future<bool> disburseLoan(String loanId, {double? amount}) async {
    _setLoading(true);
    try {
      final response = await _apiClient.post(
        ApiEndpoints.loanDisbursement(loanId),
        body: {'disbursed_amount': amount},
      );
      if (response.isSuccess) {
        await fetchLoanDetail(loanId);
        await fetchLoans(refresh: true);
        _setLoading(false);
        return true;
      }
      _setLoading(false);
      return false;
    } catch (e) {
      _setError('Failed to disburse loan: $e');
      _setLoading(false);
      return false;
    }
  }

  Future<bool> makeRepayment(Map<String, dynamic> repaymentData) async {
    _setLoading(true);
    try {
      final loanId = repaymentData['loan_id'];
      final response = await _apiClient.post(
        ApiEndpoints.loanRepayments(loanId),
        body: repaymentData,
      );
      if (response.isSuccess) {
        await fetchLoanRepayments(loanId);
        await fetchLoanDetail(loanId);
        await fetchLoans(refresh: true);
        _setLoading(false);
        return true;
      }
      _setLoading(false);
      return false;
    } catch (e) {
      _setError('Failed to process repayment: $e');
      _setLoading(false);
      return false;
    }
  }

  Future<bool> restructureLoan(String loanId,
      Map<String, dynamic> restructureData) async {
    _setLoading(true);
    try {
      final response = await _apiClient.post(
        ApiEndpoints.loanRestructure(loanId),
        body: restructureData,
      );
      if (response.isSuccess) {
        await fetchLoanDetail(loanId);
        _setLoading(false);
        return true;
      }
      _setLoading(false);
      return false;
    } catch (e) {
      _setError('Failed to restructure loan: $e');
      _setLoading(false);
      return false;
    }
  }

  Future<bool> writeOffLoan(String loanId, {String? reason}) async {
    _setLoading(true);
    try {
      final response = await _apiClient.post(
        ApiEndpoints.loanWriteOff(loanId),
        body: {'reason': reason},
      );
      if (response.isSuccess) {
        await fetchLoanDetail(loanId);
        _setLoading(false);
        return true;
      }
      _setLoading(false);
      return false;
    } catch (e) {
      _setError('Failed to write off loan: $e');
      _setLoading(false);
      return false;
    }
  }

  Future<bool> addGuarantor(
      String loanId, Map<String, dynamic> guarantorData) async {
    try {
      final response = await _apiClient.post(
        ApiEndpoints.loanGuarantors(loanId),
        body: guarantorData,
      );
      if (response.isSuccess) {
        await fetchLoanDetail(loanId);
        return true;
      }
      return false;
    } catch (e) {
      _setError('Failed to add guarantor: $e');
      return false;
    }
  }

  void _computeStats() {
    _activeLoansCount = _loans.where((l) => l.isActive).length;
    _defaultedLoansCount = _loans.where((l) => l.isDefaulted).length;
    _pendingLoansCount = _loans.where((l) => l.isPending).length;
    _completedLoansCount = _loans.where((l) => l.isCompleted).length;
    _totalDisbursed = _loans.fold<double>(
        0, (sum, l) => sum + (l.disbursedAmount ?? 0));
    _totalOutstanding = _loans.fold<double>(
        0, (sum, l) => sum + (l.outstandingAmount ?? 0));
    _totalRecovered = _loans.fold<double>(
        0, (sum, l) => sum + (l.totalPaid ?? 0));

    if (_totalDisbursed > 0) {
      _portfolioAtRisk =
          (_loans.where((l) => l.isDefaulted || l.isOverdue).fold<double>(
                  0, (sum, l) => sum + (l.outstandingAmount ?? 0)) /
              _totalDisbursed *
              100);
    }
  }

  void selectLoan(LoanModel? loan) {
    _selectedLoan = loan;
    if (loan != null) {
      fetchLoanRepayments(loan.id);
      fetchLoanSchedule(loan.id);
    }
    notifyListeners();
  }

  void clearSelection() {
    _selectedLoan = null;
    _repayments = [];
    _schedule = [];
    notifyListeners();
  }

  void _setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }

  void _setError(String message) {
    _error = message;
    notifyListeners();
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}
