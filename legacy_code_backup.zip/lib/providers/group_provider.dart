import 'package:flutter/material.dart';
import '../core/network/api_client.dart';
import '../core/constants/api_endpoints.dart';
import '../models/group/group_model.dart';
import '../services/offline_service.dart';

class GroupProvider extends ChangeNotifier {
  final ApiClient _apiClient = ApiClient();
  final OfflineService _offlineService = OfflineService();

  List<GroupModel> _groups = [];
  List<GroupModel> get groups => _groups;

  GroupModel? _selectedGroup;
  GroupModel? get selectedGroup => _selectedGroup;

  List<GroupLeaderModel> _leaders = [];
  List<GroupLeaderModel> get leaders => _leaders;

  bool _isLoading = false;
  bool get isLoading => _isLoading;

  String? _error;
  String? get error => _error;

  final int _totalCount = 0;
  int get totalCount => _totalCount;

  int _currentPage = 1;
  int get currentPage => _currentPage;
  bool _hasMore = true;
  bool get hasMore => _hasMore;

  Future<void> fetchGroups({
    String? search,
    String? status,
    String? county,
    int page = 1,
    bool refresh = false,
  }) async {
    if (refresh) {
      _currentPage = 1;
      _hasMore = true;
    }

    _setLoading(true);
    try {
      final queryParams = <String, String>{
        'page': _currentPage.toString(),
        'per_page': '50',
        'with': 'leaders,members_count,financials',
      };
      if (search != null && search.isNotEmpty) queryParams['search'] = search;
      if (status != null) queryParams['status'] = status;
      if (county != null) queryParams['county'] = county;

      final response =
          await _apiClient.get(ApiEndpoints.groups, queryParams: queryParams);
      if (response.isSuccess) {
        final data = response.data;
        if (data is List) {
          final fetched = data.map((e) => GroupModel.fromJson(e)).toList();
          if (refresh || _currentPage == 1) {
            _groups = fetched;
          } else {
            _groups.addAll(fetched);
          }
          _hasMore = fetched.length >= 50;
          _currentPage++;
        }
        await _offlineService.cacheData('groups',
            _groups.map((g) => g.toJson()).toList());
        notifyListeners();
      }
    } catch (e) {
      if (_groups.isEmpty) {
        final cached = _offlineService.getCachedData<dynamic>('groups', (d) => d);
        if (cached is List) {
          _groups = cached.map((e) => GroupModel.fromJson(e as Map<String, dynamic>)).toList();
        }
      }
      _setError('Failed to load groups: $e');
    }
    _setLoading(false);
  }

  Future<void> fetchGroupDetail(String groupId) async {
    _setLoading(true);
    try {
      final response =
          await _apiClient.get(ApiEndpoints.groupById(groupId));
      if (response.isSuccess && response.data != null) {
        _selectedGroup =
            GroupModel.fromJson(response.data as Map<String, dynamic>);
        _leaders = _selectedGroup?.leaders ?? [];
        notifyListeners();
      }
    } catch (e) {
      _setError('Failed to load group details: $e');
    }
    _setLoading(false);
  }

  Future<bool> createGroup(Map<String, dynamic> groupData) async {
    _setLoading(true);
    try {
      if (!_offlineService.isOnline) {
        await _offlineService.addToSyncQueue({
          'endpoint': ApiEndpoints.groups,
          'method': 'POST',
          'body': groupData,
        });
        _setLoading(false);
        return true;
      }

      final response =
          await _apiClient.post(ApiEndpoints.groups, body: groupData);
      if (response.isSuccess) {
        await fetchGroups(refresh: true);
        _setLoading(false);
        return true;
      }
      _setLoading(false);
      return false;
    } catch (e) {
      _setError('Failed to create group: $e');
      _setLoading(false);
      return false;
    }
  }

  Future<bool> updateGroup(String groupId, Map<String, dynamic> data) async {
    _setLoading(true);
    try {
      final response =
          await _apiClient.put(ApiEndpoints.groupById(groupId), body: data);
      if (response.isSuccess) {
        await fetchGroupDetail(groupId);
        await fetchGroups(refresh: true);
        _setLoading(false);
        return true;
      }
      _setLoading(false);
      return false;
    } catch (e) {
      _setError('Failed to update group: $e');
      _setLoading(false);
      return false;
    }
  }

  Future<bool> approveGroup(String groupId) async {
    return updateGroup(groupId, {'status': 'active', 'approval_date': DateTime.now().toIso8601String()});
  }

  Future<bool> suspendGroup(String groupId) async {
    return updateGroup(groupId, {'status': 'suspended'});
  }

  Future<bool> dissolveGroup(String groupId) async {
    return updateGroup(groupId, {'status': 'dissolved'});
  }

  Future<bool> deleteGroup(String groupId) async {
    _setLoading(true);
    try {
      final response = await _apiClient.delete(ApiEndpoints.groupById(groupId));
      if (response.isSuccess) {
        _groups.removeWhere((g) => g.id == groupId);
        notifyListeners();
        _setLoading(false);
        return true;
      }
      _setLoading(false);
      return false;
    } catch (e) {
      _setError('Failed to delete group: $e');
      _setLoading(false);
      return false;
    }
  }

  Future<bool> addLeader(String groupId, Map<String, dynamic> leaderData) async {
    try {
      final response = await _apiClient.post(
        ApiEndpoints.groupLeaders(groupId),
        body: leaderData,
      );
      if (response.isSuccess) {
        await fetchGroupDetail(groupId);
        return true;
      }
      return false;
    } catch (e) {
      _setError('Failed to add leader: $e');
      return false;
    }
  }

  Future<bool> removeLeader(String groupId, String leaderId) async {
    try {
      final response = await _apiClient.delete(
        '${ApiEndpoints.groupLeaders(groupId)}/$leaderId',
      );
      if (response.isSuccess) {
        _leaders.removeWhere((l) => l.id == leaderId);
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      _setError('Failed to remove leader: $e');
      return false;
    }
  }

  void selectGroup(GroupModel? group) {
    _selectedGroup = group;
    notifyListeners();
  }

  void clearSelection() {
    _selectedGroup = null;
    _leaders = [];
    notifyListeners();
  }

  void _setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }

  void _setError(String message) {
    _error = message;
    notifyListeners();
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}
