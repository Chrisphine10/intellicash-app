import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../../providers/member_provider.dart';
import '../../providers/savings_provider.dart';
import '../../providers/loan_provider.dart';
import '../../models/member/member_model.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/helpers.dart';
import '../../widgets/common/status_badge.dart';

class MemberDetailScreen extends StatefulWidget {
  final String memberId;
  final String memberName;
  const MemberDetailScreen({
    super.key,
    required this.memberId,
    required this.memberName,
  });

  @override
  State<MemberDetailScreen> createState() => _MemberDetailScreenState();
}

class _MemberDetailScreenState extends State<MemberDetailScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<MemberProvider>().fetchMemberDetail(widget.memberId);
      context.read<SavingsProvider>().fetchAccounts(memberId: widget.memberId);
      context.read<LoanProvider>().fetchLoans(memberId: widget.memberId);
    });
  }

  @override
  Widget build(BuildContext context) {
    final memberProvider = context.watch<MemberProvider>();
    final member = memberProvider.selectedMember;
    final savingsProvider = context.watch<SavingsProvider>();
    final loanProvider = context.watch<LoanProvider>();

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.memberName,
            style: GoogleFonts.inter(fontWeight: FontWeight.w600)),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit_outlined),
            onPressed: () => _editMember(context, member),
          ),
        ],
      ),
      body: member == null || memberProvider.isLoading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: () async {
                await context
                    .read<MemberProvider>()
                    .fetchMemberDetail(widget.memberId);
              },
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  _ProfileCard(member: member),
                  const SizedBox(height: 16),
                  _ContactCard(member: member),
                  const SizedBox(height: 16),
                  _FinancialCard(
                      savings: savingsProvider.totalSavings,
                      loans: loanProvider.totalOutstanding),
                  const SizedBox(height: 16),
                  _SavingsAccountsCard(accounts: savingsProvider.accounts),
                  const SizedBox(height: 16),
                  _LoansCard(loans: loanProvider.loans),
                  if (member.documents != null &&
                      member.documents!.isNotEmpty) ...[
                    const SizedBox(height: 16),
                    _DocumentsCard(documents: member.documents!),
                  ],
                ],
              ),
            ),
    );
  }

  void _editMember(BuildContext context, MemberModel? member) {
    if (member == null) return;
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => EditMemberScreen(existingMember: member),
      ),
    );
  }
}

class _ProfileCard extends StatelessWidget {
  final MemberModel member;
  const _ProfileCard({required this.member});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Row(
          children: [
            CircleAvatar(
              radius: 36,
              backgroundColor: AppColors.primary.withAlpha(30),
              child: Text(member.initials,
                  style: GoogleFonts.inter(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: AppColors.primary)),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(member.displayName,
                      style: GoogleFonts.inter(
                          fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 4),
                  if (member.memberNo != null)
                    Text('Member #: ${member.memberNo}',
                        style: GoogleFonts.inter(
                            fontSize: 13, color: Colors.grey[600])),
                  const SizedBox(height: 8),
                  StatusBadge(
                    status: member.statusText,
                    isActive: member.isActive,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ContactCard extends StatelessWidget {
  final MemberModel member;
  const _ContactCard({required this.member});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Contact Information',
                style: GoogleFonts.inter(
                    fontSize: 16, fontWeight: FontWeight.w600)),
            const SizedBox(height: 12),
            ...[
              ('Email', member.email, Icons.email_outlined),
              ('Phone', member.phone, Icons.phone_outlined),
              ('Gender', Helpers.genderDisplay(member.gender),
                  Icons.person_outline),
              ('Occupation', member.occupation, Icons.work_outline),
              ('National ID', member.nationalId, Icons.badge_outlined),
            ].where((t) => t.$2 != null && t.$2!.isNotEmpty).map(
                  (t) => Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Row(
                      children: [
                        Icon(t.$3, size: 18, color: Colors.grey[500]),
                        const SizedBox(width: 12),
                        Text('${t.$1}: ',
                            style: GoogleFonts.inter(
                                fontSize: 13, color: Colors.grey[600])),
                        Expanded(
                          child: Text(t.$2!,
                              style: GoogleFonts.inter(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w500)),
                        ),
                      ],
                    ),
                  ),
                ),
          ],
        ),
      ),
    );
  }
}

class _FinancialCard extends StatelessWidget {
  final double savings;
  final double loans;
  const _FinancialCard({required this.savings, required this.loans});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Expanded(
              child: Column(
                children: [
                  Icon(Icons.savings_outlined,
                      size: 28, color: AppColors.success),
                  const SizedBox(height: 8),
                  Text('Savings',
                      style: GoogleFonts.inter(
                          fontSize: 12, color: Colors.grey[600])),
                  const SizedBox(height: 4),
                  Text(Helpers.formatCurrency(savings),
                      style: GoogleFonts.inter(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: AppColors.success)),
                ],
              ),
            ),
            Container(height: 40, width: 1, color: Colors.grey[300]),
            Expanded(
              child: Column(
                children: [
                  Icon(Icons.account_balance_outlined,
                      size: 28, color: AppColors.warning),
                  const SizedBox(height: 8),
                  Text('Loans O/S',
                      style: GoogleFonts.inter(
                          fontSize: 12, color: Colors.grey[600])),
                  const SizedBox(height: 4),
                  Text(Helpers.formatCurrency(loans),
                      style: GoogleFonts.inter(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: AppColors.warning)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SavingsAccountsCard extends StatelessWidget {
  final List<dynamic> accounts;
  const _SavingsAccountsCard({required this.accounts});

  @override
  Widget build(BuildContext context) {
    if (accounts.isEmpty) return const SizedBox.shrink();
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Savings Accounts',
                style: GoogleFonts.inter(
                    fontSize: 16, fontWeight: FontWeight.w600)),
            const SizedBox(height: 12),
            ...accounts.take(3).map((acc) => Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: AppColors.success.withAlpha(20),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Icon(Icons.account_balance,
                            size: 18, color: AppColors.success),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(acc.savingsTypeDisplay ?? 'Savings',
                                style: GoogleFonts.inter(
                                    fontWeight: FontWeight.w500)),
                            Text(acc.accountNumber ?? '',
                                style: GoogleFonts.inter(
                                    fontSize: 12, color: Colors.grey[600])),
                          ],
                        ),
                      ),
                      Text(Helpers.formatCurrency(acc.balance),
                          style: GoogleFonts.inter(
                              fontWeight: FontWeight.bold,
                              color: AppColors.success)),
                    ],
                  ),
                )),
          ],
        ),
      ),
    );
  }
}

class _LoansCard extends StatelessWidget {
  final List<dynamic> loans;
  const _LoansCard({required this.loans});

  @override
  Widget build(BuildContext context) {
    if (loans.isEmpty) return const SizedBox.shrink();
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Loans',
                style: GoogleFonts.inter(
                    fontSize: 16, fontWeight: FontWeight.w600)),
            const SizedBox(height: 12),
            ...loans.take(3).map((loan) => Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: AppColors.warning.withAlpha(20),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Icon(Icons.account_balance,
                            size: 18, color: AppColors.warning),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(loan.loanProduct ?? 'Loan',
                                style: GoogleFonts.inter(
                                    fontWeight: FontWeight.w500)),
                            Text(loan.statusText ?? '',
                                style: GoogleFonts.inter(
                                    fontSize: 12, color: Colors.grey[600])),
                          ],
                        ),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(Helpers.formatCurrency(
                              loan.outstandingAmount ?? 0),
                              style: GoogleFonts.inter(
                                  fontWeight: FontWeight.bold,
                                  color: AppColors.warning)),
                          Text('O/S',
                              style: GoogleFonts.inter(
                                  fontSize: 11, color: Colors.grey[600])),
                        ],
                      ),
                    ],
                  ),
                )),
          ],
        ),
      ),
    );
  }
}

class _DocumentsCard extends StatelessWidget {
  final List<MemberDocumentModel> documents;
  const _DocumentsCard({required this.documents});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Documents',
                style: GoogleFonts.inter(
                    fontSize: 16, fontWeight: FontWeight.w600)),
            const SizedBox(height: 12),
            ...documents.map((doc) => ListTile(
                  leading: const Icon(Icons.description_outlined),
                  title: Text(doc.name ?? 'Document',
                      style: GoogleFonts.inter(fontWeight: FontWeight.w500)),
                  subtitle: Text(doc.type ?? '',
                      style: GoogleFonts.inter(fontSize: 12)),
                  trailing: const Icon(Icons.download, size: 18),
                  dense: true,
                  contentPadding: EdgeInsets.zero,
                )),
          ],
        ),
      ),
    );
  }
}

class EditMemberScreen extends StatefulWidget {
  final MemberModel? existingMember;
  const EditMemberScreen({super.key, this.existingMember});

  @override
  State<EditMemberScreen> createState() => _EditMemberScreenState();
}

class _EditMemberScreenState extends State<EditMemberScreen> {
  final _formKey = GlobalKey<FormState>();
  final _firstNameController = TextEditingController();
  final _lastNameController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  final _nationalIdController = TextEditingController();
  final _occupationController = TextEditingController();
  String? _selectedGender;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    if (widget.existingMember != null) {
      _firstNameController.text = widget.existingMember!.firstName;
      _lastNameController.text = widget.existingMember!.lastName ?? '';
      _emailController.text = widget.existingMember!.email ?? '';
      _phoneController.text = widget.existingMember!.phone ?? '';
      _nationalIdController.text = widget.existingMember!.nationalId ?? '';
      _occupationController.text = widget.existingMember!.occupation ?? '';
      _selectedGender = widget.existingMember!.gender;
    }
  }

  @override
  void dispose() {
    _firstNameController.dispose();
    _lastNameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _nationalIdController.dispose();
    _occupationController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);
    final data = {
      'first_name': _firstNameController.text.trim(),
      'last_name': _lastNameController.text.trim(),
      'email': _emailController.text.trim(),
      'phone': _phoneController.text.trim(),
      'national_id': _nationalIdController.text.trim(),
      'occupation': _occupationController.text.trim(),
      'gender': _selectedGender,
    };

    final provider = context.read<MemberProvider>();
    bool success;
    if (widget.existingMember != null) {
      success =
          await provider.updateMember(widget.existingMember!.id, data);
    } else {
      success = await provider.addMember(data);
    }

    if (mounted) {
      setState(() => _isLoading = false);
      if (success) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(widget.existingMember != null
                ? 'Member updated successfully'
                : 'Member added successfully'),
            backgroundColor: AppColors.success,
            behavior: SnackBarBehavior.floating,
          ),
        );
        Navigator.pop(context, true);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(provider.error ?? 'Operation failed'),
            backgroundColor: AppTheme.errorColor,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.existingMember != null;
    return Scaffold(
      appBar: AppBar(
        title: Text(isEdit ? 'Edit Member' : 'Add Member',
            style: GoogleFonts.inter(fontWeight: FontWeight.w600)),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _firstNameController,
                decoration: const InputDecoration(
                  labelText: 'First Name *',
                  prefixIcon: Icon(Icons.person_outline),
                ),
                validator: (v) =>
                    v == null || v.trim().isEmpty ? 'Required' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _lastNameController,
                decoration: const InputDecoration(
                  labelText: 'Last Name',
                  prefixIcon: Icon(Icons.person_outline),
                ),
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _emailController,
                decoration: const InputDecoration(
                  labelText: 'Email',
                  prefixIcon: Icon(Icons.email_outlined),
                ),
                keyboardType: TextInputType.emailAddress,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _phoneController,
                decoration: const InputDecoration(
                  labelText: 'Phone',
                  prefixIcon: Icon(Icons.phone_outlined),
                ),
                keyboardType: TextInputType.phone,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _nationalIdController,
                decoration: const InputDecoration(
                  labelText: 'National ID',
                  prefixIcon: Icon(Icons.badge_outlined),
                ),
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _occupationController,
                decoration: const InputDecoration(
                  labelText: 'Occupation',
                  prefixIcon: Icon(Icons.work_outline),
                ),
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                initialValue: _selectedGender,
                decoration: const InputDecoration(
                  labelText: 'Gender',
                  prefixIcon: Icon(Icons.wc_outlined),
                ),
                items: ['Male', 'Female', 'Other']
                    .map((g) => DropdownMenuItem(value: g, child: Text(g)))
                    .toList(),
                onChanged: (v) => setState(() => _selectedGender = v),
              ),
              const SizedBox(height: 32),
              SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _submit,
                  child: _isLoading
                      ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.white))
                      : Text(isEdit ? 'Update Member' : 'Add Member'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
