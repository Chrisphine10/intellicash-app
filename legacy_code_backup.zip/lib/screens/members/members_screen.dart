import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../../providers/member_provider.dart';
import '../../models/member/member_model.dart';
import '../../core/theme/app_colors.dart';
import 'member_detail_screen.dart';
import 'add_member_screen.dart';

class MembersScreen extends StatefulWidget {
  const MembersScreen({super.key});

  @override
  State<MembersScreen> createState() => _MembersScreenState();
}

class _MembersScreenState extends State<MembersScreen> {
  final _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<MemberProvider>().fetchMembers();
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _onSearch(String query) {
    context.read<MemberProvider>().fetchMembers(search: query, refresh: true);
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<MemberProvider>();
    final members = provider.members;

    return Scaffold(
      appBar: AppBar(
        title: Text('Members',
            style: GoogleFonts.inter(fontWeight: FontWeight.w600)),
        actions: [
          IconButton(
            icon: const Icon(Icons.filter_list),
            onPressed: () => _showFilterDialog(context),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Search members...',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _searchController.clear();
                          _onSearch('');
                        },
                      )
                    : null,
              ),
              onChanged: (v) => setState(() {}),
              onSubmitted: _onSearch,
            ),
          ),
          Expanded(
            child: provider.isLoading && members.isEmpty
                ? const Center(child: CircularProgressIndicator())
                : members.isEmpty
                    ? _emptyState()
                    : RefreshIndicator(
                        onRefresh: () => provider.fetchMembers(refresh: true),
                        child: ListView.builder(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          itemCount: members.length + (provider.hasMore ? 1 : 0),
                          itemBuilder: (context, index) {
                            if (index >= members.length) {
                              provider.fetchMembers();
                              return const Center(
                                child: Padding(
                                  padding: EdgeInsets.all(16),
                                  child: CircularProgressIndicator(),
                                ),
                              );
                            }
                            return _MemberTile(member: members[index]);
                          },
                        ),
                      ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => const AddMemberScreen()),
          );
        },
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _emptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.people_outline, size: 64, color: Colors.grey[400]),
          const SizedBox(height: 16),
          Text('No members found',
              style: GoogleFonts.inter(
                  fontSize: 16, color: Colors.grey[600])),
          const SizedBox(height: 8),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const AddMemberScreen()),
              );
            },
            child: const Text('Add Member'),
          ),
        ],
      ),
    );
  }

  void _showFilterDialog(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Filter Members',
                style: GoogleFonts.inter(
                    fontSize: 18, fontWeight: FontWeight.w600)),
            const SizedBox(height: 16),
            const Text('Status'),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: ['All', 'Active', 'Inactive', 'Suspended']
                  .map((s) => ChoiceChip(
                        label: Text(s),
                        selected: s == 'All',
                      ))
                  .toList(),
            ),
            const SizedBox(height: 16),
            const Text('Gender'),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: ['All', 'Male', 'Female']
                  .map((s) => ChoiceChip(
                        label: Text(s),
                        selected: s == 'All',
                      ))
                  .toList(),
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Apply Filters'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MemberTile extends StatelessWidget {
  final MemberModel member;
  const _MemberTile({required this.member});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: CircleAvatar(
          radius: 22,
          backgroundColor:
              member.isActive ? AppColors.success.withAlpha(30) : Colors.grey[200],
          child: Text(member.initials,
              style: GoogleFonts.inter(
                  fontWeight: FontWeight.bold,
                  color: member.isActive ? AppColors.success : Colors.grey[600])),
        ),
        title: Text(member.displayName,
            style: GoogleFonts.inter(fontWeight: FontWeight.w600)),
        subtitle: Text(
          '${member.memberNo ?? ''}  •  ${member.groupName ?? member.branchName ?? 'N/A'}',
          style: GoogleFonts.inter(fontSize: 12, color: Colors.grey[600]),
        ),
        trailing: Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: member.isActive
                ? AppColors.success.withAlpha(20)
                : Colors.grey.withAlpha(20),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Text(member.statusText,
              style: GoogleFonts.inter(
                  fontSize: 11,
                  color: member.isActive ? AppColors.success : Colors.grey[600],
                  fontWeight: FontWeight.w500)),
        ),
        onTap: () {
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (_) => MemberDetailScreen(
                memberId: member.id,
                memberName: member.displayName,
              ),
            ),
          );
        },
      ),
    );
  }
}
