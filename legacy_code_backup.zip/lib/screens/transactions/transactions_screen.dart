import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../../providers/app_provider.dart';
import '../../models/transaction/transaction_model.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/helpers.dart';

class TransactionsScreen extends StatefulWidget {
  const TransactionsScreen({super.key});

  @override
  State<TransactionsScreen> createState() => _TransactionsScreenState();
}

class _TransactionsScreenState extends State<TransactionsScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<AppProvider>().fetchTransactions();
    });
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<AppProvider>();
    final transactions = provider.transactions;

    return Scaffold(
      appBar: AppBar(
        title: Text('Transactions',
            style: GoogleFonts.inter(fontWeight: FontWeight.w600)),
        actions: [
          IconButton(
            icon: const Icon(Icons.filter_list),
            onPressed: () {},
          ),
        ],
      ),
      body: provider.isLoading && transactions.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : transactions.isEmpty
              ? _emptyState()
              : RefreshIndicator(
                  onRefresh: () => provider.fetchTransactions(),
                  child: ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: transactions.length,
                    itemBuilder: (context, index) =>
                        _TransactionTile(transaction: transactions[index]),
                  ),
                ),
    );
  }

  Widget _emptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.swap_horiz, size: 64, color: Colors.grey[400]),
          const SizedBox(height: 16),
          Text('No transactions found',
              style: GoogleFonts.inter(
                  fontSize: 16, color: Colors.grey[600])),
        ],
      ),
    );
  }
}

class _TransactionTile extends StatelessWidget {
  final TransactionModel transaction;
  const _TransactionTile({required this.transaction});

  Color get _statusColor {
    if (transaction.isCompleted) return AppColors.success;
    if (transaction.isPending) return AppColors.warning;
    if (transaction.isRejected) return AppColors.error;
    return Colors.grey;
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => _showDetail(context),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: transaction.isCredit
                      ? AppColors.success.withAlpha(20)
                      : AppColors.error.withAlpha(20),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(
                  transaction.isCredit
                      ? Icons.arrow_downward
                      : Icons.arrow_upward,
                  color: transaction.isCredit
                      ? AppColors.success
                      : AppColors.error,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(transaction.typeDisplay,
                        style: GoogleFonts.inter(
                            fontWeight: FontWeight.w600, fontSize: 14)),
                    const SizedBox(height: 2),
                    Text(
                      '${transaction.memberName ?? ''}  •  ${transaction.transactionDate != null ? Helpers.formatDate(DateTime.parse(transaction.transactionDate!)) : ''}',
                      style: GoogleFonts.inter(
                          fontSize: 12, color: Colors.grey[600]),
                    ),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    '${transaction.isCredit ? '+' : '-'}${Helpers.formatCurrency(transaction.amount ?? 0)}',
                    style: GoogleFonts.inter(
                      fontWeight: FontWeight.bold,
                      color: transaction.isCredit
                          ? AppColors.success
                          : AppColors.error,
                      fontSize: 14,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: _statusColor.withAlpha(20),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(transaction.statusText,
                        style: GoogleFonts.inter(
                            fontSize: 10,
                            color: _statusColor,
                            fontWeight: FontWeight.w500)),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showDetail(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => DraggableScrollableSheet(
        initialChildSize: 0.6,
        maxChildSize: 0.85,
        minChildSize: 0.3,
        expand: false,
        builder: (ctx, scrollController) => Padding(
          padding: const EdgeInsets.all(24),
          child: ListView(
            controller: scrollController,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey[300],
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Text('Transaction Details',
                  style: GoogleFonts.inter(
                      fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 20),
              _DetailRow(
                  'Type', transaction.typeDisplay),
              _DetailRow(
                  'Amount',
                  Helpers.formatCurrency(transaction.amount ?? 0)),
              _DetailRow(
                  'Direction',
                  transaction.isCredit ? 'Credit' : 'Debit'),
              _DetailRow('Method', transaction.method ?? 'N/A'),
              _DetailRow('Status', transaction.statusText),
              _DetailRow('Member',
                  transaction.memberName ?? 'N/A'),
              _DetailRow('Description',
                  transaction.description ?? 'N/A'),
              _DetailRow(
                  'Reference',
                  transaction.reference ?? 'N/A'),
              _DetailRow(
                  'Date',
                  transaction.transactionDate != null
                      ? Helpers.formatDateTime(DateTime.parse(
                          transaction.transactionDate!))
                      : 'N/A'),
              if (transaction.receiptNumber != null)
                _DetailRow('Receipt',
                    transaction.receiptNumber!),
            ],
          ),
        ),
      ),
    );
  }
}

class _DetailRow extends StatelessWidget {
  final String label;
  final String value;
  const _DetailRow(this.label, this.value);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 100,
            child: Text(label,
                style: GoogleFonts.inter(
                    fontSize: 13, color: Colors.grey[600])),
          ),
          Expanded(
            child: Text(value,
                style: GoogleFonts.inter(
                    fontSize: 13, fontWeight: FontWeight.w500)),
          ),
        ],
      ),
    );
  }
}
