import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../../providers/app_provider.dart';
import '../../models/notification/notification_model.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/helpers.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<AppProvider>().fetchNotifications();
    });
  }

  @override
  Widget build(BuildContext context) {
    // We use AppProvider's notification service through a workaround
    // since notifications are managed through the service directly
    final notifications = <NotificationModel>[];

    return Scaffold(
      appBar: AppBar(
        title: Text('Notifications',
            style: GoogleFonts.inter(fontWeight: FontWeight.w600)),
        actions: [
          TextButton(
            onPressed: () => _markAllRead(context),
            child: const Text('Mark all read'),
          ),
        ],
      ),
      body: notifications.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.notifications_none,
                      size: 64, color: Colors.grey[400]),
                  const SizedBox(height: 16),
                  Text('No notifications',
                      style: GoogleFonts.inter(
                          fontSize: 16, color: Colors.grey[600])),
                ],
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: notifications.length,
              itemBuilder: (context, index) =>
                  _NotificationTile(notification: notifications[index]),
            ),
    );
  }

  void _markAllRead(BuildContext context) {
    context.read<AppProvider>().markAllNotificationsRead();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('All notifications marked as read'),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }
}

class _NotificationTile extends StatelessWidget {
  final NotificationModel notification;
  const _NotificationTile({required this.notification});

  IconData get _typeIcon {
    switch (notification.type) {
      case 'meeting':
        return Icons.event;
      case 'loan':
        return Icons.account_balance;
      case 'payment':
        return Icons.payment;
      case 'savings':
        return Icons.savings;
      case 'system':
        return Icons.system_update;
      case 'reminder':
        return Icons.alarm;
      default:
        return Icons.notifications;
    }
  }

  Color get _typeColor {
    switch (notification.type) {
      case 'meeting':
        return AppColors.primary;
      case 'loan':
        return AppColors.warning;
      case 'payment':
        return AppColors.success;
      case 'savings':
        return AppColors.info;
      case 'system':
        return Colors.grey;
      case 'reminder':
        return AppColors.secondary;
      default:
        return AppColors.info;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      color: notification.isRead ? null : AppColors.primary.withAlpha(8),
      child: ListTile(
        leading: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: _typeColor.withAlpha(20),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(_typeIcon, color: _typeColor, size: 20),
        ),
        title: Text(notification.title ?? '',
            style: GoogleFonts.inter(
                fontWeight:
                    notification.isRead ? FontWeight.normal : FontWeight.w600,
                fontSize: 14)),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 4),
            Text(notification.body ?? '',
                style: GoogleFonts.inter(
                    fontSize: 12, color: Colors.grey[600]),
                maxLines: 2,
                overflow: TextOverflow.ellipsis),
            const SizedBox(height: 4),
            Text(
              notification.createdAt != null
                  ? Helpers.timeAgo(notification.createdAt!)
                  : '',
              style: GoogleFonts.inter(
                  fontSize: 11, color: Colors.grey[400]),
            ),
          ],
        ),
        trailing: notification.isRead
            ? null
            : Container(
                width: 8,
                height: 8,
                decoration: const BoxDecoration(
                  color: AppColors.primary,
                  shape: BoxShape.circle,
                ),
              ),
        onTap: () {
          context.read<AppProvider>().markNotificationRead(notification.id);
        },
      ),
    );
  }
}
