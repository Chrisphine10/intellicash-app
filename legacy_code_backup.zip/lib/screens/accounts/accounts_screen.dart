import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../../providers/savings_provider.dart';
import '../../models/savings/savings_model.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/helpers.dart';

class AccountsScreen extends StatefulWidget {
  const AccountsScreen({super.key});

  @override
  State<AccountsScreen> createState() => _AccountsScreenState();
}

class _AccountsScreenState extends State<AccountsScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<SavingsProvider>().fetchAccounts();
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final savingsProvider = context.watch<SavingsProvider>();

    return Scaffold(
      appBar: AppBar(
        title: Text('Accounts',
            style: GoogleFonts.inter(fontWeight: FontWeight.w600)),
        bottom: TabBar(
          controller: _tabController,
          tabs: [
            Tab(text: 'Savings (${savingsProvider.accounts.length})'),
            const Tab(text: 'VSLA'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _SavingsTab(),
          _VSLATab(),
        ],
      ),
    );
  }
}

class _SavingsTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final provider = context.watch<SavingsProvider>();
    final accounts = provider.accounts;

    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              _SummaryCard(
                label: 'Total Savings',
                value: provider.totalSavings,
                color: AppColors.primary,
              ),
              const SizedBox(width: 12),
              _SummaryCard(
                label: 'Shares',
                value: provider.totalShares,
                color: AppColors.secondary,
              ),
              const SizedBox(width: 12),
              _SummaryCard(
                label: 'Social Fund',
                value: provider.totalSocialFund,
                color: AppColors.info,
              ),
            ],
          ),
        ),
        Expanded(
          child: accounts.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.account_balance_wallet_outlined,
                          size: 64, color: Colors.grey[400]),
                      const SizedBox(height: 16),
                      Text('No savings accounts',
                          style: GoogleFonts.inter(
                              fontSize: 16, color: Colors.grey[600])),
                    ],
                  ),
                )
              : RefreshIndicator(
                  onRefresh: () => provider.fetchAccounts(),
                  child: ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: accounts.length,
                    itemBuilder: (context, index) =>
                        _AccountCard(account: accounts[index]),
                  ),
                ),
        ),
      ],
    );
  }
}

class _SummaryCard extends StatelessWidget {
  final String label;
  final double value;
  final Color color;
  const _SummaryCard(
      {required this.label,
      required this.value,
      required this.color});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            children: [
              Text(Helpers.formatCurrency(value),
                  style: GoogleFonts.inter(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: color)),
              const SizedBox(height: 4),
              Text(label,
                  style: GoogleFonts.inter(
                      fontSize: 11, color: Colors.grey[600])),
            ],
          ),
        ),
      ),
    );
  }
}

class _AccountCard extends StatelessWidget {
  final SavingsAccountModel account;
  const _AccountCard({required this.account});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppColors.primary.withAlpha(20),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(Icons.account_balance,
                  color: AppColors.primary, size: 24),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(account.savingsTypeDisplay,
                      style: GoogleFonts.inter(
                          fontWeight: FontWeight.w600)),
                  const SizedBox(height: 4),
                  Text(account.accountNumber ?? 'No account #',
                      style: GoogleFonts.inter(
                          fontSize: 12, color: Colors.grey[600])),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(Helpers.formatCurrency(account.balance),
                    style: GoogleFonts.inter(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        color: account.balance > 0
                            ? AppColors.success
                            : Colors.grey)),
                Text(
                    account.isActive ? 'Active' : 'Inactive',
                    style: GoogleFonts.inter(
                        fontSize: 11,
                        color: account.isActive
                            ? AppColors.success
                            : Colors.grey[600])),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _VSLATab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.groups_outlined,
                size: 64, color: Colors.grey[400]),
            const SizedBox(height: 24),
            Text('VSLA Management',
                style: GoogleFonts.inter(
                    fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text(
              'Manage village savings and loan groups, track group savings, and monitor group financial health.',
              textAlign: TextAlign.center,
              style: GoogleFonts.inter(
                  fontSize: 14, color: Colors.grey[600]),
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: const Text('VSLA management coming soon'),
                    behavior: SnackBarBehavior.floating,
                  ),
                );
              },
              icon: const Icon(Icons.open_in_new),
              label: const Text('Open VSLA'),
            ),
          ],
        ),
      ),
    );
  }
}
