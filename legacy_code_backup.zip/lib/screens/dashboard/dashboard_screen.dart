import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:intl/intl.dart';
import '../../providers/app_provider.dart';
import '../../models/report/report_model.dart';
import '../../core/theme/app_colors.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<AppProvider>();
    final summary = provider.dashboardSummary;

    if (provider.isLoading && summary == null) {
      return const Center(child: CircularProgressIndicator());
    }

    if (summary == null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.cloud_off, size: 64, color: Colors.grey[400]),
            const SizedBox(height: 16),
            Text('Unable to load dashboard',
                style: GoogleFonts.inter(color: Colors.grey[600])),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: () => provider.fetchDashboard(),
              icon: const Icon(Icons.refresh),
              label: const Text('Retry'),
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: () => provider.fetchDashboard(),
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _WelcomeCard(summary: summary),
          const SizedBox(height: 16),
          _MetricsGrid(summary: summary),
          const SizedBox(height: 16),
          _SavingsChart(summary: summary),
          const SizedBox(height: 16),
          _LoanPerformanceCard(summary: summary),
          const SizedBox(height: 16),
          _AttendanceCard(summary: summary),
        ],
      ),
    );
  }
}

class _WelcomeCard extends StatelessWidget {
  final DashboardSummaryModel summary;
  const _WelcomeCard({required this.summary});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              theme.colorScheme.primary,
              theme.colorScheme.primary.withAlpha(180),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.account_balance_rounded,
                    size: 32, color: Colors.white),
                const SizedBox(width: 12),
                Text('Intelli-Cash',
                    style: GoogleFonts.inter(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white)),
              ],
            ),
            const SizedBox(height: 16),
            Text(
              DateFormat('EEEE, MMMM d, yyyy').format(DateTime.now()),
              style: GoogleFonts.inter(
                  fontSize: 14, color: Colors.white.withAlpha(200)),
            ),
            const SizedBox(height: 4),
            Text(
              '${summary.totalGroups} Groups | ${summary.totalMembers} Members',
              style: GoogleFonts.inter(
                  fontSize: 13, color: Colors.white.withAlpha(180)),
            ),
          ],
        ),
      ),
    );
  }
}

class _MetricsGrid extends StatelessWidget {
  final DashboardSummaryModel summary;
  const _MetricsGrid({required this.summary});

  @override
  Widget build(BuildContext context) {
    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      mainAxisSpacing: 12,
      crossAxisSpacing: 12,
      childAspectRatio: 1.6,
      children: [
        _MetricCard(
          title: 'Total Savings',
          value: summary.totalSavings,
          icon: Icons.savings_outlined,
          color: AppColors.primary,
        ),
        _MetricCard(
          title: 'Total Loans',
          value: summary.totalLoans,
          icon: Icons.account_balance_outlined,
          color: AppColors.secondary,
        ),
        _MetricCard(
          title: 'Outstanding',
          value: summary.outstandingLoans,
          icon: Icons.pending_actions_outlined,
          color: AppColors.warning,
        ),
        _MetricCard(
          title: 'Bank Balance',
          value: summary.totalBankBalance,
          icon: Icons.account_balance_wallet_outlined,
          color: AppColors.info,
        ),
      ],
    );
  }
}

class _MetricCard extends StatelessWidget {
  final String title;
  final double value;
  final IconData icon;
  final Color color;

  const _MetricCard({
    required this.title,
    required this.value,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: color.withAlpha(30),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(icon, size: 18, color: color),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(title,
                      style: GoogleFonts.inter(
                          fontSize: 12,
                          color: Colors.grey[600],
                          fontWeight: FontWeight.w500),
                      overflow: TextOverflow.ellipsis),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              NumberFormat.currency(symbol: 'KSh', decimalDigits: 0)
                  .format(value),
              style: GoogleFonts.inter(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: color),
            ),
          ],
        ),
      ),
    );
  }
}

class _SavingsChart extends StatelessWidget {
  final DashboardSummaryModel summary;
  const _SavingsChart({required this.summary});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Financial Overview',
                style: GoogleFonts.inter(
                    fontSize: 16, fontWeight: FontWeight.w600)),
            const SizedBox(height: 20),
            SizedBox(
              height: 200,
              child: BarChart(
                BarChartData(
                  alignment: BarChartAlignment.spaceAround,
                  maxY: [
                    summary.totalSavings,
                    summary.totalLoans,
                    summary.outstandingLoans,
                    summary.totalBankBalance,
                  ]
                      .reduce((a, b) => a > b ? a : b),
                  barGroups: [
                    _barGroup(0, 'Savings', summary.totalSavings,
                        AppColors.primary),
                    _barGroup(1, 'Loans', summary.totalLoans,
                        AppColors.secondary),
                    _barGroup(2, 'Outstanding', summary.outstandingLoans,
                        AppColors.warning),
                    _barGroup(3, 'Bank', summary.totalBankBalance,
                        AppColors.info),
                  ],
                  titlesData: FlTitlesData(
                    show: true,
                    bottomTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        getTitlesWidget: (value, meta) {
                          const labels = ['Savings', 'Loans', 'Out.', 'Bank'];
                          return Padding(
                            padding: const EdgeInsets.only(top: 8),
                            child: Text(labels[value.toInt()],
                                style: GoogleFonts.inter(fontSize: 11)),
                          );
                        },
                      ),
                    ),
                    leftTitles: const AxisTitles(
                      sideTitles: SideTitles(showTitles: false),
                    ),
                    topTitles: const AxisTitles(
                      sideTitles: SideTitles(showTitles: false),
                    ),
                    rightTitles: const AxisTitles(
                      sideTitles: SideTitles(showTitles: false),
                    ),
                  ),
                  borderData: FlBorderData(show: false),
                  gridData: const FlGridData(show: false),
                  barTouchData: BarTouchData(
                    touchTooltipData: BarTouchTooltipData(
                      getTooltipItem: (group, groupIndex, rod, rodIndex) {
                        return BarTooltipItem(
                          NumberFormat.currency(symbol: 'KSh')
                              .format(rod.toY),
                          TextStyle(
                              color: rod.color,
                              fontWeight: FontWeight.bold),
                        );
                      },
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  BarChartGroupData _barGroup(int x, String label, double y, Color color) {
    return BarChartGroupData(x: x, barRods: [
      BarChartRodData(
        toY: y > 0 ? y : 0.1,
        color: color,
        width: 28,
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(6),
          topRight: Radius.circular(6),
        ),
      ),
    ]);
  }
}

class _LoanPerformanceCard extends StatelessWidget {
  final DashboardSummaryModel summary;
  const _LoanPerformanceCard({required this.summary});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Loan Portfolio',
                style: GoogleFonts.inter(
                    fontSize: 16, fontWeight: FontWeight.w600)),
            const SizedBox(height: 16),
            Row(
              children: [
                _StatItem(
                  label: 'Active',
                  value: summary.activeLoanCount.toString(),
                  color: AppColors.success,
                ),
                _StatItem(
                  label: 'Defaulted',
                  value: summary.defaultedLoanCount.toString(),
                  color: AppColors.error,
                ),
                _StatItem(
                  label: 'PAR',
                  value: '${summary.portfolioAtRisk.toStringAsFixed(1)}%',
                  color: summary.portfolioAtRisk > 5
                      ? AppColors.error
                      : AppColors.warning,
                ),
                _StatItem(
                  label: 'Recovery',
                  value: '${summary.recoveryRate.toStringAsFixed(1)}%',
                  color: AppColors.success,
                ),
              ],
            ),
            const SizedBox(height: 16),
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: LinearProgressIndicator(
                value: summary.portfolioAtRisk / 100,
                backgroundColor: Colors.grey[200],
                color: summary.portfolioAtRisk > 10
                    ? AppColors.error
                    : AppColors.warning,
                minHeight: 8,
              ),
            ),
            const SizedBox(height: 4),
            Text('Portfolio at Risk',
                style: GoogleFonts.inter(
                    fontSize: 12, color: Colors.grey[500])),
          ],
        ),
      ),
    );
  }
}

class _StatItem extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  const _StatItem(
      {required this.label,
      required this.value,
      required this.color});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        children: [
          Text(value,
              style: GoogleFonts.inter(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: color)),
          const SizedBox(height: 4),
          Text(label,
              style: GoogleFonts.inter(
                  fontSize: 12, color: Colors.grey[600])),
        ],
      ),
    );
  }
}

class _AttendanceCard extends StatelessWidget {
  final DashboardSummaryModel summary;
  const _AttendanceCard({required this.summary});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Members Overview',
                style: GoogleFonts.inter(
                    fontSize: 16, fontWeight: FontWeight.w600)),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _InfoRow(
                        label: 'Total Members',
                        value: summary.totalMembers.toString(),
                      ),
                      const SizedBox(height: 8),
                      _InfoRow(
                        label: 'Active Members',
                        value: summary.activeMembers.toString(),
                      ),
                      const SizedBox(height: 8),
                      _InfoRow(
                        label: 'Total Meetings',
                        value: summary.totalMeetings.toString(),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 100,
                  width: 100,
                  child: PieChart(
                    PieChartData(
                      sections: [
                        PieChartSectionData(
                          value: summary.activeMembers.toDouble(),
                          color: AppColors.success,
                          radius: 30,
                          title:
                              '${summary.activeMembers}',
                          titleStyle: GoogleFonts.inter(
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              color: Colors.white),
                        ),
                        PieChartSectionData(
                          value: (summary.totalMembers -
                                  summary.activeMembers)
                              .toDouble(),
                          color: Colors.grey[300]!,
                          radius: 30,
                          title:
                              '${summary.totalMembers - summary.activeMembers}',
                          titleStyle: GoogleFonts.inter(
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              color: Colors.grey[600]),
                        ),
                      ],
                      sectionsSpace: 2,
                      centerSpaceRadius: 30,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _LegendDot(color: AppColors.success, label: 'Active'),
                const SizedBox(width: 16),
                _LegendDot(color: Colors.grey[300]!, label: 'Inactive'),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final String label;
  final String value;
  const _InfoRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text('$label: ',
            style: GoogleFonts.inter(
                fontSize: 13, color: Colors.grey[600])),
        Text(value,
            style: GoogleFonts.inter(
                fontSize: 13, fontWeight: FontWeight.w600)),
      ],
    );
  }
}

class _LegendDot extends StatelessWidget {
  final Color color;
  final String label;
  const _LegendDot({required this.color, required this.label});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 10,
          height: 10,
          decoration: BoxDecoration(
            color: color,
            shape: BoxShape.circle,
          ),
        ),
        const SizedBox(width: 4),
        Text(label,
            style: GoogleFonts.inter(
                fontSize: 12, color: Colors.grey[600])),
      ],
    );
  }
}
