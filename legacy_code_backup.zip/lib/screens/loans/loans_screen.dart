import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../../providers/loan_provider.dart';
import '../../models/loan/loan_model.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/helpers.dart';
import '../../widgets/common/status_badge.dart';

class LoansScreen extends StatefulWidget {
  const LoansScreen({super.key});

  @override
  State<LoansScreen> createState() => _LoansScreenState();
}

class _LoansScreenState extends State<LoansScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<LoanProvider>().fetchLoans();
    });
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<LoanProvider>();
    final loans = provider.loans;

    return Scaffold(
      appBar: AppBar(
        title: Text('Loans',
            style: GoogleFonts.inter(fontWeight: FontWeight.w600)),
        actions: [
          IconButton(
            icon: const Icon(Icons.filter_list),
            onPressed: () => _showFilterDialog(context),
          ),
        ],
      ),
      body: Column(
        children: [
          _StatsRow(provider: provider),
          Expanded(
            child: provider.isLoading && loans.isEmpty
                ? const Center(child: CircularProgressIndicator())
                : loans.isEmpty
                    ? _emptyState()
                    : RefreshIndicator(
                        onRefresh: () => provider.fetchLoans(refresh: true),
                        child: ListView.builder(
                          padding: const EdgeInsets.all(16),
                          itemCount: loans.length,
                          itemBuilder: (context, index) =>
                              _LoanCard(loan: loans[index]),
                        ),
                      ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showApplyLoanDialog(context),
        icon: const Icon(Icons.add),
        label: const Text('Apply'),
      ),
    );
  }

  Widget _emptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.account_balance_outlined,
              size: 64, color: Colors.grey[400]),
          const SizedBox(height: 16),
          Text('No loans found',
              style: GoogleFonts.inter(
                  fontSize: 16, color: Colors.grey[600])),
        ],
      ),
    );
  }

  void _showFilterDialog(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Filter Loans',
                style: GoogleFonts.inter(
                    fontSize: 18, fontWeight: FontWeight.w600)),
            const SizedBox(height: 16),
            const Text('Status'),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: [
                'all',
                'pending',
                'active',
                'completed',
                'defaulted'
              ].map((s) => ChoiceChip(
                    label: Text(s[0].toUpperCase() + s.substring(1)),
                    selected: s == 'all',
                    onSelected: (_) {
                      if (s != 'all') {
                        context
                            .read<LoanProvider>()
                            .fetchLoans(status: s, refresh: true);
                      } else {
                        context.read<LoanProvider>().fetchLoans(refresh: true);
                      }
                      Navigator.pop(ctx);
                    },
                  )).toList(),
            ),
          ],
        ),
      ),
    );
  }

  void _showApplyLoanDialog(BuildContext context) {
    final nameController = TextEditingController();
    final amountController = TextEditingController();
    final purposeController = TextEditingController();
    final formKey = GlobalKey<FormState>();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(
          left: 24,
          right: 24,
          top: 24,
          bottom: MediaQuery.of(ctx).viewInsets.bottom + 24,
        ),
        child: Form(
          key: formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Apply for Loan',
                  style: GoogleFonts.inter(
                      fontSize: 18, fontWeight: FontWeight.w600)),
              const SizedBox(height: 16),
              TextFormField(
                controller: nameController,
                decoration: const InputDecoration(
                  labelText: 'Member Name',
                  prefixIcon: Icon(Icons.person_outline),
                ),
                validator: (v) =>
                    v == null || v.trim().isEmpty ? 'Required' : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: amountController,
                decoration: const InputDecoration(
                  labelText: 'Amount',
                  prefixIcon: Icon(Icons.monetization_on_outlined),
                ),
                keyboardType: TextInputType.number,
                validator: (v) {
                  if (v == null || v.trim().isEmpty) return 'Required';
                  if (double.tryParse(v) == null || double.parse(v) <= 0) {
                    return 'Enter valid amount';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: purposeController,
                decoration: const InputDecoration(
                  labelText: 'Purpose',
                  prefixIcon: Icon(Icons.description_outlined),
                ),
                maxLines: 2,
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    if (formKey.currentState!.validate()) {
                      context.read<LoanProvider>().applyLoan({
                        'member_name': nameController.text.trim(),
                        'applied_amount':
                            double.parse(amountController.text.trim()),
                        'purpose': purposeController.text.trim(),
                      });
                      Navigator.pop(ctx);
                    }
                  },
                  child: const Text('Submit Application'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatsRow extends StatelessWidget {
  final LoanProvider provider;
  const _StatsRow({required this.provider});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          _StatItem(
            label: 'Active',
            value: provider.activeLoansCount.toString(),
            color: AppColors.statusActive,
          ),
          _StatItem(
            label: 'Pending',
            value: provider.pendingLoansCount.toString(),
            color: AppColors.statusPending,
          ),
          _StatItem(
            label: 'Defaulted',
            value: provider.defaultedLoansCount.toString(),
            color: AppColors.statusDefaulted,
          ),
          _StatItem(
            label: 'PAR',
            value: '${provider.portfolioAtRisk.toStringAsFixed(1)}%',
            color: provider.portfolioAtRisk > 5
                ? AppColors.error
                : AppColors.warning,
          ),
        ],
      ),
    );
  }
}

class _StatItem extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  const _StatItem(
      {required this.label,
      required this.value,
      required this.color});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        children: [
          Text(value,
              style: GoogleFonts.inter(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: color)),
          const SizedBox(height: 2),
          Text(label,
              style: GoogleFonts.inter(
                  fontSize: 11, color: Colors.grey[600])),
        ],
      ),
    );
  }
}

class _LoanCard extends StatelessWidget {
  final LoanModel loan;
  const _LoanCard({required this.loan});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    loan.loanProduct ?? 'Loan #${loan.loanId ?? loan.id}',
                    style: GoogleFonts.inter(
                        fontWeight: FontWeight.w600, fontSize: 15),
                  ),
                ),
                StatusBadge(
                  status: loan.statusText,
                ),
              ],
            ),
            if (loan.memberName != null) ...[
              const SizedBox(height: 4),
              Text(loan.memberName!,
                  style: GoogleFonts.inter(
                      fontSize: 13, color: Colors.grey[600])),
            ],
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Applied',
                          style: GoogleFonts.inter(
                              fontSize: 11, color: Colors.grey[500])),
                      Text(
                          Helpers.formatCurrency(
                              loan.appliedAmount ?? 0),
                          style: GoogleFonts.inter(
                              fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Payable',
                          style: GoogleFonts.inter(
                              fontSize: 11, color: Colors.grey[500])),
                      Text(
                          Helpers.formatCurrency(
                              loan.totalPayable ?? 0),
                          style: GoogleFonts.inter(
                              fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text('Outstanding',
                          style: GoogleFonts.inter(
                              fontSize: 11, color: Colors.grey[500])),
                      Text(
                          Helpers.formatCurrency(
                              loan.outstandingAmount ?? 0),
                          style: GoogleFonts.inter(
                              fontWeight: FontWeight.bold,
                              color: loan.outstandingAmount != null &&
                                      loan.outstandingAmount! > 0
                                  ? AppColors.warning
                                  : AppColors.success)),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: loan.repaymentProgress,
                backgroundColor: Colors.grey[200],
                color: loan.repaymentProgress >= 1
                    ? AppColors.success
                    : loan.isDefaulted
                        ? AppColors.error
                        : AppColors.primary,
                minHeight: 6,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              '${(loan.repaymentProgress * 100).toStringAsFixed(1)}% repaid',
              style: GoogleFonts.inter(
                  fontSize: 11, color: Colors.grey[500]),
            ),
          ],
        ),
      ),
    );
  }
}
