import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../../providers/app_provider.dart';
import '../../services/sync_service.dart';
import '../../core/theme/app_colors.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  @override
  Widget build(BuildContext context) {
    final provider = context.watch<AppProvider>();
    final syncStatus = provider.syncStatus;

    return Scaffold(
      appBar: AppBar(
        title: Text('Settings',
            style: GoogleFonts.inter(fontWeight: FontWeight.w600)),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _SectionHeader(title: 'Profile'),
          Card(
            child: Column(
              children: [
                ListTile(
                  leading: CircleAvatar(
                    child: Text(provider.currentUser?.initials ?? 'U',
                        style: GoogleFonts.inter(
                            fontWeight: FontWeight.bold)),
                  ),
                  title: Text(provider.currentUser?.fullName ?? 'User',
                      style: GoogleFonts.inter(
                          fontWeight: FontWeight.w600)),
                  subtitle: Text(
                      provider.currentUser?.email ?? '',
                      style: GoogleFonts.inter(fontSize: 13)),
                ),
                Divider(height: 1, color: Colors.grey[200]),
                ListTile(
                  leading: const Icon(Icons.badge_outlined),
                  title: Text('Role',
                      style: GoogleFonts.inter(fontSize: 14)),
                  trailing: Text(
                      provider.currentUser?.roleText ?? '',
                      style: GoogleFonts.inter(fontSize: 13)),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          _SectionHeader(title: 'Sync & Offline'),
          Card(
            child: Column(
              children: [
                ListTile(
                  leading: Icon(
                    Icons.sync,
                    color: syncStatus == SyncStatus.syncing
                        ? AppColors.warning
                        : syncStatus == SyncStatus.completed
                            ? AppColors.success
                            : Colors.grey,
                  ),
                  title: Text('Synchronization',
                      style: GoogleFonts.inter(fontSize: 14)),
                  subtitle: Text(
                    syncStatus == SyncStatus.syncing
                        ? 'Syncing... ${(provider.syncProgress * 100).toStringAsFixed(0)}%'
                        : syncStatus == SyncStatus.completed
                            ? 'Last sync: Just now'
                            : 'Tap to sync now',
                    style: GoogleFonts.inter(fontSize: 12),
                  ),
                  trailing: syncStatus == SyncStatus.syncing
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                              strokeWidth: 2),
                        )
                      : const Icon(Icons.sync),
                  onTap: () => provider.syncAll(),
                ),
                Divider(height: 1, color: Colors.grey[200]),
                SwitchListTile(
                  title: Text('Auto-sync',
                      style: GoogleFonts.inter(fontSize: 14)),
                  subtitle: Text('Sync every 15 minutes',
                      style: GoogleFonts.inter(fontSize: 12)),
                  value: true,
                  onChanged: (v) {},
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          _SectionHeader(title: 'Appearance'),
          Card(
            child: SwitchListTile(
              title: Text('Dark Mode',
                  style: GoogleFonts.inter(fontSize: 14)),
              subtitle: Text('Toggle dark theme',
                  style: GoogleFonts.inter(fontSize: 12)),
              value: provider.isDarkMode,
              onChanged: (v) => provider.toggleDarkMode(),
            ),
          ),
          const SizedBox(height: 24),
          _SectionHeader(title: 'Account'),
          Card(
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.lock_outline),
                  title: Text('Change Password',
                      style: GoogleFonts.inter(fontSize: 14)),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => _showChangePasswordDialog(context),
                ),
                Divider(height: 1, color: Colors.grey[200]),
                ListTile(
                  leading: const Icon(Icons.logout, color: AppColors.error),
                  title: Text('Logout',
                      style: GoogleFonts.inter(
                          fontSize: 14, color: AppColors.error)),
                  onTap: () => _confirmLogout(context),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          Center(
            child: Column(
              children: [
                Text('Intelli-Cash v1.0.0',
                    style: GoogleFonts.inter(
                        fontSize: 12, color: Colors.grey[500])),
                const SizedBox(height: 4),
                Text('Digital VSLA Platform',
                    style: GoogleFonts.inter(
                        fontSize: 11, color: Colors.grey[400])),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _confirmLogout(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Logout'),
        content: const Text('Are you sure you want to logout?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(ctx);
              context.read<AppProvider>().logout();
            },
            style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.error),
            child: const Text('Logout'),
          ),
        ],
      ),
    );
  }

  void _showChangePasswordDialog(BuildContext context) {
    final currentPwController = TextEditingController();
    final newPwController = TextEditingController();
    final confirmPwController = TextEditingController();
    final formKey = GlobalKey<FormState>();

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Change Password'),
        content: Form(
          key: formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                controller: currentPwController,
                decoration: const InputDecoration(
                  labelText: 'Current Password',
                ),
                obscureText: true,
                validator: (v) =>
                    v == null || v.isEmpty ? 'Required' : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: newPwController,
                decoration: const InputDecoration(
                  labelText: 'New Password',
                ),
                obscureText: true,
                validator: (v) =>
                    v == null || v.length < 6 ? 'Min 6 characters' : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: confirmPwController,
                decoration: const InputDecoration(
                  labelText: 'Confirm Password',
                ),
                obscureText: true,
                validator: (v) =>
                    v != newPwController.text ? 'Passwords do not match' : null,
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              if (formKey.currentState!.validate()) {
                Navigator.pop(ctx);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Password changed successfully'),
                    behavior: SnackBarBehavior.floating,
                  ),
                );
              }
            },
            child: const Text('Change'),
          ),
        ],
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  const _SectionHeader({required this.title});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8, left: 4),
      child: Text(title,
          style: GoogleFonts.inter(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: Colors.grey[600])),
    );
  }
}
