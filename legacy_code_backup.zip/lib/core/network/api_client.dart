import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart';
import '../constants/app_constants.dart';
import '../constants/api_endpoints.dart';

class ApiException implements Exception {
  final int? statusCode;
  final String message;
  final dynamic data;

  ApiException({this.statusCode, required this.message, this.data});

  @override
  String toString() => 'ApiException($statusCode): $message';
}

class NetworkException implements Exception {
  final String message;
  NetworkException(this.message);
  @override
  String toString() => 'NetworkException: $message';
}

class TimeoutException implements Exception {
  final String message;
  TimeoutException(this.message);
  @override
  String toString() => 'TimeoutException: $message';
}

class ApiResponse {
  final int statusCode;
  final dynamic data;
  final String? message;
  final Map<String, String>? headers;

  ApiResponse({
    required this.statusCode,
    this.data,
    this.message,
    this.headers,
  });

  bool get isSuccess => statusCode >= 200 && statusCode < 300;

  T? asType<T>(T Function(Map<String, dynamic>) fromJson) {
    if (data is Map<String, dynamic>) {
      return fromJson(data as Map<String, dynamic>);
    }
    return null;
  }

  List<T> asList<T>(T Function(dynamic) fromJson) {
    if (data is List) {
      return (data as List).map((e) => fromJson(e)).toList();
    }
    return [];
  }
}

class ApiClient {
  static final ApiClient _instance = ApiClient._internal();
  factory ApiClient() => _instance;
  ApiClient._internal();

  String? _baseUrl;
  String? _apiKey;
  String? _apiSecret;
  String? _accessToken;
  String? _refreshToken;
  final http.Client _client = http.Client();

  bool _isRefreshing = false;
  final List<Completer<void>> _refreshCompleters = [];

  bool get isConfigured =>
      _baseUrl != null &&
      _baseUrl!.isNotEmpty &&
      _apiKey != null &&
      _apiKey!.isNotEmpty;

  String get baseUrl => _baseUrl ?? '';
  String? get accessToken => _accessToken;
  String? get refreshToken => _refreshToken;

  void configure({
    required String baseUrl,
    String? apiKey,
    String? apiSecret,
    String? accessToken,
    String? refreshToken,
  }) {
    _baseUrl = baseUrl.replaceAll(RegExp(r'/$'), '');
    _apiKey = apiKey;
    _apiSecret = apiSecret;
    _accessToken = accessToken;
    _refreshToken = refreshToken;
  }

  void setTokens(String accessToken, String? refreshToken) {
    _accessToken = accessToken;
    _refreshToken = refreshToken;
  }

  void clearTokens() {
    _accessToken = null;
    _refreshToken = null;
  }

  Map<String, String> get _headers {
    final headers = <String, String>{
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };
    if (_accessToken != null && _accessToken!.isNotEmpty) {
      headers['Authorization'] = 'Bearer $_accessToken';
    } else {
      if (_apiKey != null) headers['X-Api-Key'] = _apiKey!;
      if (_apiSecret != null) headers['X-Api-Secret'] = _apiSecret!;
    }
    return headers;
  }

  Uri _buildUri(String endpoint, {Map<String, String>? queryParams}) {
    final url = '$_baseUrl/api/${AppConstants.apiVersion}$endpoint';
    final uri = Uri.parse(url);
    if (queryParams != null && queryParams.isNotEmpty) {
      return uri.replace(queryParameters: queryParams);
    }
    return uri;
  }

  Future<ApiResponse> get(
    String endpoint, {
    Map<String, String>? queryParams,
    bool requiresAuth = true,
  }) async {
    return _executeWithRetry(() async {
      final uri = _buildUri(endpoint, queryParams: queryParams);
      debugPrint('[API GET] $uri');
      final response = await _client
          .get(uri, headers: _headers)
          .timeout(Duration(milliseconds: AppConstants.connectTimeout));
      return _handleResponse(response);
    }, requiresAuth);
  }

  Future<ApiResponse> post(
    String endpoint, {
    Map<String, dynamic>? body,
    bool requiresAuth = true,
  }) async {
    return _executeWithRetry(() async {
      final uri = _buildUri(endpoint);
      debugPrint('[API POST] $uri');
      final response = await _client
          .post(
            uri,
            headers: _headers,
            body: body != null ? jsonEncode(body) : null,
          )
          .timeout(Duration(milliseconds: AppConstants.connectTimeout));
      return _handleResponse(response);
    }, requiresAuth);
  }

  Future<ApiResponse> put(
    String endpoint, {
    Map<String, dynamic>? body,
    bool requiresAuth = true,
  }) async {
    return _executeWithRetry(() async {
      final uri = _buildUri(endpoint);
      debugPrint('[API PUT] $uri');
      final response = await _client
          .put(
            uri,
            headers: _headers,
            body: body != null ? jsonEncode(body) : null,
          )
          .timeout(Duration(milliseconds: AppConstants.connectTimeout));
      return _handleResponse(response);
    }, requiresAuth);
  }

  Future<ApiResponse> patch(
    String endpoint, {
    Map<String, dynamic>? body,
    bool requiresAuth = true,
  }) async {
    return _executeWithRetry(() async {
      final uri = _buildUri(endpoint);
      debugPrint('[API PATCH] $uri');
      final response = await _client
          .patch(
            uri,
            headers: _headers,
            body: body != null ? jsonEncode(body) : null,
          )
          .timeout(Duration(milliseconds: AppConstants.connectTimeout));
      return _handleResponse(response);
    }, requiresAuth);
  }

  Future<ApiResponse> delete(
    String endpoint, {
    bool requiresAuth = true,
  }) async {
    return _executeWithRetry(() async {
      final uri = _buildUri(endpoint);
      debugPrint('[API DELETE] $uri');
      final response = await _client
          .delete(uri, headers: _headers)
          .timeout(Duration(milliseconds: AppConstants.connectTimeout));
      return _handleResponse(response);
    }, requiresAuth);
  }

  Future<ApiResponse> upload(
    String endpoint, {
    required List<int> fileBytes,
    required String fileName,
    String fieldName = 'file',
    Map<String, String>? fields,
    bool requiresAuth = true,
  }) async {
    return _executeWithRetry(() async {
      final uri = _buildUri(endpoint);
      final request = http.MultipartRequest('POST', uri);

      if (_accessToken != null) {
        request.headers['Authorization'] = 'Bearer $_accessToken';
      } else {
        if (_apiKey != null) request.headers['X-Api-Key'] = _apiKey!;
        if (_apiSecret != null) request.headers['X-Api-Secret'] = _apiSecret!;
      }

      request.files.add(http.MultipartFile.fromBytes(
        fieldName,
        fileBytes,
        filename: fileName,
      ));

      if (fields != null) {
        request.fields.addAll(fields);
      }

      debugPrint('[API UPLOAD] $uri');
      final streamedResponse = await request.send().timeout(
            Duration(milliseconds: AppConstants.sendTimeout),
          );
      final response = await http.Response.fromStream(streamedResponse);
      return _handleResponse(response);
    }, requiresAuth);
  }

  Future<ApiResponse> download(
    String endpoint, {
    String? savePath,
    Map<String, String>? queryParams,
  }) async {
    final uri = _buildUri(endpoint, queryParams: queryParams);
    debugPrint('[API DOWNLOAD] $uri');
    final response = await _client
        .get(uri, headers: _headers)
        .timeout(Duration(milliseconds: AppConstants.receiveTimeout));

    if (response.statusCode == 200) {
      if (savePath != null) {
        final file = File(savePath);
        await file.writeAsBytes(response.bodyBytes);
      }
      return ApiResponse(
        statusCode: response.statusCode,
        data: response.bodyBytes,
        headers: response.headers,
      );
    }
    return _handleResponse(response);
  }

  Future<ApiResponse> _executeWithRetry(
    Future<ApiResponse> Function() request,
    bool requiresAuth,
  ) async {
    for (int attempt = 0; attempt < AppConstants.maxRetryAttempts; attempt++) {
      try {
        final response = await request();
        if (response.statusCode == 401 && requiresAuth) {
          await _handleTokenRefresh();
          continue;
        }
        return response;
      } on SocketException {
        if (attempt == AppConstants.maxRetryAttempts - 1) {
          throw NetworkException(
              'No internet connection. Please check your network.');
        }
        await Future.delayed(Duration(seconds: 1 << attempt));
      } on http.ClientException {
        if (attempt == AppConstants.maxRetryAttempts - 1) {
          throw NetworkException('Connection failed. Please try again.');
        }
        await Future.delayed(Duration(seconds: 1 << attempt));
      } on TimeoutException {
        throw TimeoutException('Request timed out. Please try again.');
      }
    }
    throw NetworkException('Request failed after retries.');
  }

  Future<void> _handleTokenRefresh() async {
    if (_isRefreshing) {
      final completer = Completer<void>();
      _refreshCompleters.add(completer);
      return completer.future;
    }

    _isRefreshing = true;
    try {
      final response = await post(
        ApiEndpoints.refreshToken,
        body: {'refresh_token': _refreshToken},
        requiresAuth: false,
      );
      if (response.isSuccess) {
        _accessToken = response.data?['access_token'];
        _refreshToken = response.data?['refresh_token'];
      } else {
        clearTokens();
        throw ApiException(
          statusCode: 401,
          message: 'Session expired. Please login again.',
        );
      }
    } finally {
      _isRefreshing = false;
      for (final completer in _refreshCompleters) {
        completer.complete();
      }
      _refreshCompleters.clear();
    }
  }

  ApiResponse _handleResponse(http.Response response) {
    dynamic data;
    String? message;

    try {
      final decoded = jsonDecode(response.body);
      if (decoded is Map<String, dynamic>) {
        data = decoded['data'] ?? decoded;
        message = decoded['message'] ?? decoded['error'];
      } else {
        data = decoded;
      }
    } catch (_) {
      data = response.body;
    }

    if (response.statusCode >= 200 && response.statusCode < 300) {
      return ApiResponse(
        statusCode: response.statusCode,
        data: data,
        message: message,
        headers: response.headers,
      );
    }

    throw ApiException(
      statusCode: response.statusCode,
      message: message ?? 'An error occurred (${response.statusCode})',
      data: data,
    );
  }

  void dispose() {
    _client.close();
  }
}
