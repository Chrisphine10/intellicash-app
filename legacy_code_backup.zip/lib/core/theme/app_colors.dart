import 'package:flutter/material.dart';

class AppColors {
  static const Color primary = Color(0xFF1A56DB);
  static const Color primaryLight = Color(0xFF3B82F6);
  static const Color primaryDark = Color(0xFF1E40AF);

  static const Color secondary = Color(0xFF7C3AED);
  static const Color secondaryLight = Color(0xFFA78BFA);
  static const Color secondaryDark = Color(0xFF5B21B6);

  static const Color success = Color(0xFF059669);
  static const Color successLight = Color(0xFF34D399);
  static const Color successDark = Color(0xFF047857);

  static const Color warning = Color(0xFFD97706);
  static const Color warningLight = Color(0xFFFBBF24);
  static const Color warningDark = Color(0xFFB45309);

  static const Color error = Color(0xFFDC2626);
  static const Color errorLight = Color(0xFFF87171);
  static const Color errorDark = Color(0xFFB91C1C);

  static const Color info = Color(0xFF0284C7);
  static const Color infoLight = Color(0xFF38BDF8);
  static const Color infoDark = Color(0xFF0369A1);

  static const Color surface = Color(0xFFF8FAFC);
  static const Color surfaceDark = Color(0xFF1E293B);

  static const Color background = Color(0xFFFFFFFF);
  static const Color backgroundDark = Color(0xFF0F172A);

  static const Color textPrimary = Color(0xFF1E293B);
  static const Color textSecondary = Color(0xFF64748B);
  static const Color textDisabled = Color(0xFF94A3B8);
  static const Color textOnPrimary = Color(0xFFFFFFFF);
  static const Color textDarkPrimary = Color(0xFFF1F5F9);
  static const Color textDarkSecondary = Color(0xFF94A3B8);

  static const Color border = Color(0xFFE2E8F0);
  static const Color borderDark = Color(0xFF334155);
  static const Color divider = Color(0xFFF1F5F9);
  static const Color dividerDark = Color(0xFF1E293B);

  static const Color scaffoldBackground = Color(0xFFF8FAFC);
  static const Color scaffoldBackgroundDark = Color(0xFF0F172A);

  static const Color cardBackground = Color(0xFFFFFFFF);
  static const Color cardBackgroundDark = Color(0xFF1E293B);

  static const Color inputBackground = Color(0xFFFFFFFF);
  static const Color inputBackgroundDark = Color(0xFF1E293B);

  // Status colors
  static const Color statusActive = Color(0xFF059669);
  static const Color statusPending = Color(0xFFD97706);
  static const Color statusInactive = Color(0xFF6B7280);
  static const Color statusSuspended = Color(0xFFDC2626);
  static const Color statusCompleted = Color(0xFF0284C7);
  static const Color statusDefaulted = Color(0xFF991B1B);

  // Chart colors
  static const List<Color> chartColors = [
    Color(0xFF1A56DB),
    Color(0xFF7C3AED),
    Color(0xFF059669),
    Color(0xFFD97706),
    Color(0xFFDC2626),
    Color(0xFF0284C7),
    Color(0xFF8B5CF6),
    Color(0xFFEC4899),
    Color(0xFF14B8A6),
    Color(0xFFF97316),
  ];

  static const List<Color> gradientColors = [
    Color(0xFF1A56DB),
    Color(0xFF7C3AED),
    Color(0xFF059669),
  ];

  static const Map<String, Color> statusColors = {
    'active': statusActive,
    'inactive': statusInactive,
    'pending': statusPending,
    'suspended': statusSuspended,
    'completed': statusCompleted,
    'defaulted': statusDefaulted,
    'approved': statusActive,
    'rejected': error,
    'cancelled': statusInactive,
    'draft': statusPending,
    'withdrawn': statusInactive,
    'deceased': Colors.black87,
    'written_off': error,
    'restructured': warning,
    'scheduled': info,
    'in_progress': warning,
    'postponed': statusPending,
    'dormant': statusInactive,
    'overdue': error,
    'paid': success,
    'partial': warning,
  };

  static Color getStatusColor(String status) {
    return statusColors[status.toLowerCase()] ?? statusPending;
  }
}
