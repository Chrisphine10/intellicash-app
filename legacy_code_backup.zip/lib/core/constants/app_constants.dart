class AppConstants {
  static const String appName = 'Intelli-Cash';
  static const String appVersion = '1.0.0';
  static const String apiVersion = 'v1';

  static const int connectTimeout = 30000;
  static const int receiveTimeout = 30000;
  static const int sendTimeout = 30000;

  static const int defaultPageSize = 50;
  static const int maxOfflineRecords = 5000;
  static const int syncIntervalMinutes = 15;
  static const int maxRetryAttempts = 3;

  static const String dateFormat = 'yyyy-MM-dd';
  static const String dateTimeFormat = 'yyyy-MM-dd HH:mm:ss';
  static const String timeFormat = 'HH:mm:ss';
  static const String displayDateFormat = 'dd MMM yyyy';
  static const String displayDateTimeFormat = 'dd MMM yyyy HH:mm';
  static const String displayTimeFormat = 'HH:mm';

  static const String currencyCode = 'KES';
  static const String currencySymbol = 'KSh';
  static const String locale = 'en';
  static const String fallbackLocale = 'en';

  static const String dbName = 'intellicash.db';
  static const int dbVersion = 1;

  static const String encryptionKey = 'intellicash_encrypt_key_32bytes!';
  static const String hiveBoxName = 'intellicash_box';
  static const String secureStoragePrefix = 'ic_';

  static const String apiEndpointHealth = '/health';
  static const String apiEndpointAuth = '/auth';
  static const String apiEndpointUsers = '/users';
  static const String apiEndpointGroups = '/groups';
  static const String apiEndpointMembers = '/members';
  static const String apiEndpointMeetings = '/meetings';
  static const String apiEndpointSavings = '/savings';
  static const String apiEndpointLoans = '/loans';
  static const String apiEndpointTransactions = '/transactions';
  static const String apiEndpointReports = '/reports';
  static const String apiEndpointNotifications = '/notifications';
  static const String apiEndpointDocuments = '/documents';
  static const String apiEndpointSync = '/sync';
  static const String apiEndpointAudit = '/audit';
  static const String apiEndpointAnalytics = '/analytics';
  static const String apiEndpointPayments = '/payments';
  static const String apiEndpointAI = '/ai';
  static const String apiEndpointIntegrations = '/integrations';

  static const List<String> supportedLocales = ['en', 'sw', 'fr', 'ar'];
  static const List<String> supportedCurrencies = [
    'KES', 'UGX', 'TZS', 'RWF', 'BIF', 'SSP', 'NGN', 'GHS', 'ZAR', 'USD', 'EUR'
  ];

  static const Map<String, String> countryCodes = {
    'KE': '+254',
    'UG': '+256',
    'TZ': '+255',
    'RW': '+250',
    'BI': '+257',
    'SS': '+211',
    'NG': '+234',
    'GH': '+233',
    'ZA': '+27',
  };

  static const Map<String, String> loanTypes = {
    'emergency': 'Emergency Loan',
    'business': 'Business Loan',
    'agriculture': 'Agriculture Loan',
    'school_fees': 'School Fees Loan',
    'social': 'Social Loan',
    'education': 'Education Loan',
    'personal': 'Personal Loan',
    'group': 'Group Loan',
  };

  static const Map<String, String> meetingTypes = {
    'regular': 'Regular Meeting',
    'special': 'Special Meeting',
    'emergency': 'Emergency Meeting',
    'annual': 'Annual General Meeting',
    'training': 'Training Session',
  };

  static const List<String> memberStatuses = [
    'active', 'inactive', 'suspended', 'dormant', 'withdrawn', 'deceased'
  ];

  static const List<String> loanStatuses = [
    'draft', 'pending', 'approved', 'active', 'completed', 'defaulted',
    'written_off', 'restructured', 'rejected', 'cancelled'
  ];

  static const List<String> meetingStatuses = [
    'scheduled', 'in_progress', 'completed', 'cancelled', 'postponed'
  ];

  static const List<String> savingsTypes = [
    'voluntary', 'mandatory', 'share', 'social_fund', 'emergency'
  ];
}
