import '../constants/app_constants.dart';

class ApiEndpoints {
  static String baseUrl = '';

  static const String health = '/health';
  static const String testConnection = '/health/ping';

  // Auth
  static const String login = '/auth/login';
  static const String register = '/auth/register';
  static const String logout = '/auth/logout';
  static const String refreshToken = '/auth/refresh';
  static const String forgotPassword = '/auth/forgot-password';
  static const String resetPassword = '/auth/reset-password';
  static const String verifyEmail = '/auth/verify-email';
  static const String verifyMfa = '/auth/verify-mfa';
  static const String changePassword = '/auth/change-password';
  static const String profile = '/auth/profile';
  static const String twoFactor = '/auth/two-factor';

  // Users
  static const String users = '/users';
  static String userById(String id) => '/users/$id';
  static String userGroups(String id) => '/users/$id/groups';
  static String userPermissions(String id) => '/users/$id/permissions';

  // Organizations
  static const String organizations = '/organizations';
  static String organizationById(String id) => '/organizations/$id';
  static String organizationSettings(String id) => '/organizations/$id/settings';
  static String organizationBranding(String id) => '/organizations/$id/branding';
  static String organizationUsers(String id) => '/organizations/$id/users';

  // Groups
  static const String groups = '/groups';
  static String groupById(String id) => '/groups/$id';
  static String groupMembers(String id) => '/groups/$id/members';
  static String groupMeetings(String id) => '/groups/$id/meetings';
  static String groupSavings(String id) => '/groups/$id/savings';
  static String groupLoans(String id) => '/groups/$id/loans';
  static String groupReports(String id) => '/groups/$id/reports';
  static String groupFinancials(String id) => '/groups/$id/financials';
  static String groupSettings(String id) => '/groups/$id/settings';
  static String groupConstitution(String id) => '/groups/$id/constitution';
  static String groupLeaders(String id) => '/groups/$id/leaders';
  static String groupCashbook(String id) => '/groups/$id/cashbook';
  static String groupGeneralLedger(String id) => '/groups/$id/general-ledger';

  // Members
  static const String members = '/members';
  static String memberById(String id) => '/members/$id';
  static String memberSavings(String id) => '/members/$id/savings';
  static String memberLoans(String id) => '/members/$id/loans';
  static String memberTransactions(String id) => '/members/$id/transactions';
  static String memberDocuments(String id) => '/members/$id/documents';
  static String memberHistory(String id) => '/members/$id/history';
  static String memberCreditScore(String id) => '/members/$id/credit-score';
  static String memberAttendance(String id) => '/members/$id/attendance';
  static String memberKyc(String id) => '/members/$id/kyc';
  static String memberPhoto(String id) => '/members/$id/photo';
  static String memberSignature(String id) => '/members/$id/signature';

  // Meetings
  static const String meetings = '/meetings';
  static String meetingById(String id) => '/meetings/$id';
  static String meetingAttendance(String id) => '/meetings/$id/attendance';
  static String meetingMinutes(String id) => '/meetings/$id/minutes';
  static String meetingAgenda(String id) => '/meetings/$id/agenda';
  static String meetingResolutions(String id) => '/meetings/$id/resolutions';
  static String meetingVotes(String id) => '/meetings/$id/votes';
  static String meetingSignatures(String id) => '/meetings/$id/signatures';
  static String meetingReport(String id) => '/meetings/$id/report';
  static String meetingFinancials(String id) => '/meetings/$id/financials';

  // Savings
  static const String savings = '/savings';
  static String savingById(String id) => '/savings/$id';
  static String savingDeposit(String id) => '/savings/$id/deposit';
  static String savingWithdrawal(String id) => '/savings/$id/withdrawal';
  static String savingTransfer(String id) => '/savings/$id/transfer';
  static String savingTransactions(String id) => '/savings/$id/transactions';
  static String savingStatement(String id) => '/savings/$id/statement';
  static String savingInterest(String id) => '/savings/$id/interest';

  // Loans
  static const String loans = '/loans';
  static String loanById(String id) => '/loans/$id';
  static String loanRepayments(String id) => '/loans/$id/repayments';
  static String loanSchedule(String id) => '/loans/$id/schedule';
  static String loanGuarantors(String id) => '/loans/$id/guarantors';
  static String loanCollateral(String id) => '/loans/$id/collateral';
  static String loanRestructure(String id) => '/loans/$id/restructure';
  static String loanWriteOff(String id) => '/loans/$id/write-off';
  static String loanApproval(String id) => '/loans/$id/approval';
  static String loanDisbursement(String id) => '/loans/$id/disbursement';

  // Transactions
  static const String transactions = '/transactions';
  static String transactionById(String id) => '/transactions/$id';
  static String transactionReceipt(String id) => '/transactions/$id/receipt';
  static String transactionReverse(String id) => '/transactions/$id/reverse';

  // Reports
  static const String reports = '/reports';
  static String reportById(String id) => '/reports/$id';
  static const String reportDashboard = '/reports/dashboard';
  static const String reportFinancial = '/reports/financial';
  static const String reportLoan = '/reports/loan';
  static const String reportSavings = '/reports/savings';
  static const String reportAttendance = '/reports/attendance';
  static const String reportPortfolio = '/reports/portfolio';
  static const String reportGender = '/reports/gender';
  static const String reportImpact = '/reports/impact';
  static const String reportExcel = '/reports/excel';
  static const String reportPdf = '/reports/pdf';
  static const String reportCsv = '/reports/csv';

  // Notifications
  static const String notifications = '/notifications';
  static const String notificationSend = '/notifications/send';
  static const String notificationTemplates = '/notifications/templates';
  static String notificationById(String id) => '/notifications/$id';
  static const String notificationRead = '/notifications/read-all';
  static String notificationReadOne(String id) => '/notifications/$id/read';

  // Documents
  static const String documents = '/documents';
  static String documentById(String id) => '/documents/$id';
  static String documentDownload(String id) => '/documents/$id/download';
  static String documentUpload = '/documents/upload';
  static String documentSign(String id) => '/documents/$id/sign';

  // Payments
  static const String payments = '/payments';
  static const String paymentMpesa = '/payments/mpesa';
  static const String paymentMpesaStk = '/payments/mpesa/stk-push';
  static const String paymentBank = '/payments/bank';
  static const String paymentMobileMoney = '/payments/mobile-money';
  static const String paymentCard = '/payments/card';
  static const String paymentWallet = '/payments/wallet';
  static const String paymentVerify = '/payments/verify';
  static const String paymentReconcile = '/payments/reconcile';

  // Sync
  static const String sync = '/sync';
  static const String syncPull = '/sync/pull';
  static const String syncPush = '/sync/push';
  static const String syncStatus = '/sync/status';
  static const String syncConflict = '/sync/conflicts';
  static const String syncResolve = '/sync/resolve';

  // AI
  static const String ai = '/ai';
  static const String aiChat = '/ai/chat';
  static const String aiPredict = '/ai/predict';
  static const String aiSummarize = '/ai/summarize';
  static const String aiOcr = '/ai/ocr';
  static const String aiTranslate = '/ai/translate';
  static const String aiSpeechToText = '/ai/speech-to-text';
  static const String aiRecommend = '/ai/recommend';
  static const String aiFraudDetection = '/ai/fraud-detection';
  static const String aiReportGenerator = '/ai/report-generator';
  static const String aiFinancialAdvisor = '/ai/financial-advisor';

  // Audit
  static const String auditLogs = '/audit/logs';
  static const String auditTrail = '/audit/trail';
  static String auditByEntity(String entity, String id) =>
      '/audit/$entity/$id';

  // Analytics
  static const String analytics = '/analytics';
  static const String analyticsKpi = '/analytics/kpi';
  static const String analyticsTrends = '/analytics/trends';
  static const String analyticsForecast = '/analytics/forecast';
  static const String analyticsHeatmap = '/analytics/heatmap';

  // Financial
  static const String cashbook = '/financial/cashbook';
  static const String generalLedger = '/financial/general-ledger';
  static const String chartOfAccounts = '/financial/chart-of-accounts';
  static const String trialBalance = '/financial/trial-balance';
  static const String incomeStatement = '/financial/income-statement';
  static const String balanceSheet = '/financial/balance-sheet';
  static const String cashFlow = '/financial/cash-flow';

  // Integrations
  static const String integrations = '/integrations';
  static const String integrationDhis2 = '/integrations/dhis2';
  static const String integrationSalesforce = '/integrations/salesforce';
  static const String integrationPowerBi = '/integrations/power-bi';
  static const String integrationQuickBooks = '/integrations/quickbooks';
  static const String integrationXero = '/integrations/xero';

  static String buildUrl(String endpoint) => '$baseUrl/api/${AppConstants.apiVersion}$endpoint';
}
