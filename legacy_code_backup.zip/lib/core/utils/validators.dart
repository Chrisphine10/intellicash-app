class Validators {
  static String? required(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'This field is required';
    }
    return null;
  }

  static String? email(String? value) {
    if (value == null || value.trim().isEmpty) return null;
    final emailRegex = RegExp(
      r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$',
    );
    if (!emailRegex.hasMatch(value.trim())) {
      return 'Enter a valid email address';
    }
    return null;
  }

  static String? phone(String? value) {
    if (value == null || value.trim().isEmpty) return null;
    final phoneRegex = RegExp(r'^\+?[\d\s\-()]{7,15}$');
    if (!phoneRegex.hasMatch(value.trim())) {
      return 'Enter a valid phone number';
    }
    return null;
  }

  static String? nationalId(String? value) {
    if (value == null || value.trim().isEmpty) return null;
    if (value.trim().length < 5) {
      return 'Enter a valid national ID';
    }
    return null;
  }

  static String? amount(String? value) {
    if (value == null || value.trim().isEmpty) return null;
    final amount = double.tryParse(value.trim());
    if (amount == null || amount < 0) {
      return 'Enter a valid amount';
    }
    return null;
  }

  static String? positiveAmount(String? value) {
    if (value == null || value.trim().isEmpty) return 'Amount is required';
    final amount = double.tryParse(value.trim());
    if (amount == null || amount <= 0) {
      return 'Amount must be greater than zero';
    }
    return null;
  }

  static String? percentage(String? value) {
    if (value == null || value.trim().isEmpty) return null;
    final pct = double.tryParse(value.trim());
    if (pct == null || pct < 0 || pct > 100) {
      return 'Enter a percentage between 0 and 100';
    }
    return null;
  }

  static String? password(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Password is required';
    }
    if (value.length < 8) {
      return 'Password must be at least 8 characters';
    }
    if (!RegExp(r'[A-Z]').hasMatch(value)) {
      return 'Password must contain an uppercase letter';
    }
    if (!RegExp(r'[a-z]').hasMatch(value)) {
      return 'Password must contain a lowercase letter';
    }
    if (!RegExp(r'[0-9]').hasMatch(value)) {
      return 'Password must contain a number';
    }
    return null;
  }

  static String? confirmPassword(String? value, String password) {
    if (value == null || value.trim().isEmpty) {
      return 'Please confirm your password';
    }
    if (value != password) {
      return 'Passwords do not match';
    }
    return null;
  }

  static String? url(String? value) {
    if (value == null || value.trim().isEmpty) return null;
    final urlRegex = RegExp(
      r'^https?:\/\/[\w\-]+(\.[\w\-]+)+[/#?]?.*$',
    );
    if (!urlRegex.hasMatch(value.trim())) {
      return 'Enter a valid URL';
    }
    return null;
  }

  static String? integer(String? value) {
    if (value == null || value.trim().isEmpty) return null;
    if (int.tryParse(value.trim()) == null) {
      return 'Enter a valid whole number';
    }
    return null;
  }

  static String? positiveInteger(String? value) {
    if (value == null || value.trim().isEmpty) return 'This field is required';
    final num = int.tryParse(value.trim());
    if (num == null || num <= 0) {
      return 'Enter a positive number';
    }
    return null;
  }

  static String? Function(String?) minLength(int min) {
    return (String? value) {
      if (value == null || value.trim().isEmpty) return null;
      if (value.trim().length < min) {
        return 'Must be at least $min characters';
      }
      return null;
    };
  }

  static String? Function(String?) maxLength(int max) {
    return (String? value) {
      if (value == null || value.trim().isEmpty) return null;
      if (value.trim().length > max) {
        return 'Must be at most $max characters';
      }
      return null;
    };
  }

  static String? date(String? value) {
    if (value == null || value.trim().isEmpty) return null;
    try {
      DateTime.parse(value.trim());
    } catch (_) {
      return 'Enter a valid date';
    }
    return null;
  }

  static String? futureDate(String? value) {
    if (value == null || value.trim().isEmpty) return null;
    try {
      final date = DateTime.parse(value.trim());
      if (date.isBefore(DateTime.now().subtract(const Duration(days: 1)))) {
        return 'Date must be in the future';
      }
    } catch (_) {
      return 'Enter a valid date';
    }
    return null;
  }

  static String? pastDate(String? value) {
    if (value == null || value.trim().isEmpty) return null;
    try {
      final date = DateTime.parse(value.trim());
      if (date.isAfter(DateTime.now())) {
        return 'Date must be in the past';
      }
    } catch (_) {
      return 'Enter a valid date';
    }
    return null;
  }
}
