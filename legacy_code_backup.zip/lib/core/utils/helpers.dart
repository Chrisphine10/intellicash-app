import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class Helpers {
  static String formatCurrency(double amount, {String? currency}) {
    final format = NumberFormat.currency(
      symbol: currency ?? 'KSh',
      decimalDigits: 2,
    );
    return format.format(amount);
  }

  static String formatNumber(double number, {int decimals = 2}) {
    final fmt = NumberFormat('#,##0.${'0' * decimals}');
    return fmt.format(number);
  }

  static String formatDate(DateTime date, {String? format}) {
    final fmt = DateFormat(format ?? 'dd MMM yyyy');
    return fmt.format(date);
  }

  static String formatDateTime(DateTime date) {
    final fmt = DateFormat('dd MMM yyyy HH:mm');
    return fmt.format(date);
  }

  static String formatTime(DateTime date) {
    final fmt = DateFormat('HH:mm');
    return fmt.format(date);
  }

  static String timeAgo(DateTime date) {
    final now = DateTime.now();
    final diff = now.difference(date);
    if (diff.inSeconds < 60) return '${diff.inSeconds}s ago';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
    if (diff.inHours < 24) return '${diff.inHours}h ago';
    if (diff.inDays < 7) return '${diff.inDays}d ago';
    if (diff.inDays < 30) return '${(diff.inDays / 7).floor()}w ago';
    if (diff.inDays < 365) return '${(diff.inDays / 30).floor()}mo ago';
    return '${(diff.inDays / 365).floor()}y ago';
  }

  static String truncate(String text, int maxLength) {
    if (text.length <= maxLength) return text;
    return '${text.substring(0, maxLength)}...';
  }

  static String initials(String firstName, String lastName) {
    final first = firstName.isNotEmpty ? firstName[0].toUpperCase() : '';
    final last = lastName.isNotEmpty ? lastName[0].toUpperCase() : '';
    return '$first$last';
  }

  static String initialsFromName(String fullName) {
    final parts = fullName.split(' ');
    if (parts.length >= 2) {
      return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
    }
    return parts[0][0].toUpperCase();
  }

  static String phoneWithCountryCode(String countryCode, String phone) {
    final cleanPhone = phone.replaceAll(RegExp(r'[^0-9]'), '');
    if (cleanPhone.startsWith('0')) {
      return '$countryCode${cleanPhone.substring(1)}';
    }
    return '$countryCode$cleanPhone';
  }

  static String maskPhone(String phone) {
    if (phone.length < 6) return phone;
    return '${phone.substring(0, 3)}****${phone.substring(phone.length - 3)}';
  }

  static String maskEmail(String email) {
    final parts = email.split('@');
    if (parts.length != 2) return email;
    final name = parts[0];
    if (name.length <= 2) return '${name[0]}***@${parts[1]}';
    return '${name[0]}${name[1]}***@${parts[1]}';
  }

  static String generateMemberNumber(String prefix, int count) {
    return '$prefix${(count + 1).toString().padLeft(6, '0')}';
  }

  static String generateGroupCode(String prefix, int count) {
    return '$prefix${(count + 1).toString().padLeft(4, '0')}';
  }

  static String generateLoanId(String prefix, int count) {
    return 'LN-$prefix${DateTime.now().year}-${(count + 1).toString().padLeft(5, '0')}';
  }

  static String generateTransactionRef(String type) {
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    final random = (timestamp % 10000).toString().padLeft(4, '0');
    return '$type-$timestamp-$random';
  }

  static String pluralize(int count, String singular, {String? plural}) {
    if (count == 1) return '$count $singular';
    return '$count ${plural ?? '${singular}s'}';
  }

  static bool isValidEmail(String email) {
    return RegExp(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
        .hasMatch(email);
  }

  static bool isValidPhone(String phone) {
    return RegExp(r'^\+?[\d\s\-()]{7,15}$').hasMatch(phone);
  }

  static double calculatePercentage(double value, double total) {
    if (total == 0) return 0;
    return (value / total) * 100;
  }

  static String formatPercentage(double value) {
    return '${value.toStringAsFixed(1)}%';
  }

  static String fileSizeString(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    if (bytes < 1024 * 1024 * 1024) {
      return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    }
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(1)} GB';
  }

  static Color parseColor(String hex) {
    hex = hex.replaceAll('#', '');
    if (hex.length == 6) hex = 'FF$hex';
    return Color(int.parse(hex, radix: 16));
  }

  static String colorToHex(Color color) {
    return '#${color.toARGB32().toRadixString(16).substring(2).toUpperCase()}';
  }

  static Map<String, dynamic> removeNulls(Map<String, dynamic> map) {
    return map..removeWhere((_, v) => v == null);
  }

  static String capitalize(String text) {
    if (text.isEmpty) return text;
    return text[0].toUpperCase() + text.substring(1);
  }

  static String titleCase(String text) {
    return text.split('_').map((word) {
      if (word.isEmpty) return word;
      return word[0].toUpperCase() + word.substring(1);
    }).join(' ');
  }

  static String snakeCase(String text) {
    return text
        .replaceAllMapped(
          RegExp(r'[A-Z]'),
          (match) => '_${match.group(0)!.toLowerCase()}',
        )
        .toLowerCase()
        .replaceAll(RegExp(r'^_'), '');
  }

  static T? enumFromString<T>(List<T> values, String? value) {
    if (value == null) return null;
    return values.firstWhere(
      (v) => v.toString().split('.').last.toLowerCase() == value.toLowerCase(),
      orElse: () => values.first,
    );
  }

  static int calculateAge(DateTime birthDate) {
    final now = DateTime.now();
    int age = now.year - birthDate.year;
    if (now.month < birthDate.month ||
        (now.month == birthDate.month && now.day < birthDate.day)) {
      age--;
    }
    return age;
  }

  static String genderDisplay(String? gender) {
    switch (gender?.toLowerCase()) {
      case 'm':
      case 'male':
        return 'Male';
      case 'f':
      case 'female':
        return 'Female';
      default:
        return 'Other';
    }
  }
}
