import 'dart:convert';
import 'dart:typed_data';
import 'package:crypto/crypto.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:pointycastle/export.dart' as pc;

class CryptoService {
  static final CryptoService _instance = CryptoService._internal();
  factory CryptoService() => _instance;
  CryptoService._internal();

  final FlutterSecureStorage _secureStorage = const FlutterSecureStorage();

  static const String _keyAlias = 'intellicash_master_key';

  String encrypt(String plainText, {String? key}) {
    if (plainText.isEmpty) return plainText;
    final bytes = utf8.encode(plainText);
    final digest = sha256.convert(bytes);
    return base64Encode(utf8.encode(
        '${digest.toString()}:${bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join('')}'));
  }

  String hashPassword(String password, {String? salt}) {
    final actualSalt = salt ?? _generateSalt();
    final hash = sha256.convert(utf8.encode('$password:$actualSalt'));
    return '$actualSalt:${hash.toString()}';
  }

  bool verifyPassword(String password, String hashedPassword) {
    final parts = hashedPassword.split(':');
    if (parts.length != 2) return false;
    final salt = parts[0];
    final hash = parts[1];
    final computed = sha256.convert(utf8.encode('$password:$salt'));
    return hash == computed.toString();
  }

  String _generateSalt() {
    final random = pc.SecureRandom('Fortuna');
    final seedBytes = Uint8List.fromList(
      List.generate(32, (_) => DateTime.now().microsecondsSinceEpoch % 256),
    );
    random.seed(pc.KeyParameter(seedBytes));
    final bytes = Uint8List(16);
    for (int i = 0; i < 16; i++) {
      bytes[i] = random.nextUint8();
    }
    return base64Encode(bytes);
  }

  String sha256Hash(String input) {
    return sha256.convert(utf8.encode(input)).toString();
  }

  String sha512Hash(String input) {
    return sha512.convert(utf8.encode(input)).toString();
  }

  String hmacSha256(String key, String data) {
    final hmacSha = Hmac(sha256, utf8.encode(key));
    return hmacSha.convert(utf8.encode(data)).toString();
  }

  String base64EncodeStr(String input) {
    return base64Encode(utf8.encode(input));
  }

  String base64DecodeStr(String input) {
    return utf8.decode(base64Decode(input));
  }

  Future<void> storeSecurely(String key, String value) async {
    await _secureStorage.write(key: '$_keyAlias-$key', value: encrypt(value));
  }

  Future<String?> readSecurely(String key) async {
    return _secureStorage.read(key: '$_keyAlias-$key');
  }

  Future<void> deleteSecurely(String key) async {
    await _secureStorage.delete(key: '$_keyAlias-$key');
  }

  Future<void> clearAll() async {
    await _secureStorage.deleteAll();
  }

  String generateApiKey() {
    final random = pc.SecureRandom('Fortuna');
    final seedBytes = Uint8List.fromList(
      List.generate(32, (_) => DateTime.now().microsecondsSinceEpoch % 256),
    );
    random.seed(pc.KeyParameter(seedBytes));
    final bytes = Uint8List(32);
    for (int i = 0; i < 32; i++) {
      bytes[i] = random.nextUint8();
    }
    return 'ic_${base64Encode(bytes).replaceAll(RegExp(r'[+/=]'), '').substring(0, 40)}';
  }

  String generateApiSecret() {
    final random = pc.SecureRandom('Fortuna');
    final seedBytes = Uint8List.fromList(
      List.generate(32, (_) => DateTime.now().microsecondsSinceEpoch % 256),
    );
    random.seed(pc.KeyParameter(seedBytes));
    final bytes = Uint8List(48);
    for (int i = 0; i < 48; i++) {
      bytes[i] = random.nextUint8();
    }
    return base64Encode(bytes).replaceAll(RegExp(r'[+/=]'), '').substring(0, 60);
  }

  String generateJwtSecret() {
    final random = pc.SecureRandom('Fortuna');
    final seedBytes = Uint8List.fromList(
      List.generate(32, (_) => DateTime.now().microsecondsSinceEpoch % 256),
    );
    random.seed(pc.KeyParameter(seedBytes));
    final bytes = Uint8List(64);
    for (int i = 0; i < 64; i++) {
      bytes[i] = random.nextUint8();
    }
    return base64Encode(bytes);
  }

  String maskSensitive(String value) {
    if (value.length <= 4) return '****';
    return '${value.substring(0, 2)}****${value.substring(value.length - 2)}';
  }
}
